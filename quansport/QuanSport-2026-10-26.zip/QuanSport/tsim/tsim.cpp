// tsim -- transim's semiclassical tracer on a transim deck, for QuanSport's side-by-side view.
// Built against the LIVE transim/src/plugin.cpp (#included, as transim's own test/dfm.cpp does), and fed
// the very messages transim's panel sends when it opens a project file, so there is no second copy
// of transim's physics.
//
//   tsim <messages.txt> <B1,B2,...> <nTraj>
// messages.txt: one JSON message per line (configure / contacts / map), as transim's panel sends them.
// Prints one JSON line per field: {"B", "launched", "gx", "gy", "T": {contact id: fraction}, "d": [...]}
// with T = carriers from the source reaching each terminal / carriers launched, and d the trajectory
// density grid (row 0 = bottom, index iy * gx + ix).
#include "plugin.cpp"

#include <cstdio>
#include <fstream>
#include <sstream>

int main(int argc, char **argv) {
    if (argc < 4) { std::fprintf(stderr, "usage: tsim messages.txt B1,B2,... nTraj\n"); return 2; }
    Instance s;
    std::ifstream in(argv[1]);
    std::string line;
    int nmsg = 0;
    while (std::getline(in, line)) { if (!line.empty()) { handleMessage(s, line); ++nmsg; } }
    for (const std::string &o : s.outbox) if (o.find("\"error\"") != std::string::npos) std::fprintf(stderr, "transim: %s\n", o.c_str());
    std::vector<double> Bs;
    { std::stringstream ss(argv[2]); std::string tok; while (std::getline(ss, tok, ',')) if (!tok.empty()) Bs.push_back(std::stod(tok)); }
    const int N = std::max(100, std::atoi(argv[3]));
    const size_t nc = s.contacts.size();
    int src = -1;
    for (size_t j = 0; j < nc; ++j) if (s.contacts[j].role == "source") { src = static_cast<int>(j); break; }
    if (src < 0) { std::fprintf(stderr, "no source contact\n"); return 1; }
    for (double B : Bs) {
        Params p = s.p; p.B = B;
        const TrajResult tr = runTrajectoriesSync(s, p, false, false, N);
        // with a single source, row 0 of `reached` belongs to it (as test/dfm.cpp reads it)
        const double L = tr.launchedBy.empty() ? 0.0 : static_cast<double>(tr.launchedBy[0]);
        std::printf("{\"B\":%.9g,\"launched\":%.0f,\"gx\":%d,\"gy\":%d,\"T\":{", B, L, tr.gx, tr.gy);
        bool first = true;
        for (size_t j = 0; j < nc; ++j) {
            const std::string &r = s.contacts[j].role;
            if (static_cast<int>(j) == src || (r != "drain" && r != "probe" && r != "source")) continue;
            std::printf("%s\"%s\":%.6g", first ? "" : ",", s.contacts[j].id.c_str(), L > 0 ? tr.reached[0 * nc + j] / L : 0.0);
            first = false;
        }
        std::printf("},\"d\":[");
        for (size_t k = 0; k < tr.density.size(); ++k) std::printf("%s%llu", k ? "," : "", static_cast<unsigned long long>(tr.density[k]));
        std::printf("]}\n");
        std::fflush(stdout);
    }
    return 0;
}
