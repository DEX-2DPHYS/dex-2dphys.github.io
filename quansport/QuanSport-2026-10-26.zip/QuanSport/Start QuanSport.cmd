@echo off
title QuanSport
rem Starts the QuanSport backend and opens QuanSport in the browser.
rem Keep this window open while you work; closing it stops QuanSport.
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is needed: https://nodejs.org/ ^(the LTS installer^). & pause & exit /b 1)
node app\server.mjs %*
if errorlevel 1 pause
