"""Where QuanSport finds transim and prebuilt helpers.

Working copy (Dropbox): transim is the DSW plugin next door, and C++ helpers are built on first use.
Downloaded package: transim/ inside the QuanSport folder holds transim's example devices and dfm.json
(not its C++ source), and bin/ holds tsim.exe and g1_ref.exe prebuilt from that source, so no compiler
is needed."""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PACKAGED = os.path.join(ROOT, "transim")
TRANSIM = _PACKAGED if os.path.isdir(os.path.join(_PACKAGED, "ui", "examples")) else \
    os.path.normpath(os.path.join(ROOT, "..", "DSW", "Plugins", "2D Materials", "transim"))
EXAMPLES = os.path.join(TRANSIM, "ui", "examples")
PREBUILT = os.path.join(ROOT, "bin")


def prebuilt(name):
    """A packaged prebuilt executable, or None in the working copy."""
    p = os.path.join(PREBUILT, name + (".exe" if os.name == "nt" else ""))
    return p if os.path.isfile(p) else None
