"""QuanSport job worker: one job (JSON on stdin), progress and results as JSON lines on stdout.

Job:
  {"kind": "run" | "preview",
   "deck": <transim-project dict>,
   "s": 10, "energy": 0.0, "B": [0, 0.002, ...],
   "options": {cap_width_nm, cap_strength, absorbing_edges, rebuild_junctions},
   "maps": {"gx": 360, "gy": 180, "at": [B values], "kinds": ["density", "current"]},
   "semiclassical": {"on": true, "nTraj": 200000}}
Lines:
  {"t":"log","msg"}  {"t":"classical",...}  {"t":"built",...}  {"t":"point",...}  {"t":"map",...}
  {"t":"done","secs","peakMB"}  {"t":"error","msg"}
"""
import json
import math
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))

import numpy as np  # noqa: E402

from qtrans import deck as dk  # noqa: E402
from qtrans.model import Graphene  # noqa: E402


def emit(**kw):
    sys.stdout.write(json.dumps(kw, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def peak_mb():
    """Peak resident memory of this process (MB)."""
    try:
        if sys.platform == "win32":
            import ctypes
            from ctypes import wintypes

            class PMC(ctypes.Structure):
                _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                            ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                            ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                            ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                            ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]
            c = PMC()
            c.cb = ctypes.sizeof(PMC)
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.GetCurrentProcess.restype = wintypes.HANDLE          # a pseudo-handle (-1): without the
            k32.K32GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(PMC), wintypes.DWORD]
            k32.K32GetProcessMemoryInfo.restype = wintypes.BOOL       # types it was truncated and the call failed
            if not k32.K32GetProcessMemoryInfo(k32.GetCurrentProcess(), ctypes.byref(c), c.cb):
                return float("nan")
            return c.PeakWorkingSetSize / 2 ** 20
        import resource
        return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
    except Exception:
        return float("nan")


def preview(job):
    d = dk.parse(job["deck"])
    s = float(job.get("s", 10))
    g = Graphene(s=s)
    area = d.W_um * d.H_um * 1e6                       # nm^2
    hole = sum(math.pi / 4 * (c.x1 - c.x0) * (c.y1 - c.y0) * area if c.role == "reflector" else
               (c.x1 - c.x0) * (c.y1 - c.y0) * area for c in d.contacts if c.is_obstacle())
    sites = (area - hole) * 4 / (math.sqrt(3) * g.A ** 2)   # 2 atoms per cell of area sqrt(3)/2 A^2
    if str(d.params.get("edge", "specular")) == "absorbing":  # the absorbing frame outside the device
        k0 = abs(float(g.kF_signed(d.n_cm2))) or 0.177
        wc = 3 * 2 * math.pi / k0
        frame = 2 * (d.W_um + d.H_um) * 1e3 * wc + 4 * wc * wc
        sites += frame * 4 / (math.sqrt(3) * g.A ** 2)
    n_abs = np.abs(d.density.data) if d.density is not None else np.array([abs(d.n_cm2)])
    nmax = float(n_abs.max()) or abs(d.n_cm2)
    nref = float(np.median(n_abs[n_abs > 0])) if np.any(n_abs > 0) else abs(d.n_cm2)
    kmax = float(abs(g.kF_signed(nmax)))
    kref = float(abs(g.kF_signed(nref)))
    Umax = g.hvF * kmax
    warn = []
    if kref * g.acc > 0.3:
        warn.append("k_F a_s = %.2f at the typical density: lattice effects (warping) are not small; "
                    "G2/G3 found s with k_F a_s <= 0.25 needed for angular accuracy" % (kref * g.acc))
    if Umax > 0.5 * 3 * g.t:
        warn.append("the highest density needs |U| = %.2f eV, beyond half the scaled band (%.2f eV): "
                    "lower s; metal-like regions need their own model" % (Umax, 1.5 * g.t))
    roles = {}
    for c in d.contacts:
        roles[c.role] = roles.get(c.role, 0) + 1
    emit(t="preview", name=d.name, W_um=d.W_um, H_um=d.H_um, s=s, a_s_nm=g.acc, t_s_eV=g.t,
         sites=int(sites), kFas=kref * g.acc, lambdaF_nm=2 * math.pi / kref if kref else None,
         EF_eV=g.hvF * kref, Umax_eV=Umax, roles=roles, warnings=warn, hash=d.sha256)


def run(job):
    from qtrans import device as D
    from qtrans import output

    d = dk.parse(job["deck"])
    s = float(job.get("s", 10))
    E = float(job.get("energy", 0.0))
    Bs = [float(b) for b in job.get("B", [d.B])]
    o = job.get("options", {}) or {}
    opt = D.Options(cap_width_nm=float(o.get("cap_width_nm", 0) or 0),
                    cap_strength=float(o.get("cap_strength", 0) or 0),
                    absorbing_edges=o.get("absorbing_edges"),
                    rebuild_junctions=bool(o.get("rebuild_junctions", True)))
    mp = job.get("maps") or {}
    gx, gy = int(mp.get("gx", 0) or 0), int(mp.get("gy", 0) or 0)
    map_at = [float(b) for b in mp.get("at", [])]
    kinds = mp.get("kinds", ["density"])

    t0 = time.time()
    # semiclassical first (seconds): transim's own tracer on the same deck and fields; its trajectory grid
    # then becomes the grid of the quantum maps, so the two overlay cell for cell
    sc = job.get("semiclassical") or {}
    if sc.get("on", True):
        from qtrans import semiclassical
        emit(t="log", msg="semiclassical: transim tracer, %d trajectories per field" % int(sc.get("nTraj", 200000)))
        try:
            for r in semiclassical.run(job["deck"], Bs, n_traj=int(sc.get("nTraj", 200000)), traj_res=gx or None):
                if gx:
                    gx, gy = r["gx"], r["gy"]
                keep = any(abs(r["B"] - b) < 1e-12 for b in map_at)
                emit(t="classical", B=r["B"], T=r["T"], launched=r["launched"], gx=r["gx"], gy=r["gy"],
                     rowZero="bottom", d=r["d"] if keep else None)
        except Exception as e:
            emit(t="log", msg="semiclassical run failed: %s" % e)

    emit(t="log", msg="building %s at s = %g" % (d.name, s))
    dev = D.build_device(d, s=s, opt=opt, magnetic=True)
    roles = {c.id: c.role for c in d.contacts}
    src = [i for i, cid in enumerate(dev.leads) if roles[cid] == "source"]
    if not src:
        raise ValueError("the deck has no source contact")
    j0 = src[0]
    emit(t="built", sites=dev.n_sites, leads=dev.leads, sides=dev.lead_sides,
         roles=[roles[c] for c in dev.leads], notes=dev.notes, secs=dev.build_s, peakMB=peak_mb())

    for i, B in enumerate(Bs):
        t1 = time.time()
        want_map = gx > 0 and any(abs(B - b) < 1e-12 for b in map_at)
        r = D.solve(dev, B=B, energy=E, wavefunction_from=j0 if want_map else None)
        N0 = r["N"][j0]
        T = {dev.leads[k]: r["T"][k][j0] / N0 if N0 else 0.0 for k in range(len(dev.leads)) if k != j0}
        emit(t="point", i=i, B=B, N=N0, T=T, R=r["T"][j0][j0] / N0 if N0 else 0.0,
             absorbed=r["absorbed"][j0], secs=time.time() - t1, peakMB=peak_mb())
        if want_map:
            psi = r["psi"]
            if "density" in kinds:
                m = output.density_map(dev, psi, gx, gy)
                emit(t="map", B=B, kind="density", gx=gx, gy=gy, rowZero="bottom",
                     data=[float("%.4g" % v) for v in m.ravel()])
            if "current" in kinds:
                jx, jy = output.current_map(dev, psi, dev.params(B), gx, gy)
                emit(t="map", B=B, kind="current", gx=gx, gy=gy, rowZero="bottom",
                     jx=[float("%.4g" % v) for v in jx.ravel()], jy=[float("%.4g" % v) for v in jy.ravel()])
    emit(t="done", secs=time.time() - t0, peakMB=peak_mb())


def main():
    try:
        job = json.loads(sys.stdin.read())
        if job.get("kind") == "preview":
            preview(job)
        else:
            run(job)
    except Exception as e:  # report, never die silently
        emit(t="error", msg="%s: %s" % (type(e).__name__, e), trace=traceback.format_exc()[-2000:])
        sys.exit(1)


if __name__ == "__main__":
    main()
