"""Gauge check that needs no reference code: around every hexagon of the finalized system the product of
hopping phases must be exp(-i (e/hbar) B A_hex) (counter-clockwise loop, electron charge -e), with
A_hex = (3 sqrt 3 / 2) a_cc^2. A wrong Peierls phase anywhere -- including where the gauge function
Lambda switches, at lead mouths, or around holes -- shows up as a wrong flux in some hexagon."""
import math

import numpy as np


def hexagon_flux_errors(dev, params, B_k):
    """Return (n_hexagons, max |flux error| in rad) for the finalized system's complete hexagons."""
    syst = dev.syst
    H = syst.hamiltonian_submatrix(params=params, sparse=True).tocsr()
    pos = np.array([s.pos for s in syst.sites])
    acc = dev.g.acc
    key = lambda p: (int(round(p[0] / acc * 1000)), int(round(p[1] / acc * 1000)))
    index = {key(p): i for i, p in enumerate(pos)}
    area = 1.5 * math.sqrt(3) * acc ** 2
    want = -B_k * area
    # hexagon vertices sit at angles 30 + 60 k deg from the centre (bonds are vertical in this lattice);
    # every site is a vertex of up to three hexagons, centres at the site minus those vertex offsets
    ang = [math.radians(30 + 60 * k) for k in range(6)]
    off = [(acc * math.cos(a), acc * math.sin(a)) for a in ang]
    seen, worst, n = set(), 0.0, 0
    for p in pos:
        for (ox, oy) in off:
            c = (p[0] - ox, p[1] - oy)
            ck = key(c)
            if ck in seen:
                continue
            seen.add(ck)
            idx = [index.get(key((c[0] + vx, c[1] + vy))) for (vx, vy) in off]
            if any(i is None for i in idx):
                continue
            prod = 1.0 + 0j
            ok = True
            for k in range(6):
                a, b = idx[(k + 1) % 6], idx[k]       # hop b -> a, counter-clockwise
                h = H[a, b]
                if h == 0:
                    ok = False
                    break
                prod *= h / -dev.g.t
            if not ok:
                continue
            err = (math.atan2(prod.imag, prod.real) - want + math.pi) % (2 * math.pi) - math.pi
            worst = max(worst, abs(err))
            n += 1
    return n, worst
