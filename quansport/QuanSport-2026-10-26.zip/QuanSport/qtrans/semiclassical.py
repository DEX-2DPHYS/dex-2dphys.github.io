"""transim's semiclassical tracer on a deck, through tsim (tsim/tsim.cpp #includes the live transim core).

tsim is built on first use (g++, WinLibs) into %LOCALAPPDATA%\\QuanSport\\bin and rebuilt when tsim.cpp or
transim's plugin.cpp changes."""
import glob
import json
import os
import subprocess
import tempfile

try:
    from . import paths
except ImportError:  # loaded as a plain module
    import paths

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TRANSIM = paths.TRANSIM
SRC = os.path.join(ROOT, "tsim", "tsim.cpp")
BIN_DIR = os.path.join(os.environ.get("LOCALAPPDATA", tempfile.gettempdir()), "QuanSport", "bin")
EXE = os.path.join(BIN_DIR, "tsim.exe" if os.name == "nt" else "tsim")


def _gpp():
    cands = ["g++"] + glob.glob(os.path.expandvars(
        r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\BrechtSanders.WinLibs*\mingw64\bin\g++.exe"))
    for c in cands:
        try:
            subprocess.run([c, "--version"], capture_output=True, check=True)
            return c
        except Exception:
            pass
    return None


def ensure_built():
    """Build tsim if it is missing or older than its sources. Returns the exe path."""
    shipped = paths.prebuilt("tsim")  # a downloaded package carries it, built from its own sources
    if shipped:
        return shipped
    plugin = os.path.join(TRANSIM, "src", "plugin.cpp")
    if os.path.exists(EXE) and os.path.getmtime(EXE) >= max(os.path.getmtime(SRC), os.path.getmtime(plugin)):
        return EXE
    gpp = _gpp()
    if gpp is None:
        raise RuntimeError("g++ not found: needed once to build transim's tracer (tsim) for the side-by-side view")
    os.makedirs(BIN_DIR, exist_ok=True)
    # never -ffast-math: it removes transim's isfinite guards (transim build rule)
    r = subprocess.run([gpp, "-std=c++17", "-O3", "-fno-fast-math", "-fopenmp", "-static", "-I", os.path.join(TRANSIM, "src"),
                        "-o", EXE, SRC], capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError("building tsim failed:\n" + r.stderr[-3000:])
    return EXE


def messages(deck_dict):
    """The messages transim's panel sends when it opens this project file."""
    p = dict(deck_dict.get("params") or {})
    p.pop("t", None)
    lines = [json.dumps({"t": "configure", **p})]
    cs = deck_dict.get("contacts") or []
    lines.append(json.dumps({"t": "contacts", "data": ";".join(
        "%s|%s|%.17g|%.17g|%.17g|%.17g" % (c["id"], c["role"], c["x0"], c["y0"], c["x1"], c["y1"]) for c in cs)}))
    maps = deck_dict.get("maps") or {}
    for kind in ("density", "mobility"):
        m = maps.get(kind)
        if m and m.get("w") and m.get("h") and isinstance(m.get("data"), list) and len(m["data"]) == m["w"] * m["h"]:
            lines.append(json.dumps({"t": "map", "kind": kind, "w": m["w"], "h": m["h"], "data": m["data"]}))
    return lines


def run(deck_dict, Bs, n_traj=200000, traj_res=None):
    """Yields one dict per field: {B, launched, gx, gy, T: {id: fraction}, d: [...]}.
    traj_res sets the number of trajectory-map cells along x (transim's trajRes)."""
    exe = ensure_built()
    d = json.loads(json.dumps(deck_dict))
    if traj_res:
        d.setdefault("params", {})["trajRes"] = int(traj_res)
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as f:
        f.write("\n".join(messages(d)) + "\n")
        path = f.name
    try:
        p = subprocess.Popen([exe, path, ",".join("%.9g" % b for b in Bs), str(int(n_traj))],
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        for line in p.stdout:
            if line.startswith("{"):
                yield json.loads(line)
        err = p.stderr.read()
        if p.wait():
            raise RuntimeError("tsim failed: " + err[-2000:])
    finally:
        os.remove(path)
