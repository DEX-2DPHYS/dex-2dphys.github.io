"""Small synthetic transim decks for gates and tests (same format transim writes)."""
from .deck import parse


def make_deck(W_um, H_um, contacts, n_cm2=1e12, B=0.0, edge="specular", pn_width_nm=0.0,
              density=None, name="synthetic"):
    """contacts: list of (id, role, x0, y0, x1, y1) in fractional coordinates.
    density: optional (w, h, data_row0_top) in cm^-2."""
    d = {"format": "transim-project", "version": 1, "name": name,
         "params": {"W_um": W_um, "H_um": H_um, "n_cm2": n_cm2, "B": B, "edge": edge,
                    "pnWidth_nm": pn_width_nm, "pnMode": "klein"},
         "contacts": [{"id": c[0], "role": c[1], "x0": c[2], "y0": c[3], "x1": c[4], "y1": c[5]} for c in contacts],
         "maps": {"density": None, "mobility": None}}
    if density is not None:
        w, h, data = density
        d["maps"]["density"] = {"w": w, "h": h, "data": [float(v) for v in data], "min": min(data), "max": max(data)}
    return parse(d, name)
