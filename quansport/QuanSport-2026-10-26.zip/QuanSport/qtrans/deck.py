"""Read transim project files (.transim.json, "format": "transim-project", version 1).

Geometry conventions follow transim/src/plugin.cpp exactly:
- contacts are rectangles in FRACTIONAL coordinates (x0, y0, x1, y1 in 0..1 of W and H), y up;
- a "reflector" is the ellipse inscribed in its rectangle, a "wall" is the rectangle itself;
- a density map is sampled bilinearly with ROW 0 AT THE TOP (FieldMap::sample);
- map values are absolute densities in cm^-2; with no map the uniform params.n_cm2 applies.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field

import numpy as np

ROLES = ("source", "drain", "probe", "absorber", "reflector", "wall")


@dataclass
class Contact:
    id: str
    role: str
    x0: float
    y0: float
    x1: float
    y1: float

    def contains(self, xf: float, yf: float) -> bool:
        """inContact(): closed rectangle in fractional coordinates."""
        return self.x0 <= xf <= self.x1 and self.y0 <= yf <= self.y1

    def is_obstacle(self) -> bool:
        return self.role in ("reflector", "wall")

    def in_obstacle(self, xf: float, yf: float) -> bool:
        """inObstacle(): a wall is its rectangle, a reflector the inscribed ellipse."""
        if self.role == "wall":
            return self.contains(xf, yf)
        if self.role != "reflector":
            return False
        ax, ay = 0.5 * (self.x1 - self.x0), 0.5 * (self.y1 - self.y0)
        if ax <= 0 or ay <= 0:
            return False
        u = (xf - 0.5 * (self.x0 + self.x1)) / ax
        v = (yf - 0.5 * (self.y0 + self.y1)) / ay
        return u * u + v * v <= 1

    def to_json(self) -> dict:
        return {"id": self.id, "role": self.role, "x0": self.x0, "y0": self.y0, "x1": self.x1, "y1": self.y1}


@dataclass
class FieldMap:
    """FieldMap: w x h floats, row 0 = top of the image. Values as stored (density: cm^-2)."""
    w: int
    h: int
    data: np.ndarray  # shape (h, w), float32 like transim's std::vector<float>
    vmin: float | None = None
    vmax: float | None = None
    src: dict | None = None  # the map as read, written back unchanged if data is untouched

    @classmethod
    def from_json(cls, m: dict | None) -> "FieldMap | None":
        if not m or not m.get("w") or not m.get("h"):
            return None
        w, h = int(m["w"]), int(m["h"])
        d = m.get("data")
        if not isinstance(d, list) or len(d) != w * h:
            return None  # transim's apply() drops such a map too
        arr = np.asarray(d, dtype=np.float32).reshape(h, w)
        return cls(w, h, arr, m.get("min"), m.get("max"), m)

    def sample(self, xf, yf):
        """Bilinear sample, vectorised. Same arithmetic order as FieldMap::sample (double
        precision on float32 data), so results agree with the C++ to rounding."""
        xf = np.clip(np.asarray(xf, dtype=float), 0.0, 1.0)
        yf = np.clip(np.asarray(yf, dtype=float), 0.0, 1.0)
        x = xf * (self.w - 1)
        y = (1.0 - yf) * (self.h - 1)
        i0 = np.floor(x).astype(int)
        j0 = np.floor(y).astype(int)
        i1 = np.minimum(i0 + 1, self.w - 1)
        j1 = np.minimum(j0 + 1, self.h - 1)
        fx, fy = x - i0, y - j0
        v = self.data.astype(float)
        a = v[j0, i0] * (1 - fx) + v[j0, i1] * fx
        b = v[j1, i0] * (1 - fx) + v[j1, i1] * fx
        return a * (1 - fy) + b * fy

    def to_json(self) -> dict:
        # transim holds maps as float32; writing those back would turn 1e12 into 999999995904
        # and change the file, so an untouched map returns its original values
        if self.src is not None and np.array_equal(
                self.data, np.asarray(self.src["data"], dtype=np.float32).reshape(self.h, self.w)):
            return dict(self.src)
        out = {"w": self.w, "h": self.h, "data": [float(x) for x in self.data.ravel()]}
        if self.vmin is not None:
            out["min"] = self.vmin
        if self.vmax is not None:
            out["max"] = self.vmax
        return out


@dataclass
class Deck:
    name: str
    W_um: float
    H_um: float
    n_cm2: float
    B: float
    pn_width_nm: float
    pn_mode: str
    contacts: list[Contact]
    density: FieldMap | None
    params: dict = field(default_factory=dict)  # everything, verbatim
    raw: dict = field(default_factory=dict)      # the whole file, verbatim
    sha256: str = ""

    # --- geometry -------------------------------------------------------------------
    def density_cm2(self, x_um, y_um):
        """Signed density (cm^-2) at device coordinates in um (x right, y up)."""
        x_um = np.asarray(x_um, dtype=float)
        if self.density is None:
            return np.full(np.shape(x_um), float(self.n_cm2))
        return self.density.sample(x_um / self.W_um, np.asarray(y_um, dtype=float) / self.H_um)

    def obstacle(self, x_um: float, y_um: float) -> bool:
        xf, yf = x_um / self.W_um, y_um / self.H_um
        return any(c.in_obstacle(xf, yf) for c in self.contacts)

    def by_role(self, role: str) -> list[Contact]:
        return [c for c in self.contacts if c.role == role]

    def summary(self) -> str:
        roles = {}
        for c in self.contacts:
            roles[c.role] = roles.get(c.role, 0) + 1
        dm = "uniform %.3g cm^-2" % self.n_cm2 if self.density is None else \
            "map %dx%d [%.3g, %.3g]" % (self.density.w, self.density.h, self.density.data.min(), self.density.data.max())
        return "%s: %g x %g um, B %g T, pn %s/%g nm, %s, density %s" % (
            self.name, self.W_um, self.H_um, self.B, self.pn_mode, self.pn_width_nm,
            ", ".join("%d %s" % (n, r) for r, n in roles.items()), dm)

    def to_json(self) -> dict:
        """Back to a transim-project dict: the original with contacts and density re-written."""
        out = dict(self.raw)
        out["contacts"] = [c.to_json() for c in self.contacts]
        maps = dict(out.get("maps") or {})
        maps["density"] = self.density.to_json() if self.density is not None else None
        out["maps"] = maps
        return out


def _canonical(o):
    """Numbers as floats, so 0 and 0.0 hash alike: the hash identifies the device, not its spelling."""
    if isinstance(o, bool) or o is None or isinstance(o, str):
        return o
    if isinstance(o, (int, float)):
        return float(o)
    if isinstance(o, dict):
        return {k: _canonical(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_canonical(v) for v in o]
    return o


def deck_hash(d: dict) -> str:
    """sha256 of the canonical deck, without the save timestamp."""
    c = _canonical({k: v for k, v in d.items() if k != "saved"})
    return hashlib.sha256(json.dumps(c, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _num(p: dict, key: str, default: float) -> float:
    v = p.get(key, default)
    try:
        v = float(v)
    except (TypeError, ValueError):
        return default
    return v if math.isfinite(v) else default


def parse(d: dict, name: str = "") -> Deck:
    if not isinstance(d, dict) or d.get("format") != "transim-project":
        raise ValueError("not a transim project file")
    if int(d.get("version", 1)) != 1:
        raise ValueError("unsupported transim-project version %r" % d.get("version"))
    p = dict(d.get("params") or {})
    contacts = []
    for i, c in enumerate(d.get("contacts") or []):
        role = str(c.get("role", ""))
        if role not in ROLES:
            raise ValueError("contact %d has unknown role %r" % (i, role))
        contacts.append(Contact(str(c.get("id", "c%d" % i)), role,
                                float(c["x0"]), float(c["y0"]), float(c["x1"]), float(c["y1"])))
    maps = d.get("maps") or {}
    return Deck(
        name=str(d.get("name") or name or "deck"),
        W_um=max(0.2, _num(p, "W_um", 4.0)),   # Params::W() clamps to 0.2 um
        H_um=max(0.2, _num(p, "H_um", 2.0)),
        n_cm2=_num(p, "n_cm2", 1e12),
        B=_num(p, "B", 0.0),
        pn_width_nm=_num(p, "pnWidth_nm", 0.0),
        pn_mode=str(p.get("pnMode", "klein")),
        contacts=contacts,
        density=FieldMap.from_json(maps.get("density")),
        params=p,
        raw=d,
        sha256=deck_hash(d),
    )


def load(path: str) -> Deck:
    with open(path, encoding="utf-8") as f:
        d = json.load(f)
    import os
    return parse(d, os.path.basename(path).replace(".transim.json", ""))
