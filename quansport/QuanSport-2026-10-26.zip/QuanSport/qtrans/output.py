"""Quantum maps binned onto transim's trajectory grid, so classical and quantum maps overlay pixel
for pixel. Grid: gx x gy cells over the W x H device, row 0 = BOTTOM (as transim's trajectory
density, which is indexed iy * gx + ix with y up)."""
import numpy as np
import kwant


def bin_sites(pos_nm, values, W_nm, H_nm, gx, gy):
    """Sum `values` of sites into gx x gy cells; returns array (gy, gx), row 0 = bottom."""
    ix = np.clip((pos_nm[:, 0] / W_nm * gx).astype(int), 0, gx - 1)
    iy = np.clip((pos_nm[:, 1] / H_nm * gy).astype(int), 0, gy - 1)
    # Handle complex values
    dtype = np.result_type(values.dtype, np.float64)
    out = np.zeros(gy * gx, dtype=dtype)
    np.add.at(out, iy * gx + ix, values)
    return out.reshape(gy, gx)


def density_map(dev, psi, gx, gy):
    """Density of the scattering states injected from one lead, summed over its modes, binned.
    Only the device itself; the absorbing frame outside it is left out."""
    pos = np.array([s.pos for s in dev.syst.sites])
    rho = np.sum(np.abs(psi) ** 2, axis=0)
    W, H = dev.deck.W_um * 1e3, dev.deck.H_um * 1e3
    keep = (pos[:, 0] >= 0) & (pos[:, 0] <= W) & (pos[:, 1] >= 0) & (pos[:, 1] <= H)
    return bin_sites(pos[keep], rho[keep], W, H, gx, gy)


def current_map(dev, psi, params, gx, gy):
    """Particle current of the injected states, as (jx, jy) binned at bond midpoints.

    Bond current from site j to site i: J_ij = 2 Im(psi_i^* H_ij psi_j) (units of 1/hbar), summed over
    the modes; only off-diagonal H enters, so the absorbing (imaginary, on-site) potential does not.
    Each bond appears as (i, j) and (j, i) with opposite J and opposite direction, i.e. the same
    vector, hence the factor 1/2. Sites outside the device (absorbing frame) are not binned."""
    H = dev.syst.hamiltonian_submatrix(params=params, sparse=True).tocoo()
    off = H.row != H.col
    i, j, h = H.row[off], H.col[off], H.data[off]
    pos = np.array([s.pos for s in dev.syst.sites])
    J = np.zeros(len(i))
    for mode in psi:
        J += 2 * np.imag(np.conj(mode[i]) * h * mode[j])
    J = np.real(J)  # Ensure J is real (current is always real)
    d = pos[i] - pos[j]
    vec = J[:, None] * d / np.linalg.norm(d, axis=1)[:, None] * 0.5
    mid = 0.5 * (pos[i] + pos[j])
    W, H_ = dev.deck.W_um * 1e3, dev.deck.H_um * 1e3
    keep = (mid[:, 0] >= 0) & (mid[:, 0] <= W) & (mid[:, 1] >= 0) & (mid[:, 1] <= H_)
    jx = bin_sites(mid[keep], vec[keep, 0], W, H_, gx, gy)
    jy = bin_sites(mid[keep], vec[keep, 1], W, H_, gx, gy)
    return jx, jy
