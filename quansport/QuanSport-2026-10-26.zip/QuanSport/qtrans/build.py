"""Tight-binding builders.

ribbon_y(): a strip periodic along x (twisted boundary condition, Bloch phase `phase` per period),
transport along y, potential U(y). Junction lines are along x = ZIGZAG lines, so a sharp step
keeps the two valleys apart (they sit at different k_x). Used by the Klein gate.

Note (2026-10-21): kwant.wraparound with leads gave T != 1 for a UNIFORM strip on this lattice
(depending on the strip length), so the periodic boundary is built by hand here: the same
twisted hoppings in the system and in both leads. The period must be >= 2 cells: with one cell
the two neighbours across the boundary are the same site. With two cells (period 2A) the valleys
sit at Bloch phases 4pi/3 (K) and 2pi/3 (K'), so a phase near 4pi/3 selects one valley.
"""
import cmath
import math

import kwant

from .model import Graphene

K_PHASE = 2 * math.pi / 3     # Dirac point of one valley, as a Bloch phase per lattice constant A


def _twist_x(B, lat, ncell, t):
    """Close builder B periodically along x with period ncell * A: every nearest-neighbour bond
    that leaves the strip is re-attached to the image site, carrying exp(i phase m) for a
    crossing of m periods (parameter `phase`)."""
    shift = (ncell, 0)          # tag shift of one period: ncell primitive vectors a1 = (A, 0)
    kinds = lat.neighbors()
    added = 0
    mine = set()                # twisted bonds already placed (each is met from both ends)
    for s in list(B.sites()):
        for hk in kinds:
            # a HoppingKind(delta, a, b) links site b(tag) -> a(tag + delta)
            for (fam_a, fam_b, sign) in ((hk.family_a, hk.family_b, 1), (hk.family_b, hk.family_a, -1)):
                if s.family != fam_b:
                    continue
                tag = tuple(x + sign * d for x, d in zip(s.tag, hk.delta))
                tgt = fam_a(*tag)
                if tgt in B:
                    continue
                for m in (1, -1):
                    img = fam_a(tag[0] - m * shift[0], tag[1] - m * shift[1])
                    if img in B and s != img:
                        key = tuple(B.symmetry.to_fd(img, s))   # the same bond under a lead's translation
                        if key in mine:
                            break
                        if (img, s) in B or (s, img) in B:
                            # with a one-cell period both neighbours across the boundary are the
                            # same site; overwriting the plain bond silently removed it (G2 bug)
                            raise ValueError("twisted bond would overwrite an existing bond: use ncell >= 2")
                        # tgt = img + m * period: psi(tgt) = e^{i m phase} psi(img)
                        B[img, s] = (lambda mm: (lambda a, b, phase: -t * cmath.exp(1j * mm * phase)))(m)
                        mine.add(key)
                        mine.add(tuple(B.symmetry.to_fd(s, img)))
                        added += 1
                        break
    return added


def ribbon_y(g: Graphene, U_of_y, y0, y1, U_bottom, U_top, ncell=2):
    """Periodic strip (period ncell * A along x) for y in [y0, y1), leads below (U_bottom) and
    above (U_top). Parameter: `phase` = Bloch phase per period."""
    lat = g.lattice()
    vy = lat.vec((-1, 2))                    # (0, sqrt(3) A)
    W = ncell * g.A
    inside = lambda p: 0 <= p[0] < W - 1e-9

    syst = kwant.Builder()
    syst[lat.shape(lambda p: inside(p) and y0 <= p[1] < y1, (0.1 * g.A, 0.5 * (y0 + y1)))] = \
        lambda site: float(U_of_y(site.pos[1]))
    syst[lat.neighbors()] = -g.t
    _twist_x(syst, lat, ncell, g.t)

    def lead(sign, U):
        ld = kwant.Builder(kwant.TranslationalSymmetry(sign * vy))
        ld[lat.shape(lambda p: inside(p), (0.1 * g.A, 0))] = U
        ld[lat.neighbors()] = -g.t
        _twist_x(ld, lat, ncell, g.t)
        return ld

    syst.attach_lead(lead(-1, U_bottom))
    syst.attach_lead(lead(+1, U_top))
    return syst.finalized()


def phase_for_angle(g: Graphene, theta, kF, ncell=2):
    """Bloch phase per period giving incidence angle theta (from the junction normal, the y axis)
    for Fermi wavevector kF, measured from the Dirac point K."""
    return ncell * (K_PHASE + kF * math.sin(theta) * g.A)
