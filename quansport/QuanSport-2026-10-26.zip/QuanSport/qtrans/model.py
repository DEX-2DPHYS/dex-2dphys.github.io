"""Scalable tight-binding graphene (Liu et al., PRL 114, 036601 (2015)).

a_s = s a0, t_s = t0 / s, so v_F = 3 t a / (2 hbar) is unchanged and the Dirac physics at a given
density is kept while s a0 << lambda_F.  Lengths in nm, energies in eV, B in tesla.

Lattice: kwant.lattice.honeycomb with lattice constant A = sqrt(3) a_s; its default orientation has
the C-C bonds along y, so edges and junction lines along x are ZIGZAG and along y ARMCHAIR.
"""
from dataclasses import dataclass
import math

import numpy as np
import kwant

HBAR_EVS = 6.582119569e-16      # eV s
E_CHARGE = 1.602176634e-19      # C
HBAR_JS = 1.054571817e-34       # J s
E_OVER_HBAR_NM2 = E_CHARGE / HBAR_JS * 1e-18   # e/hbar in 1/(T nm^2)


@dataclass
class Graphene:
    s: float = 20.0          # scaling factor
    t0: float = 2.7          # eV
    a0: float = 0.142        # nm, C-C distance

    @property
    def acc(self):           # scaled C-C distance (nm)
        return self.s * self.a0

    @property
    def A(self):             # scaled lattice constant (nm)
        return math.sqrt(3) * self.acc

    @property
    def t(self):             # scaled hopping (eV)
        return self.t0 / self.s

    @property
    def vF(self):            # m/s, independent of s
        return 3 * self.t0 * self.a0 * 1e-9 / (2 * HBAR_EVS)

    @property
    def hvF(self):           # hbar v_F in eV nm
        return HBAR_EVS * self.vF * 1e9

    def lattice(self):
        return kwant.lattice.honeycomb(a=self.A, norbs=1)

    # --- density <-> potential (E_F = 0) ------------------------------------------------
    def kF_signed(self, n_cm2):
        """Signed Fermi wavevector (1/nm): + on an electron side, - on a hole side."""
        n = np.asarray(n_cm2, dtype=float) * 1e-14       # cm^-2 -> nm^-2
        return np.sign(n) * np.sqrt(np.pi * np.abs(n))

    def U_of_k(self, k_signed):
        """On-site energy (eV) that puts the local Dirac point at -hbar v_F k: E_F = 0 is then
        k above it (electrons, k > 0) or |k| below it (holes, k < 0)."""
        return -self.hvF * np.asarray(k_signed, dtype=float)

    def U_of_n(self, n_cm2):
        return self.U_of_k(self.kF_signed(n_cm2))

    def check_U(self, U, frac=0.5):
        """Largest |U| the scaled band supports with a near-linear cone. Raises with the reason."""
        Umax = float(np.max(np.abs(U))) if np.size(U) else 0.0
        if Umax > frac * 3 * self.t:
            raise ValueError(
                "potential |U| = %.3g eV exceeds %.0f%% of the scaled band (3 t_s = %.3g eV at s = %g): "
                "lower s or the density; metal-like densities need their own model" % (
                    Umax, 100 * frac, 3 * self.t, self.s))
        return Umax

    def summary(self, n_cm2=1e12):
        k = float(abs(self.kF_signed(n_cm2)))
        return ("s=%g: a_s=%.3f nm, A=%.3f nm, t_s=%.4f eV, v_F=%.4g m/s, at n=%.3g: k_F=%.4f /nm, "
                "lambda_F=%.2f nm, k_F a_s=%.2f, E_F=%.4f eV = %.2f t_s" % (
                    self.s, self.acc, self.A, self.t, self.vF, n_cm2, k, 2 * math.pi / k,
                    k * self.acc, self.hvF * k, self.hvF * k / self.t))
