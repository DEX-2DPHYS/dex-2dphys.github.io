"""Build a Kwant tight-binding system from a transim deck (qtrans.deck.Deck).

Coordinates: nm, origin at the device's bottom-left corner, x right, y up (transim's convention,
fractional contact rectangles scaled by W and H).

- sites: the W x H rectangle minus reflectors (inscribed ellipses) and walls (rectangles); dangling
  sites removed so every cut edge is zigzag/armchair, never bearded (G0 finding);
- on-site potential U(r) = -hbar v_F k_F(r) (E_F = 0), from the density map; where the map changes
  sign the junction is REBUILT from its n = 0 contour with Cayssol's profile of width pnWidth_nm
  (the map's own ramp is a tracer convenience, not physics);
- leads: one semi-infinite graphene lead per source / drain / probe contact on a device edge,
  perpendicular to that edge, with the contact's width and the potential at the contact;
- absorbers (inside) and, for edge == "absorbing", a frame OUTSIDE the free edges: a complex absorbing potential -i eta(r),
  quadratic in the depth, so the system is non-Hermitian on purpose (check_hermiticity=False);
- magnetic field (uniform B along +z, electron charge -e): Peierls phases in closed form.
  Landau gauge A = (-B y, 0) everywhere, plus the gauge transformation Lambda = B x y in the mouth
  of every top/bottom lead (and in those leads), so A = (0, B x) there. Each lead sees a gauge that
  is invariant along its own axis, and since a gauge transformation adds exactly Lambda_i - Lambda_j
  to a hop's phase, the field stays uniform however abruptly Lambda switches.
  (kwant.physics.magnetic_gauge took 6 s + 22 s per field on 15 k sites and grew faster than
  linearly: unusable at 1e6 sites.) Proof of correctness: qtrans.gaugecheck (every hexagon carries
  e B A/hbar) and the quantum-Hall check in tests/g2_device.py.
"""
from __future__ import annotations

import cmath
import math
import time
from dataclasses import dataclass, field

import numpy as np
import kwant
from scipy import ndimage

from .deck import Deck
from .klein import profile_k
from .model import Graphene, E_OVER_HBAR_NM2


@dataclass
class Options:
    cap_width_nm: float = 0.0        # 0 = 3 lambda_F at the deck density
    cap_strength: float = 0.0        # eta at full depth (eV); 0 = E_F / 2 (G2b: 2 E_F reflected 2e-3)
    junction_grid_nm: float = 0.0    # grid for the n = 0 contour; 0 = min(1 nm, a_s / 2)
    rebuild_junctions: bool = True   # False: use the map's own values everywhere
    edge_tol: float = 1e-6           # fractional tolerance for "the contact touches this edge"
    absorbing_edges: list | None = None  # override: which free edges get the CAP (None = from the deck)


@dataclass
class Device:
    g: Graphene
    deck: Deck
    syst: kwant.system.FiniteSystem
    leads: list = field(default_factory=list)          # contact ids, in Kwant lead order
    lead_sides: list = field(default_factory=list)
    n_sites: int = 0
    build_s: float = 0.0
    notes: list = field(default_factory=list)
    magnetic: bool = True

    def params(self, B=0.0):
        """Kwant params for field B (tesla): Bk = e B / hbar in 1/nm^2."""
        return {"Bk": B * E_OVER_HBAR_NM2} if self.magnetic else {}


# --- potential ---------------------------------------------------------------------------

def potential_function(deck: Deck, g: Graphene, opt: Options, notes: list):
    """Return U(x_nm, y_nm) (vectorised) for the deck."""
    Wn, Hn = deck.W_um * 1e3, deck.H_um * 1e3

    def k_map(x, y):
        return g.kF_signed(deck.density_cm2(np.asarray(x) / 1e3, np.asarray(y) / 1e3))

    if deck.density is None:
        kk = float(g.kF_signed(deck.n_cm2))
        return lambda x, y: np.full(np.shape(x), float(g.U_of_k(kk)))

    data = deck.density.data
    sign_change = data.min() < 0 < data.max()
    if not sign_change or not opt.rebuild_junctions or deck.pn_mode == "pass":
        if sign_change:
            notes.append("junctions taken from the map's own ramp (no rebuild)")
        return lambda x, y: g.U_of_k(k_map(x, y))

    # signed distance to the n = 0 contour of the (bilinear) map, on a fine grid
    h = opt.junction_grid_nm or min(1.0, 0.5 * g.acc)
    nx, ny = int(math.ceil(Wn / h)) + 1, int(math.ceil(Hn / h)) + 1
    xs, ys = np.linspace(0, Wn, nx), np.linspace(0, Hn, ny)
    X, Y = np.meshgrid(xs, ys)                      # shape (ny, nx), row 0 = y = 0 (bottom)
    n = deck.density_cm2(X / 1e3, Y / 1e3)
    pos = n >= 0
    hx, hy = xs[1] - xs[0], ys[1] - ys[0]
    d_in = ndimage.distance_transform_edt(pos, sampling=(hy, hx))     # in n regions: distance to p
    d_out = ndimage.distance_transform_edt(~pos, sampling=(hy, hx))   # in p regions: distance to n
    # half a cell puts the contour between the two grid points it separates
    sd = np.where(pos, d_in - 0.5 * min(hx, hy), -(d_out - 0.5 * min(hx, hy)))
    # near the contour the transform is only good to a grid cell; the map's own first-order distance
    # n / |grad n| is sub-grid accurate there (G2e: a 2.5 nm junction is so steep that 0.35 nm matters)
    gy_, gx_ = np.gradient(n, hy, hx)
    gn = np.hypot(gx_, gy_)
    lin = np.where(gn > 0, n / np.where(gn > 0, gn, 1.0), sd)
    near = (np.abs(sd) < 2.5 * max(hx, hy)) & (np.abs(lin) < 2.5 * max(hx, hy)) & (np.sign(lin) == np.sign(sd))
    sd = np.where(near, lin, sd)

    d = max(0.0, deck.pn_width_nm)
    pix = max(Wn / max(1, deck.density.w - 1), Hn / max(1, deck.density.h - 1))
    # Two different distances (merging them made a 0.5 um device with d = 40 nm find NO plateau, i.e.
    # U = 0 everywhere): plateaus are read beyond the map's own ramp (a few map pixels, plus a few
    # lattice constants); the Cayssol profile replaces the map within 8 d of the contour.
    ramp_guard = max(3 * pix, 4 * g.acc)
    far_n = sd > ramp_guard
    far_p = sd < -ramp_guard
    if not far_n.any() or not far_p.any():
        raise ValueError("cannot read the n and p plateau densities: no part of the map lies more than %.0f nm "
                         "from its n = 0 contour on one side" % ramp_guard)
    # plateau = a high percentile of |n| on each side (a median also counts the map's ramp)
    pn, pp = float(np.percentile(n[far_n], 95)), float(np.percentile(-n[far_p], 95))
    kn, kp = float(np.sqrt(np.pi * pn * 1e-14)), float(np.sqrt(np.pi * pp * 1e-14))
    # how far the map's own ramp reaches: the typical distance at which |n| is between 90 and 98 % of
    # its plateau (the 20 nm tanh of the DFM decks is still at 0.905 at 30 nm)
    tail = ((n > 0.9 * pn) & (n < 0.98 * pn)) | ((-n > 0.9 * pp) & (-n < 0.98 * pp))
    ramp98 = float(np.median(np.abs(sd[tail]))) if tail.any() else 0.0
    guard = max(ramp_guard, 1.5 * ramp98, 8 * d)
    notes.append("junction rebuilt from the n = 0 contour: d = %g nm, plateaus n %.3g / p %.3g cm^-2, "
                 "profile within %.0f nm, grid %.2f nm" % (d, kn * kn / math.pi * 1e14, -kp * kp / math.pi * 1e14, guard, h))
    sd_i = lambda x, y: ndimage.map_coordinates(sd, [np.asarray(y) / hy, np.asarray(x) / hx], order=1, mode="nearest")

    def U(x, y):
        x, y = np.asarray(x, float), np.asarray(y, float)
        s = sd_i(x, y)
        k_far = k_map(x, y)
        k_near = profile_k(s, -kp, kn, d)            # x < 0: p side (k < 0), x > 0: n side
        return g.U_of_k(np.where(np.abs(s) > guard, k_far, k_near))
    return U


# --- geometry helpers ----------------------------------------------------------------------

def _side(c, tol):
    """Which device edge a contact rectangle sits on."""
    if c.x0 <= tol:
        return "left"
    if c.x1 >= 1 - tol:
        return "right"
    if c.y0 <= tol:
        return "bottom"
    if c.y1 >= 1 - tol:
        return "top"
    return None


def build_device(deck: Deck, s: float = 10, opt: Options | None = None, magnetic: bool = True) -> Device:
    t_start = time.time()
    opt = opt or Options()
    g = Graphene(s=s)
    lat = g.lattice()
    Wn, Hn = deck.W_um * 1e3, deck.H_um * 1e3
    notes: list = []
    U = potential_function(deck, g, opt, notes)

    kF0 = abs(float(g.kF_signed(deck.n_cm2))) or 0.177
    lam = 2 * math.pi / kF0
    w_cap = opt.cap_width_nm or 3 * lam
    eta0 = opt.cap_strength or 0.5 * g.hvF * kF0

    contacts = deck.contacts
    obstacles = [c for c in contacts if c.is_obstacle()]
    absorbers = [c for c in contacts if c.role == "absorber"]
    terminals = [c for c in contacts if c.role in ("source", "drain", "probe")]

    # Absorbing edges (transim's edge = "absorbing"): an absorbing FRAME of width w_cap OUTSIDE the
    # device, quadratic in the depth, with a gap (the lead's own channel) wherever a lead attaches.
    # The device area itself is untouched, so a carrier is lost only once it reaches the edge, as in
    # transim. (A strip INSIDE the device swallowed a 20 nm emitter's wave within its first 100 nm:
    # quantum T 0.001 against transim's 0.12 on the mini Veselago dot.)
    edge_mode = str(deck.params.get("edge", "specular"))
    free_edges = ["left", "right", "bottom", "top"] if edge_mode == "absorbing" else []
    if opt.absorbing_edges is not None:
        free_edges = list(opt.absorbing_edges)
    lead_spans = []
    for c in terminals:
        side = _side(c, opt.edge_tol)
        if side is None:
            raise ValueError("contact %r (%s) does not touch a device edge; interior contacts are not "
                             "supported yet" % (c.id, c.role))
        lead_spans.append((c, side))
    ext = {e: (w_cap if e in free_edges else 0.0) for e in ("left", "right", "bottom", "top")}

    def in_channel(x, y):
        """The strip in front of a lead mouth, outside the device: left free for the lead."""
        for c, side in lead_spans:
            if side == "left" and x < 0 and c.y0 * Hn <= y <= c.y1 * Hn:
                return True
            if side == "right" and x > Wn and c.y0 * Hn <= y <= c.y1 * Hn:
                return True
            if side == "bottom" and y < 0 and c.x0 * Wn <= x <= c.x1 * Wn:
                return True
            if side == "top" and y > Hn and c.x0 * Wn <= x <= c.x1 * Wn:
                return True
        return False

    def inside(p):
        x, y = p
        if not (-ext["left"] <= x <= Wn + ext["right"] and -ext["bottom"] <= y <= Hn + ext["top"]):
            return False
        if 0 <= x <= Wn and 0 <= y <= Hn:
            xf, yf = x / Wn, y / Hn
            return not any(c.in_obstacle(xf, yf) for c in obstacles)
        return not in_channel(x, y)            # the absorbing frame

    def cap(x, y):
        x, y = np.asarray(x, float), np.asarray(y, float)
        dep = np.zeros(np.shape(x))
        for e in free_edges:
            out = {"left": -x, "right": x - Wn, "bottom": -y, "top": y - Hn}[e]
            dep = np.maximum(dep, np.clip(out / w_cap, 0, 1))
        eta = eta0 * dep ** 2
        xf, yf = x / Wn, y / Hn
        for a in absorbers:
            inn = (xf >= a.x0) & (xf <= a.x1) & (yf >= a.y0) & (yf <= a.y1)
            eta = np.where(inn, eta0, eta)
        return eta

    syst = kwant.Builder()
    syst[lat.shape(inside, (0.5 * Wn, 0.5 * Hn) if inside((0.5 * Wn, 0.5 * Hn)) else _any_inside(inside, Wn, Hn))] = 0.0
    sites = list(syst.sites())
    P = np.array([s_.pos for s_ in sites])
    Uv = U(P[:, 0], P[:, 1])
    g.check_U(Uv)
    Ev = Uv - 1j * cap(P[:, 0], P[:, 1])
    for s_, e in zip(sites, Ev):
        syst[s_] = complex(e) if e.imag else float(e.real)

    # gauge: Lambda = x y in the mouth of every top/bottom lead, 0 elsewhere (see module docstring)
    m = 2 * g.A
    mouths = [(c.x0 * Wn - m, c.x1 * Wn + m, side) for c, side in lead_spans if side in ("bottom", "top")]

    def lam_sys(x, y):
        for (xa, xb, side) in mouths:
            if xa <= x <= xb and ((side == "bottom" and y <= m) or (side == "top" and y >= Hn - m)):
                return x * y
        return 0.0

    if magnetic:
        syst[lat.neighbors()] = _peierls_hop(g.t, lam_sys)
    else:
        syst[lat.neighbors()] = -g.t
    syst.eradicate_dangling()

    # leads
    vx, vy = lat.vec((1, 0)), lat.vec((-1, 2))
    ids, sides = [], []
    for i, (c, side) in enumerate(lead_spans):
        cx, cy = 0.5 * (c.x0 + c.x1) * Wn, 0.5 * (c.y0 + c.y1) * Hn
        Ul = float(U(np.array([min(max(cx, 0.0), Wn)]), np.array([min(max(cy, 0.0), Hn)]))[0])
        if side in ("left", "right"):
            y0, y1 = c.y0 * Hn, c.y1 * Hn
            sym = kwant.TranslationalSymmetry(-vx if side == "left" else vx)
            shape = lambda p, y0=y0, y1=y1: y0 <= p[1] <= y1
            start = (0, 0.5 * (y0 + y1))
        else:
            x0, x1 = c.x0 * Wn, c.x1 * Wn
            sym = kwant.TranslationalSymmetry(-vy if side == "bottom" else vy)
            shape = lambda p, x0=x0, x1=x1: x0 <= p[0] <= x1
            start = (0.5 * (x0 + x1), 0)
        ld = kwant.Builder(sym)
        ld[lat.shape(shape, start)] = Ul
        if magnetic:
            lam = _lam_xy if side in ("bottom", "top") else _lam_zero
            ld[lat.neighbors()] = _peierls_hop(g.t, lam)
        else:
            ld[lat.neighbors()] = -g.t
        ld.eradicate_dangling()
        syst.attach_lead(ld)
        ids.append(c.id)
        sides.append(side)
    fsyst = syst.finalized()
    dev = Device(g=g, deck=deck, syst=fsyst, leads=ids, lead_sides=sides, n_sites=len(fsyst.sites),
                 notes=notes, magnetic=magnetic)
    dev.notes.append("CAP width %.0f nm, eta0 %.3g eV, free edges %s" % (w_cap, eta0, free_edges or "none"))
    dev.build_s = time.time() - t_start
    return dev


def _lam_xy(x, y):
    return x * y


def _lam_zero(x, y):
    return 0.0


def _peierls_hop(t, lam):
    """Hopping a <- b with the Peierls phase of A = (-B y, 0) + grad(B lam), electron charge -e:
    H_ab = -t exp(-i (e/hbar) int_b^a A.dl), Bk = e B / hbar in 1/nm^2."""
    def hop(a, b, Bk):
        (xa, ya), (xb, yb) = a.pos, b.pos
        flux = -(xa - xb) * 0.5 * (ya + yb) + lam(xa, ya) - lam(xb, yb)
        return -t * cmath.exp(-1j * Bk * flux)
    return hop


def _any_inside(inside, Wn, Hn):
    for fx in np.linspace(0.05, 0.95, 19):
        for fy in np.linspace(0.05, 0.95, 19):
            if inside((fx * Wn, fy * Hn)):
                return (fx * Wn, fy * Hn)
    raise ValueError("no point of the device lies outside the obstacles")


# --- solving -------------------------------------------------------------------------------

def solve(dev: Device, B=0.0, energy=0.0, wavefunction_from=None):
    """Scattering matrix at field B. Returns dict with T[i][j] (from lead j to lead i, incl.
    reflection on the diagonal), the number of incoming modes per lead and the absorbed
    fraction per lead; optionally the scattering wavefunctions injected from one lead."""
    params = dev.params(B)
    sm = kwant.smatrix(dev.syst, energy, params=params, check_hermiticity=False)
    nL = len(dev.leads)
    N = [int(sm.num_propagating(j)) for j in range(nL)]
    T = [[float(np.sum(np.abs(sm.submatrix(i, j)) ** 2)) for j in range(nL)] for i in range(nL)]
    absorbed = [(N[j] - sum(T[i][j] for i in range(nL))) / N[j] if N[j] else 0.0 for j in range(nL)]
    out = dict(T=T, N=N, absorbed=absorbed, B=B)
    if wavefunction_from is not None:
        wf = kwant.wave_function(dev.syst, energy, params=params, check_hermiticity=False)
        out["psi"] = wf(wavefunction_from)
    return out
