"""Analytic Klein transmission across a graphene p-n junction, ported from transim's tracer
(transim/src/plugin.cpp, the junction crossing) so quantum and semiclassical use one law.

Signed Fermi wavevectors: k > 0 on an n (electron) side, k < 0 on a p (hole) side.
"""
import math

import numpy as np


def abrupt(theta1, k1, k2):
    """Abrupt step, Cheianov & Fal'ko (2006):  T = cos th1 cos th2 / cos^2((th1 + th2)/2),
    th2 = -asin(|k1|/|k2| sin th1) (negative refraction). cos^2 th1 for |k1| = |k2|."""
    sr = abs(k1) / abs(k2) * math.sin(theta1) if k2 else 2.0
    if abs(sr) >= 1:
        return 0.0
    th2 = -math.asin(sr)
    ch = math.cos(0.5 * (theta1 + th2))
    return math.cos(theta1) * math.cos(th2) / (ch * ch) if ch > 1e-12 else 0.0


def _lsh(a):
    """log(sinh|a|), stable for large |a|."""
    a = abs(a)
    return a + math.log1p(-math.exp(-2 * a)) - math.log(2.0)


def smooth(theta1, k1, k2, d):
    """Smooth junction of length d, Cayssol, Huard & Goldhaber-Gordon, PRB 79, 075428 (2009),
    Eq. (10): R = sinh(pi d k+-) sinh(pi d k-+) / (sinh(pi d k++) sinh(pi d k--)),
    k^{rs} = K2 - K1 + r X2 + s X1, X = sign(K) sqrt(K^2 - ky^2).  k1, k2 SIGNED (1/length),
    d in the same length unit.  d -> 0 gives abrupt()."""
    if d <= 0:
        return abrupt(theta1, k1, k2)
    ky = abs(k1) * math.sin(theta1)
    if abs(ky) >= abs(k2):
        return 0.0
    X1 = math.copysign(math.sqrt(max(0.0, k1 * k1 - ky * ky)), k1)
    X2 = math.copysign(math.sqrt(max(0.0, k2 * k2 - ky * ky)), k2)
    kpm, kmp = k2 - k1 + X2 - X1, k2 - k1 - X2 + X1
    kpp, kmm = k2 - k1 + X2 + X1, k2 - k1 - X2 - X1
    a = math.pi * d
    if abs(a * kpm) <= 1e-12 or abs(a * kmp) <= 1e-12:
        return 1.0
    R = math.exp(_lsh(a * kpm) + _lsh(a * kmp) - _lsh(a * kpp) - _lsh(a * kmm))
    return min(1.0, max(0.0, 1 - R))


def profile_k(x, k1, k2, d):
    """Cayssol's wavevector profile kF(x) = k1 + (k2 - k1)/(exp(-x/d) + 1); d = 0 is a step at 0."""
    x = np.asarray(x, dtype=float)
    if d <= 0:
        return np.where(x < 0, k1, k2).astype(float)
    return k1 + (k2 - k1) * 0.5 * (1 + np.tanh(0.5 * x / d))  # = 1/(exp(-x/d)+1), overflow-free
