QUANSPORT - quantum transport in graphene devices, with Kwant
=============================================================

QuanSport computes quantum transport through the graphene devices of TranSim
(transmission between contacts, maps of where the current goes, field sweeps),
with the Kwant quantum-transport library underneath. It is to Kwant what 2DMD
is to LAMMPS: you set up and look at the device in a browser page, and Kwant
does the calculation on your own PC.

  - scalable tight-binding graphene (Liu et al., PRL 114, 036601 (2015))
  - p-n junctions rebuilt from the device's density map (Cayssol, Huard &
    Goldhaber-Gordon, PRB 79, 075428 (2009))
  - absorbing boundaries as a complex absorbing potential, and the magnetic
    field as exact Peierls phases
  - next to every quantum result, TranSim's semiclassical (trajectory) result
    for the same device, so the two can be compared side by side

Scientific template: Boggild et al., "A two-dimensional Dirac fermion
microscope", Nat. Commun. 8, 15783 (2017) - the paper and its supplement are in
the refs folder.

Made by Peter Boggild (DTU Physics, 2DPHYS). This is a test version, shared as
it is. Questions and suggestions: pbog@dtu.dk


1. INSTALL (once)
-----------------
Windows 10 or 11, 64-bit. An internet connection the first time.

 1. Put this "QuanSport" folder where it can stay, for example in Documents.
 2. Double-click  Install QuanSport.cmd   (no administrator rights needed).
    It sets up, for your Windows user only:
      - Node.js, if it is not there yet (it runs QuanSport's small local
        server), through Windows' own installer (winget);
      - a private Python 3.11 with Kwant, NumPy, SciPy and Matplotlib from
        conda-forge, in %LOCALAPPDATA%\QuanSport\env (about 1 GB, a few
        minutes). It does not touch any other Python on the PC;
      - a "QuanSport" icon on the desktop.
 3. If Windows shows "Windows protected your PC": "More info", "Run anyway".
    The scripts are plain text files you can read first.

Run the installer again at any time to repair. "Uninstall QuanSport.cmd"
removes the Python environment and the icon (your saved runs are kept).


2. START
--------
Double-click the desktop icon (or Start QuanSport.cmd). A small window opens -
keep it open while you work, closing it stops QuanSport - and QuanSport opens
in your browser. Everything runs on this PC; nothing is sent anywhere.

  Device       pick one of TranSim's example devices (Hall bar, Veselago
               lens, the Dirac fermion microscope, Klein magnetometer, EMR
               devices ...) or open your own TranSim project (.transim.json)
  Model & run  the lattice (scalable tight binding), the fields and maps,
               the boundaries, the semiclassical comparison; then Run
  Results      quantum and semiclassical transmissions T(B) and the current
               maps side by side
  Self-check   runs QuanSport's own tests (below)
  About        what is under the hood

Runs are kept in %LOCALAPPDATA%\QuanSport\runs, so they survive a restart.


3. SIZE, MEMORY AND TIME - read this before the first run
---------------------------------------------------------
QuanSport treats every carbon site of the device (scaled by the factor s), so
the cost grows with the device area. Rule of thumb: about 4 kB of memory per
lattice site, and roughly linear time.

 - START HERE: examples\small-two-terminal.transim.json (open it with "Open a
   device"). About 60 000 sites at s = 10: two fields in about 15 seconds on
   an ordinary PC.
 - The examples in the Device list are TranSim's full-size devices (several
   micrometres). At s = 10, the scale that is accurate for transmissions, they
   need 3 to 12 million sites: 13 GB or more of free memory and 15 minutes or
   more per field. That is a workstation job. Coarser scales (s = 20, 40) are
   much cheaper but the page warns when the lattice no longer resolves the
   physics.
 - To make a device that fits your PC: open it in TranSim, make it smaller
   (width and height), save the project, and open that file in QuanSport. The
   preview under "Lattice" shows the number of sites before you run.


4. SELF-CHECK
-------------
Each gate prints ALL CLEAR or the checks that failed:
  G0   the environment: Kwant and its MUMPS solver work (a graphene ribbon)
  G1   QuanSport reads TranSim's devices exactly as TranSim does
  GS   the semiclassical side reproduces TranSim's own reference results
  G2   Klein tunnelling through a p-n junction against the analytic
       result; absorbing boundaries, gauge, quantum Hall plateaus, magnetic
       focusing; junction potentials
  G3   the lattice scaling: which scale factor is accurate for which result


5. GOOD TO KNOW
---------------
 - When you publish results, please cite Kwant: Groth, Wimmer, Akhmerov &
   Waintal, New J. Phys. 16, 063065 (2014).
 - TranSim, the semiclassical simulator whose devices QuanSport uses, is on
   the DEX site: https://dex-2dphys.github.io/
 - The folder "bin" holds two small programs built from TranSim's code (its
   trajectory tracer and its map sampler), so no compiler is needed.
