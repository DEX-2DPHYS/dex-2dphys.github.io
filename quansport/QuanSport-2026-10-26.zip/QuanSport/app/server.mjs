// QuanSport backend: serves the QuanSport page from this computer and runs quantum-transport jobs as
// Python worker processes (qtrans/worker.py, Kwant + MUMPS) in the qtrans environment.
//
//   node app/server.mjs [--port 8097] [--no-open]
//
// Binds 127.0.0.1 only. Endpoints:
//   GET    /api/qs/hello              {app, version, python, kwant, cores, memGB, jobs, maxJobs, examples}
//   GET    /api/qs/examples           transim's example list (index.json)
//   GET    /api/qs/example?file=...   one transim deck (.transim.json)
//   POST   /api/qs/preview            body: job -> the worker's preview line (sites, k_F a_s, warnings)
//   POST   /api/qs/jobs               body: job ({kind:"run"|"gate", ...}) -> {id}
//   GET    /api/qs/jobs               summaries, newest first
//   GET    /api/qs/jobs/:id           the whole record (built, points, maps, log)
//   DELETE /api/qs/jobs/:id           cancel a queued or running job (kills its process)
// Finished runs are kept in %LOCALAPPDATA%\QuanSport\runs\<id>.json (outside Dropbox: maps are big).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { spawn, spawnSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(here, '..');                                   // the Quantum transport folder
// transim inside a downloaded package, else the DSW plugin next door (the working copy); as qtrans/paths.py
const PACKAGED = fs.existsSync(path.join(ROOT, 'transim', 'ui', 'examples'));
const TRANSIM = PACKAGED ? path.join(ROOT, 'transim') : path.resolve(ROOT, '..', 'DSW', 'Plugins', '2D Materials', 'transim');
const EXAMPLES = path.join(TRANSIM, 'ui', 'examples');
const PAGE = 'QuanSport.html';
const VERSION = '0.1';
const arg = (k, d) => { const i = process.argv.indexOf(k); return i >= 0 ? process.argv[i + 1] : d; };
const PORT = +(arg('--port', process.env.QS_PORT || 8097));
const CORES = os.availableParallelism ? os.availableParallelism() : os.cpus().length;
const MEM = os.totalmem();
const MAX_JOBS = +(process.env.QS_JOBS || 2);
const RUNS = path.join(process.env.LOCALAPPDATA || os.tmpdir(), 'QuanSport', 'runs');
fs.mkdirSync(RUNS, { recursive: true });

// --- Python ---------------------------------------------------------------------------------
function findPython() {
  const py = process.platform === 'win32' ? 'python.exe' : 'bin/python';
  // QTRANS_PYTHON, then the working copy's env, then the private env "Install QuanSport.cmd" creates
  const cands = [process.env.QTRANS_PYTHON, path.join(os.homedir(), 'envs', 'qtrans', py),
    path.join(process.env.LOCALAPPDATA || os.homedir(), 'QuanSport', 'env', py)].filter(Boolean);
  for (const c of cands) if (fs.existsSync(c)) return c;
  return 'python';
}
const PY = findPython();
const probe = spawnSync(PY, ['-I', '-c', 'import kwant, sys; import kwant.solvers.default as d; print(kwant.__version__, type(d.smatrix.__self__).__module__, sys.version.split()[0])'], { encoding: 'utf8' });
const [KWANT, SOLVER, PYVER] = (probe.stdout || '').trim().split(/\s+/);
if (!KWANT) {
  console.log('QuanSport could not import kwant with ' + PY);
  console.log(probe.stderr || '');
  console.log(PACKAGED
    ? 'Run "Install QuanSport.cmd" once: it sets up Python with Kwant for QuanSport.'
    : 'Create the environment (see DESIGN.md, Environment): conda create -p %USERPROFILE%\\envs\\qtrans -c conda-forge python=3.11 kwant numpy scipy matplotlib-base');
}

// --- jobs -----------------------------------------------------------------------------------
const jobs = new Map();          // id -> record
let seq = 0;
const newId = () => new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14) + '-' + (++seq);

function summary(j) {
  return { id: j.id, kind: j.kind, name: j.name, status: j.status, created: j.created, started: j.started, ended: j.ended,
    total: j.total, done: j.points ? j.points.length : 0, sites: j.built ? j.built.sites : null,
    peakMB: j.peakMB || (j.built && j.built.peakMB) || null, error: j.error || null, gate: j.gate || null };
}

const GATES = { g0: 'g0_env.py', g1: 'g1_deck.py', gs: 'gs_transim.py', g2klein: 'g2_klein.py', g2pot: 'g2_potential.py', g2device: 'g2_device.py', g3: 'g3_scale.py' };

function startNext() {
  const running = [...jobs.values()].filter((j) => j.status === 'running').length;
  if (running >= MAX_JOBS) return;
  const next = [...jobs.values()].filter((j) => j.status === 'queued').sort((a, b) => a.created.localeCompare(b.created))[0];
  if (!next) return;
  launch(next);
  startNext();
}

function launch(j) {
  j.status = 'running'; j.started = new Date().toISOString();
  let argv;
  if (j.kind === 'gate') argv = ['-I', path.join(ROOT, 'tests', GATES[j.gate])];
  else argv = ['-I', path.join(ROOT, 'qtrans', 'worker.py')];
  const p = spawn(PY, argv, { cwd: ROOT, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } });
  j.proc = p;
  let buf = '';
  p.stdout.on('data', (d) => {
    buf += d;
    let k;
    while ((k = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, k).replace(/\r$/, ''); buf = buf.slice(k + 1);
      if (j.kind === 'gate') { j.log.push(line); continue; }
      let m; try { m = JSON.parse(line); } catch { j.log.push(line); continue; }
      if (m.t === 'built') j.built = m;
      else if (m.t === 'point') j.points.push(m);
      else if (m.t === 'map') j.maps.push(m);
      else if (m.t === 'classical') j.classical.push(m);
      else if (m.t === 'log') j.log.push(m.msg);
      else if (m.t === 'done') { j.secs = m.secs; j.peakMB = m.peakMB; }
      else if (m.t === 'error') { j.error = m.msg; j.log.push(m.trace || m.msg); }
    }
  });
  p.stderr.on('data', (d) => { j.stderr = (j.stderr + d).slice(-20000); });
  p.on('exit', (code) => {
    j.proc = null; j.ended = new Date().toISOString();
    if (j.status === 'cancelled') { /* keep */ }
    else if (j.kind === 'gate') j.status = j.log.some((l) => l.trim() === 'ALL CLEAR') ? 'clear' : 'failed';
    else j.status = code === 0 && !j.error ? 'done' : 'failed';
    if (j.status === 'failed' && !j.error) j.error = (j.stderr || '').trim().split('\n').slice(-3).join(' ') || ('exit code ' + code);
    console.log(`${j.kind} ${j.id} ${j.name}: ${j.status}${j.secs ? ` in ${j.secs.toFixed(1)} s` : ''}${j.peakMB ? `, peak ${j.peakMB.toFixed(0)} MB` : ''}`);
    if (j.kind === 'run') save(j);
    startNext();
  });
  if (j.kind === 'run') { p.stdin.write(JSON.stringify(j.job)); }
  p.stdin.end();
}

function save(j) {
  const { proc, ...rest } = j;
  fs.writeFile(path.join(RUNS, j.id + '.json'), JSON.stringify(rest), () => {});
}

// earlier runs, so results survive a restart
for (const f of fs.readdirSync(RUNS).filter((f) => f.endsWith('.json'))) {
  try { const j = JSON.parse(fs.readFileSync(path.join(RUNS, f), 'utf8')); j.proc = null; if (j.status === 'running' || j.status === 'queued') j.status = 'failed'; jobs.set(j.id, j); } catch { /* skip */ }
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch (e) { reject(e); } });
    req.on('error', reject);
  });
}

function json(res, code, obj) {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, { 'Content-Type': 'application/json', 'Content-Length': b.length, 'Cache-Control': 'no-store' });
  res.end(b);
}

function preview(job) {
  return new Promise((resolve) => {
    const p = spawn(PY, ['-I', path.join(ROOT, 'qtrans', 'worker.py')], { cwd: ROOT });
    let out = '', err = '';
    p.stdout.on('data', (d) => { out += d; });
    p.stderr.on('data', (d) => { err += d; });
    p.on('exit', () => {
      const lines = out.trim().split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
      resolve(lines.find((l) => l.t === 'preview') || lines.find((l) => l.t === 'error') || { t: 'error', msg: err.slice(-500) || 'no output' });
    });
    p.stdin.end(JSON.stringify({ ...job, kind: 'preview' }));
  });
}

// --- static ---------------------------------------------------------------------------------
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.pdf': 'application/pdf' };
function serveFile(res, file, base) {
  if (!file.startsWith(base + path.sep)) { res.writeHead(403).end(); return; }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404).end('not found'); return; }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': st.size, 'Cache-Control': 'no-store' });
    fs.createReadStream(file).pipe(res);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = decodeURIComponent(url.pathname);
  try {
    if (p === '/api/qs/hello') {
      return json(res, 200, { app: 'quansport', version: VERSION, python: PY, pythonVersion: PYVER || null, kwant: KWANT || null, solver: SOLVER || null,
        cores: CORES, memGB: +(MEM / 2 ** 30).toFixed(1), freeGB: +(os.freemem() / 2 ** 30).toFixed(1), maxJobs: MAX_JOBS, runsDir: RUNS,
        transim: fs.existsSync(EXAMPLES), jobs: [...jobs.values()].filter((j) => j.status === 'running').length });
    }
    if (p === '/api/qs/examples') {
      const idx = JSON.parse(fs.readFileSync(path.join(EXAMPLES, 'index.json'), 'utf8'));
      return json(res, 200, idx);
    }
    if (p === '/api/qs/example') {
      const f = url.searchParams.get('file') || '';
      if (!/^[\w.-]+\.transim\.json$/.test(f)) return json(res, 400, { error: 'bad file name' });
      return serveFile(res, path.join(EXAMPLES, f), EXAMPLES);
    }
    if (p === '/api/qs/preview' && req.method === 'POST') return json(res, 200, await preview(await readBody(req)));
    if (p === '/api/qs/jobs' && req.method === 'POST') {
      const body = await readBody(req);
      const kind = body.kind === 'gate' ? 'gate' : 'run';
      if (kind === 'gate' && !GATES[body.gate]) return json(res, 400, { error: 'unknown gate' });
      const id = newId();
      const j = { id, kind, gate: body.gate || null, name: kind === 'gate' ? 'self-check ' + body.gate : ((body.deck && body.deck.name) || 'deck') + ` (s = ${body.s})`,
        status: 'queued', created: new Date().toISOString(), job: kind === 'run' ? body : null, total: kind === 'run' ? (body.B || []).length : null,
        built: null, points: [], maps: [], classical: [], log: [], stderr: '' };
      jobs.set(id, j);
      startNext();
      return json(res, 200, { id });
    }
    if (p === '/api/qs/jobs' && req.method === 'GET') {
      return json(res, 200, [...jobs.values()].sort((a, b) => b.created.localeCompare(a.created)).map(summary));
    }
    const m = /^\/api\/qs\/jobs\/([\w-]+)$/.exec(p);
    if (m) {
      const j = jobs.get(m[1]);
      if (!j) return json(res, 404, { error: 'no such job' });
      if (req.method === 'DELETE') {
        if (j.proc) { j.status = 'cancelled'; j.proc.kill(); }
        else if (j.status === 'queued') { j.status = 'cancelled'; }
        else { jobs.delete(j.id); fs.rm(path.join(RUNS, j.id + '.json'), () => {}); }
        return json(res, 200, { ok: true });
      }
      const { proc, ...rest } = j;
      return json(res, 200, rest);
    }
    if (req.method !== 'GET') { res.writeHead(405).end(); return; }
    if (p === '/' ) { res.writeHead(302, { Location: '/' + PAGE }).end(); return; }
    if (p === '/favicon.ico') { res.writeHead(204).end(); return; }
    return serveFile(res, path.resolve(here, '.' + p), here);
  } catch (e) {
    return json(res, 500, { error: (e && e.message) || String(e) });
  }
});

server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.log(`Port ${PORT} is in use - probably QuanSport is already running. Opening it.`);
    if (!process.argv.includes('--no-open')) openBrowser();
    setTimeout(() => process.exit(0), 500);
    return;
  }
  throw e;
});

function openBrowser() {
  const u = `http://127.0.0.1:${PORT}/${PAGE}`;
  if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', u], { detached: true, stdio: 'ignore' }).unref();
  else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [u], { detached: true, stdio: 'ignore' }).unref();
}

server.listen(PORT, '127.0.0.1', () => {
  console.log(`QuanSport ${VERSION}: http://127.0.0.1:${PORT}/  (${CORES} threads, ${(MEM / 2 ** 30).toFixed(0)} GB, up to ${MAX_JOBS} jobs at once)`);
  console.log(KWANT ? `Python ${PYVER} with Kwant ${KWANT} (${SOLVER}): ${PY}` : 'Kwant NOT available: runs will fail until the qtrans environment exists.');
  console.log(`Runs are kept in ${RUNS}`);
  console.log('Keep this window open while you work; close it to stop QuanSport.');
  if (!process.argv.includes('--no-open')) openBrowser();
});
