"""Command-line qtrans run (the same worker QuanSport uses).

    python run_qtrans.py <deck.transim.json> --scale 10 --B 0,0.002,0.008 --out result.qtrans.json
           [--maps 0.002,0.008 --grid 360x180]

Writes a .qtrans.json result (format in DESIGN.md).
"""
import argparse
import datetime
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--scale", type=float, default=10)
    ap.add_argument("--B", default=None, help="comma-separated fields in tesla (default: the deck's B)")
    ap.add_argument("--maps", default="", help="comma-separated fields at which to save maps")
    ap.add_argument("--grid", default="360x180")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    with open(a.deck, encoding="utf-8") as f:
        deck = json.load(f)
    Bs = [float(x) for x in a.B.split(",")] if a.B else [float(deck.get("params", {}).get("B", 0))]
    gx, gy = (int(v) for v in a.grid.lower().split("x"))
    job = {"kind": "run", "deck": deck, "s": a.scale, "B": Bs,
           "maps": {"gx": gx, "gy": gy, "at": [float(x) for x in a.maps.split(",") if x], "kinds": ["density", "current"]}}
    p = subprocess.Popen([sys.executable, "-I", os.path.join(HERE, "qtrans", "worker.py")],
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
    p.stdin.write(json.dumps(job))
    p.stdin.close()
    res = {"format": "qtrans-result", "version": 1, "created": datetime.datetime.now().isoformat(timespec="seconds"),
           "deck": {"name": deck.get("name"), "file": os.path.basename(a.deck)}, "s": a.scale,
           "B": Bs, "points": [], "maps": [], "classical": []}
    for line in p.stdout:
        m = json.loads(line)
        t = m.pop("t")
        if t == "built":
            res["build"] = m
            print("built: %d sites, leads %s, %.1f s" % (m["sites"], m["leads"], m["secs"]))
        elif t == "point":
            res["points"].append(m)
            print("B = %+.4g T: %s  absorbed %.3f  (%.1f s)" % (m["B"], {k: round(v, 4) for k, v in m["T"].items()}, m["absorbed"], m["secs"]))
        elif t == "classical":
            res["classical"].append(m)
            print("classical B = %+.4g T: %s" % (m["B"], {k: round(v, 4) for k, v in m["T"].items()}))
        elif t == "map":
            res["maps"].append(m)
        elif t == "done":
            res["secs"], res["peakMB"] = m["secs"], m["peakMB"]
        elif t == "error":
            print("ERROR:", m["msg"])
            print(m.get("trace", ""))
            sys.exit(1)
        elif t == "log":
            print(m["msg"])
    p.wait()
    from qtrans.deck import deck_hash
    res["deck"]["hash"] = deck_hash(deck)
    out = a.out or os.path.splitext(os.path.splitext(a.deck)[0])[0] + ".qtrans.json"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(res, f)
    print("wrote", out, "(%.1f s, peak %.0f MB)" % (res.get("secs", 0), res.get("peakMB", 0)))


if __name__ == "__main__":
    sys.path.insert(0, HERE)
    main()
