@echo off
rem One-time setup of QuanSport (current user only, no administrator rights): Node.js if missing,
rem a private Python with Kwant in %LOCALAPPDATA%\QuanSport\env (about 1 GB), and a desktop icon.
rem Run it again to repair. "Uninstall QuanSport.cmd" removes it.
title Install QuanSport
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install\install-quansport.ps1"
if errorlevel 1 (echo. & echo   Something went wrong - see the message above.)
echo.
pause
