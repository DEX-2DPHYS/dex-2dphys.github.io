@echo off
rem Removes what "Install QuanSport.cmd" added: the private Python environment, micromamba and its
rem package cache in %LOCALAPPDATA%\QuanSport, and the desktop icon. Your saved runs are kept.
title Uninstall QuanSport
powershell -NoProfile -Command "$b = Join-Path $env:LOCALAPPDATA QuanSport; foreach ($d in env,mamba,micromamba.exe,bin) { $p = Join-Path $b $d; if (Test-Path $p) { Remove-Item -Recurse -Force $p; Write-Host (removed  + $p) } }; $l = Join-Path ([Environment]::GetFolderPath(Desktop)) QuanSport.lnk; if (Test-Path $l) { Remove-Item -Force $l; Write-Host (removed  + $l) }; Write-Host (kept your runs in  + (Join-Path $b runs))"
echo.
pause
