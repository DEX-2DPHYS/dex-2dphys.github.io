The self-check gates write their figures and tables here.
