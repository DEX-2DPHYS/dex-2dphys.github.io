# One-time setup of QuanSport on a Windows PC (current user only, no administrator rights).
#   1. Node.js (runs QuanSport's small local server) - installed with winget if it is missing
#   2. micromamba - a single program that fetches Python packages from conda-forge
#   3. a private Python 3.11 with Kwant (+ MUMPS), NumPy, SciPy, Matplotlib in %LOCALAPPDATA%\QuanSport\env
#      (about 1 GB; it does not touch any other Python on the PC)
#   4. a "QuanSport" icon on the desktop
# Run it again at any time: it repairs what is missing and leaves the rest.
param([string]$EnvDir = (Join-Path $env:LOCALAPPDATA 'QuanSport\env'), [switch]$NoShortcut)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $PSScriptRoot          # the QuanSport folder
$base = Join-Path $env:LOCALAPPDATA 'QuanSport'
New-Item -ItemType Directory -Force -Path $base | Out-Null
function Step([string]$t) { Write-Host ''; Write-Host "== $t" -ForegroundColor Cyan }

# 1. Node.js
Step 'Node.js'
$node = Get-Command node -ErrorAction SilentlyContinue
if ($node) {
  Write-Host "found: $(& node --version)"
} else {
  $winget = Get-Command winget -ErrorAction SilentlyContinue
  if (-not $winget) { throw 'Node.js is missing and winget is not available. Install Node.js (LTS) from https://nodejs.org/ and run this again.' }
  Write-Host 'installing Node.js LTS with winget ...'
  & winget install -e --id OpenJS.NodeJS.LTS --scope user --accept-source-agreements --accept-package-agreements
  $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User')
  if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Node.js did not install. Install it from https://nodejs.org/ (LTS) and run this again.' }
}

# 2. micromamba
Step 'micromamba'
$mm = Join-Path $base 'micromamba.exe'
if (-not (Test-Path $mm)) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
  $url = 'https://github.com/mamba-org/micromamba-releases/releases/latest/download/micromamba-win-64'
  Write-Host "downloading $url"
  Invoke-WebRequest -Uri $url -OutFile "$mm.part" -UseBasicParsing
  Move-Item -Force "$mm.part" $mm
}
Write-Host "micromamba $(& $mm --version)"

# 3. the Python environment with Kwant
Step "Python with Kwant in $EnvDir (first time: a few minutes, about 1 GB)"
$env:MAMBA_ROOT_PREFIX = Join-Path $base 'mamba'
$py = Join-Path $EnvDir 'python.exe'
$check = "import kwant, numpy, scipy, matplotlib, sys; import kwant.solvers.default as d; print('Kwant', kwant.__version__, 'solver', type(d.smatrix.__self__).__module__, 'Python', sys.version.split()[0])"
$ok = $false
if (Test-Path $py) { try { & $py -I -c $check; $ok = ($LASTEXITCODE -eq 0) } catch { $ok = $false } }
if (-not $ok) {
  & $mm create -y -p $EnvDir -c conda-forge --override-channels 'python=3.11' 'kwant=1.5' numpy scipy matplotlib-base
  if ($LASTEXITCODE -ne 0) { throw 'creating the Python environment failed (see above). Check the internet connection and run this again.' }
  & $py -I -c $check
  if ($LASTEXITCODE -ne 0) { throw 'Kwant does not import in the new environment (see above).' }
}

# 4. desktop icon
if (-not $NoShortcut) {
  Step 'desktop icon'
  $desk = [Environment]::GetFolderPath('Desktop')
  $ws = New-Object -ComObject WScript.Shell
  $lnk = $ws.CreateShortcut((Join-Path $desk 'QuanSport.lnk'))
  $lnk.TargetPath = Join-Path $here 'Start QuanSport.cmd'
  $lnk.WorkingDirectory = $here
  $lnk.IconLocation = "$env:SystemRoot\System32\imageres.dll,144"
  $lnk.Description = 'QuanSport - quantum transport with Kwant'
  $lnk.Save()
  Write-Host "$desk\QuanSport.lnk"
}
Write-Host ''
Write-Host 'QuanSport is ready. Start it with the desktop icon or "Start QuanSport.cmd".' -ForegroundColor Green
