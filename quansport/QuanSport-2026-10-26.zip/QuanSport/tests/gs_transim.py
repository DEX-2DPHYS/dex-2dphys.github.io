"""GS: the semiclassical side (tsim = transim's live core on a deck) reproduces transim's own reference
output dfm.json (transim/test/dfm.cpp): the DFM circular p-n deck (vd25) at several fields, every drain,
within Monte Carlo noise (4 sigma of the binomial counting error of both runs, floor 0.002).

    python tests/gs_transim.py
"""
import json
import math
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from qtrans import semiclassical as sc  # noqa: E402

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


t0 = time.time()
exe = sc.ensure_built()
print("  tsim: %s (%.1f s)" % (exe, time.time() - t0))
deck = json.load(open(os.path.join(sc.TRANSIM, "ui", "examples", "dfm-circular-pn.transim.json"), encoding="utf-8"))
ref = json.load(open(os.path.join(sc.TRANSIM, "dfm.json"), encoding="utf-8"))["vd25"]
N = 200000
Bs = (0.0, 0.002, 0.004, 0.008)
worst = 0.0
for r in sc.run(deck, list(Bs), n_traj=N):
    i = min(range(len(ref["B"])), key=lambda k: abs(ref["B"][k] - r["B"]))
    for key, col in (("back", "T2"), ("top", "T3"), ("bottom", "T4")):
        a, b = r["T"][key], ref[col][i]
        sig = math.sqrt(max(a * (1 - a), b * (1 - b), 1e-6) * 2 / N)    # both runs are binomial samples
        z = abs(a - b) / sig
        worst = max(worst, z)
        ok = abs(a - b) < max(4 * sig, 0.002)
        if not ok:
            check(False, "B = %g T, %s: tsim %.4f vs dfm.json %.4f" % (r["B"], key, a, b))
    print("  B = %+.4f T: back %.4f/%.4f  top %.4f/%.4f  bottom %.4f/%.4f (tsim/dfm.json)" % (
        r["B"], r["T"]["back"], ref["T2"][i], r["T"]["top"], ref["T3"][i], r["T"]["bottom"], ref["T4"][i]))
check(not fails, "tsim reproduces transim's dfm.json (vd25) at %d fields x 3 drains, worst %.1f sigma" % (len(Bs), worst))
print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
