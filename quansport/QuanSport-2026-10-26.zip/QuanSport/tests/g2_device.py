"""G2b-d: the 2D device builder (qtrans.device) at s = 10, n = 1e12.

  b) absorbing boundary (CAP): modes within 60 deg of the normal reflect < 1e-4, mean absorption > 95 %
  c) gauge: on a device with leads on all four edges and a hole, every hexagon carries exactly the flux
     e B A_hex / hbar (including where the gauge function switches and at the lead mouths); T(+B) != T(-B)
     but T_ij(B) = T_ji(-B) (Onsager-Buttiker); and at 6 T, where E_F lies between Landau levels 1 and 2,
     every lead passes exactly T = 3 (spinless nu = 2N + 1) to ONE neighbour: chiral edge transport through
     all four lead interfaces, which a gauge mismatch at any lead would scatter
  d) transverse magnetic focusing: two 20 nm contacts L = 0.5 um apart on one specular edge; the
     first peak sits at B1 = 2 hbar k_F / (e L) to 10 %, only for B < 0 (electrons turn
     counter-clockwise for B > 0, transim's convention), with a second peak near 2 B1

    python tests/g2_device.py
"""
import math
import os
import sys
import time

import numpy as np
import kwant

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from qtrans.synth import make_deck  # noqa: E402
from qtrans import device as D  # noqa: E402
from qtrans.model import Graphene, HBAR_JS, E_CHARGE, E_OVER_HBAR_NM2  # noqa: E402
from qtrans.gaugecheck import hexagon_flux_errors  # noqa: E402

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


g = Graphene(s=10)
kF = float(g.kF_signed(1e12))   # 1/nm

# --- b) CAP -------------------------------------------------------------------------------
t0 = time.time()
deck = make_deck(0.8, 0.2, [("src", "source", 0, 0, 0.01, 1)])
dev = D.build_device(deck, s=10, opt=D.Options(absorbing_edges=["right"]), magnetic=False)
sm = kwant.smatrix(dev.syst, 0.0, check_hermiticity=False)
Rm = (np.abs(sm.submatrix(0, 0)) ** 2).sum(axis=0)
v = np.abs(sm.lead_info[0].velocities[:len(Rm)])
fast = v > 0.5 * v.max()
print("  CAP: %d modes, %d sites, %.1f s, %s" % (len(Rm), dev.n_sites, time.time() - t0, dev.notes[-1]))
check(Rm[fast].max() < 1e-4, "CAP: modes within 60 deg of the normal reflect < 1e-4 (max %.1e)" % Rm[fast].max())
check(1 - Rm.mean() > 0.95, "CAP: mean absorption > 95 %% (%.1f %%)" % (100 * (1 - Rm.mean())))

# --- c) gauge against kwant.physics.magnetic_gauge -----------------------------------------
t0 = time.time()
deck4 = make_deck(0.2, 0.2, [("L", "source", 0, 0.3, 0.01, 0.6), ("R", "drain", 0.99, 0.2, 1, 0.5),
                             ("B", "drain", 0.2, 0, 0.45, 0.01), ("T", "drain", 0.5, 0.99, 0.8, 1),
                             ("hole", "reflector", 0.55, 0.45, 0.75, 0.7)])
fast_dev = D.build_device(deck4, s=10)
Bk = 1.5 * E_OVER_HBAR_NM2
nhex, ferr = hexagon_flux_errors(fast_dev, fast_dev.params(1.5), Bk)
check(nhex > 5000 and ferr < 1e-10, "every hexagon carries e B A/hbar: %d hexagons, worst error %.1e rad (flux %.2e rad each)" % (
    nhex, ferr, Bk * 1.5 * math.sqrt(3) * fast_dev.g.acc ** 2))
Ts = {}
for B in (1.5, -1.5):
    S1 = kwant.smatrix(fast_dev.syst, 0.0, params=fast_dev.params(B), check_hermiticity=False)
    Ts[B] = np.array([[S1.transmission(i, j) for j in range(4)] for i in range(4)])
# quantum Hall on the same layout at 0.4 um: in 0.2 um the opposite edge states still tunnel into each
# other (2e-3 at 6 T, 2e-4 at 7 T, the same with or without the hole); at 0.4 um quantisation is exact
qh_dev = D.build_device(make_deck(0.4, 0.4, [("L", "source", 0, 0.3, 0.01, 0.6), ("R", "drain", 0.99, 0.2, 1, 0.5),
                                             ("B", "drain", 0.2, 0, 0.45, 0.01), ("T", "drain", 0.5, 0.99, 0.8, 1),
                                             ("hole", "reflector", 0.55, 0.45, 0.75, 0.7)]), s=10)
for B in (6.0, -6.0):
    S1 = kwant.smatrix(qh_dev.syst, 0.0, params=qh_dev.params(B), check_hermiticity=False)
    Ts[B] = np.array([[S1.transmission(i, j) for j in range(4)] for i in range(4)])
print("  gauge: %d sites, %.1f s" % (fast_dev.n_sites, time.time() - t0))
check(np.max(np.abs(Ts[1.5] - Ts[-1.5])) > 0.05, "the field matters: T(+B) != T(-B) (max diff %.2f)" % np.max(np.abs(Ts[1.5] - Ts[-1.5])))
check(np.max(np.abs(Ts[1.5] - Ts[-1.5].T)) < 1e-6, "Onsager-Buttiker: T_ij(B) = T_ji(-B) (max %.1e)" % np.max(np.abs(Ts[1.5] - Ts[-1.5].T)))
for B in (6.0, -6.0):
    T = Ts[B].copy()
    np.fill_diagonal(T, 0)
    big = np.sort(T, axis=0)
    check(np.all(np.abs(big[-1] - 3) < 1e-6) and np.all(big[:-1] < 1e-6),
          "quantum Hall at %+g T: each lead sends exactly 3 to one neighbour, ~0 elsewhere (max dev %.1e)" % (
              B, max(np.max(np.abs(big[-1] - 3)), np.max(big[:-1]))))
    print("    receivers at %+g T: %s" % (B, [qh_dev.leads[i] + "<-" + qh_dev.leads[j] for j, i in enumerate(np.argmax(T, axis=0))]))
check(not np.array_equal(np.argmax(Ts[6.0] - np.diag(np.diag(Ts[6.0])), axis=0), np.argmax(Ts[-6.0] - np.diag(np.diag(Ts[-6.0])), axis=0)),
      "reversing B reverses the chirality")

# --- d) magnetic focusing -----------------------------------------------------------------
t0 = time.time()
W = 1.0
L = 0.5 * W * 1e3                                   # nm between contact centres
B1 = 2 * HBAR_JS * kF * 1e9 / (E_CHARGE * L * 1e-9)  # tesla
deckf = make_deck(W, W / 2, [("src", "source", 0.23, 0, 0.27, 0.01), ("det", "drain", 0.73, 0, 0.77, 0.01)])
devf = D.build_device(deckf, s=10, opt=D.Options(absorbing_edges=["top", "left", "right"]))
Bs = np.round(np.arange(-2.4, 0.61, 0.04) * B1, 4)
Tf = np.array([D.solve(devf, B=b)["T"][1][0] for b in Bs])
print("  focusing: %d sites, %d fields in %.1f s; B1 = %.3f T" % (devf.n_sites, len(Bs), time.time() - t0, B1))
neg = Bs < 0
ipk = np.argmax(np.where((Bs < -0.5 * B1) & (Bs > -1.5 * B1), Tf, -1))
Bp = Bs[ipk]
check(abs(abs(Bp) / B1 - 1) < 0.10, "first focusing peak at |B| = %.3f T = %.3f B1 (within 10 %%)" % (abs(Bp), abs(Bp) / B1))
check(Bp < 0, "the peak is at negative B (electrons turn counter-clockwise for B > 0, as in transim)")
check(Tf[Bs > 0.2 * B1].max() < 0.05 * Tf[ipk], "no focusing for B > 0 (max %.4f vs peak %.3f)" % (Tf[Bs > 0.2 * B1].max(), Tf[ipk]))
i2 = np.argmax(np.where((Bs < -1.6 * B1) & (Bs > -2.4 * B1), Tf, -1))
check(abs(abs(Bs[i2]) / B1 - 2) < 0.15, "second peak (one specular bounce) at %.2f B1" % (abs(Bs[i2]) / B1))

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6, 3.4))
    ax.plot(Bs, Tf, "-o", ms=3)
    for k in (1, 2):
        ax.axvline(-k * B1, color="0.6", ls="--", lw=0.8)
        ax.text(-k * B1, ax.get_ylim()[1] * 0.92, " -%d B$_1$" % k, fontsize=8, color="0.4")
    ax.set_xlabel("B (T)")
    ax.set_ylabel("T(detector <- source)")
    ax.set_title("G2d: transverse magnetic focusing, L = %.0f nm, s = 10, n = 1e12" % L, fontsize=9)
    ax.grid(alpha=0.3)
    fig.tight_layout()
    out = os.path.join(HERE, "..", "results", "g2_focusing.png")
    fig.savefig(out, dpi=130)
    print("  figure:", os.path.normpath(out))
except Exception as e:
    print("  (no figure:", e, ")")

print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
