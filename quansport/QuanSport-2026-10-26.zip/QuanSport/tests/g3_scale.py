"""G3: scale convergence on a cropped (1 x 1 um) Veselago dot, the Fig. 4 geometry of the DFM paper in
miniature: 20 nm emitter at mid-height on the left edge, a p-type dot (radius 0.25 um) at x = 0.55 um in
n-type graphene (|n| = 1e12 cm^-2), drains on the back, top and bottom edges, every free edge absorbing.

Each case runs as its own process (tests/g3_one.py) so its peak memory is measured cleanly.
Compared between s values: T to each drain, and the |psi|^2 map from the source (on a 100 x 100 grid,
correlation of sqrt-density). Criterion (hand-over): s = 20 and s = 10 agree within a few %; the s = 5
run, where it fits, shows which of the two is converged.

    python tests/g3_scale.py [--s 20,10,5] [--w 2.5,40] [--B 0,0.1]
"""
import argparse
import json
import os
import subprocess
import sys
import time

import numpy as np
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

ap = argparse.ArgumentParser()
ap.add_argument("--s", default="20,10,5")
ap.add_argument("--w", default="2.5,40")
ap.add_argument("--B", default="0,0.1")
ap.add_argument("--src", default="20", help="emitter width (nm)")
ap.add_argument("--size", default="1.0", help="device side (um); the dot scales with it")
a = ap.parse_args()
a_size = a.size
S = [float(x) for x in a.s.split(",")]
WS = [float(x) for x in a.w.split(",")]
BS = [float(x) for x in a.B.split(",")]

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


res = {}
for w in WS:
    for s in S:
        t0 = time.time()
        p = subprocess.run([sys.executable, "-I", os.path.join(HERE, "g3_one.py"), str(s), str(w), ",".join(map(str, BS)), a.src, a.size],
                           capture_output=True, text=True, cwd=ROOT)
        lines = [json.loads(l) for l in p.stdout.splitlines() if l.startswith("{")]
        if p.returncode or not lines:
            print("  s=%g w=%g FAILED: %s" % (s, w, (p.stderr or p.stdout)[-800:]))
            continue
        r = lines[-1]
        res[(w, s)] = r
        print("  w=%4g nm s=%-3g: %8d sites, source %s nm with %s modes, build %5.1f s, %s per field, peak %.2f GB | %s" % (
            w, s, r["sites"], a.src, "/".join(map(str, r["modes"])), r["build_s"], "/".join("%.0f s" % x for x in r["secs"]),
            r["peakMB"] / 1024, "  ".join("B=%g: %s abs %.3f" % (B, {k: round(v, 4) for k, v in T.items()}, ab)
                                          for B, T, ab in zip(r["B"], r["T"], r["absorbed"]))))
        if 0.0 in BS:   # the device is mirror-symmetric about y = H/2: at B = 0 top and bottom must agree
            T0 = r["T"][BS.index(0.0)]
            print("      mirror check at B = 0: top %.4f vs bottom %.4f (%.1f %% apart)" % (
                T0["top"], T0["bottom"], 100 * abs(T0["top"] - T0["bottom"]) / max(1e-9, 0.5 * (T0["top"] + T0["bottom"]))))

with open(os.path.join(ROOT, "results", "g3_scale_src%s_size%s.json" % (a.src, a.size)), "w") as f:
    json.dump({"%g|%g" % k: v for k, v in res.items()}, f)

# --- comparisons ---------------------------------------------------------------------------
def compare(w, s1, s2):
    r1, r2 = res.get((w, s1)), res.get((w, s2))
    if not r1 or not r2:
        return None
    worst_T, worst_c, worst_sh = 0.0, 1.0, 0.0
    for i in range(len(BS)):
        t1, t2 = sum(r1["T"][i].values()) or 1, sum(r2["T"][i].values()) or 1
        for k in r1["T"][i]:
            a, b = r1["T"][i][k], r2["T"][i][k]
            worst_T = max(worst_T, abs(a - b) / max(0.02, 0.5 * (a + b)))   # relative, floor 0.02
            worst_sh = max(worst_sh, abs(a / t1 - b / t2))                   # share of the flux reaching drains
        # compare maps at the resolution the physics claims: averaged over lambda_F / 2 (18 nm at 1e12);
        # the pixel-level speckle of a lattice-sharp junction keeps changing with s (G3, 2026-10-21)
        cell = float(a_size) * 1e3 / 100
        m1 = ndimage.gaussian_filter(np.sqrt(np.array(r1["maps"][i])), 18.0 / cell)
        m2 = ndimage.gaussian_filter(np.sqrt(np.array(r2["maps"][i])), 18.0 / cell)
        worst_c = min(worst_c, float(np.corrcoef(m1.ravel(), m2.ravel())[0, 1]))
    return worst_T, worst_c, worst_sh


# The verdict uses the drain SHARES (independent of how the emitter's injected current is normalised,
# which changes with its mode content) and the map correlation; per-mode T is printed for information.
SHARE_TOL, CORR_TOL = 0.05, 0.95
for w in WS:
    for s1, s2 in ((20, 10), (10, 5), (5, 2.5)):
        c = compare(w, s1, s2)
        if c is None:
            continue
        ok = c[2] < SHARE_TOL and c[1] > CORR_TOL
        print("  w=%g nm: s=%g vs s=%g: worst drain-share difference %.3f, worst map correlation (lambda_F/2 averaged) %.4f, worst per-mode T difference %.0f %%" % (
            w, s1, s2, c[2], c[1], 100 * c[0]))
        print(("  [ OK ] " if ok else "  [info] ") + "w=%g nm: s=%g %s s=%g (shares within %.2f, map corr > %.2f)" % (
            w, s1, "agrees with" if ok else "does NOT agree with", s2, SHARE_TOL, CORR_TOL))
        if (s1, s2) == (5, 2.5) or ((s1, s2) == (10, 5) and 2.5 not in S):
            check(ok, "w=%g nm: s=%g is converged against s=%g" % (w, s1, s2))

print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
