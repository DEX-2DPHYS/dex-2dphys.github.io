// g1_ref -- transim's own FieldMap::sample and inObstacle, for the G1 cross-check.
// Built against the live transim source, so G1 compares with the code, not a copy of it.
//
//   g1_ref <in.txt>
// in.txt:  w h / w*h map values (row 0 = top) / nc / nc lines "role x0 y0 x1 y1" /
//          np / np lines "xf yf"
// prints one line per point: "<sample %.17g> <obstacle 0|1>"
#include "plugin.cpp"

#include <cstdio>
#include <fstream>

int main(int argc, char **argv) {
    if (argc < 2) { std::fprintf(stderr, "usage: g1_ref in.txt\n"); return 2; }
    std::ifstream in(argv[1]);
    FieldMap m;
    in >> m.w >> m.h;
    m.v.resize(static_cast<size_t>(m.w) * m.h);
    for (auto &x : m.v) { double d; in >> d; x = static_cast<float>(d); }
    int nc = 0; in >> nc;
    std::vector<Contact> cs(nc);
    for (auto &c : cs) in >> c.role >> c.x0 >> c.y0 >> c.x1 >> c.y1;
    int np = 0; in >> np;
    for (int k = 0; k < np; ++k) {
        double xf, yf; in >> xf >> yf;
        bool obs = false;
        for (const auto &c : cs) if (inObstacle(c, xf, yf)) obs = true;
        std::printf("%.17g %d\n", m.sample(xf, yf, -1.0), obs ? 1 : 0);
    }
    return 0;
}
