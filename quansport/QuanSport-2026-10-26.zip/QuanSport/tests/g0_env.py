"""G0: Kwant works, MUMPS is the default solver, and a graphene zigzag ribbon shows
quantized conductance steps G = (2m+1) e^2/h (spinless, valley-degenerate plateaus 1, 3, 5).

    python tests/g0_env.py
"""
import sys
import time

import numpy as np
import kwant

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


print("kwant", kwant.__version__, "python", sys.version.split()[0])

# --- MUMPS --------------------------------------------------------------------------
default = kwant.solvers.default
name = getattr(default, "__name__", "") or type(default).__module__
try:
    import kwant.solvers.mumps  # noqa: F401
    has_mumps = True
except Exception as e:  # pragma: no cover
    print("  mumps import:", e)
    has_mumps = False
check(has_mumps, "kwant.solvers.mumps imports")
solver_mod = type(default.smatrix.__self__).__module__
check(solver_mod == "kwant.solvers.mumps", "default solver is MUMPS (" + solver_mod + ")")

# --- zigzag ribbon ------------------------------------------------------------------
t = 1.0
lat = kwant.lattice.honeycomb(a=1.0, norbs=1)
a_sub, b_sub = lat.sublattices
W, L = 30.0, 20.0  # in units of a; zigzag edges run along x for honeycomb()'s default orientation


def ribbon(pos):
    x, y = pos
    return 0 <= x < L and 0 <= y < W


def lead_shape(pos):
    return 0 <= pos[1] < W


syst = kwant.Builder()
syst[lat.shape(ribbon, (0, 0))] = 0.0
syst[lat.neighbors()] = -t
sym = kwant.TranslationalSymmetry(lat.vec((-1, 0)))
lead = kwant.Builder(sym)
lead[lat.shape(lead_shape, (0, 0))] = 0.0
lead[lat.neighbors()] = -t
# a straight cut leaves one-neighbour (bearded) sites on one edge; remove them so both
# edges are true zigzag (a bearded ribbon is gapped and gives plateaus 0, 2, 4)
syst.eradicate_dangling()
lead.eradicate_dangling()
syst.attach_lead(lead)
syst.attach_lead(lead.reversed())
fsyst = syst.finalized()
print("  sites:", len(fsyst.sites))

Es = np.linspace(0.005, 0.35, 140)
t0 = time.time()
G = np.array([kwant.smatrix(fsyst, E).transmission(1, 0) for E in Es])
print("  sweep time %.1f s" % (time.time() - t0))

# plateaus: G should sit at integers and take the odd values 1, 3, 5 in turn
near_int = np.abs(G - np.round(G)) < 0.02
check(near_int.mean() > 0.85, "G on integer plateaus at %.0f%% of energies" % (100 * near_int.mean()))
vals = sorted(set(int(round(g)) for g, ok in zip(G, near_int) if ok))
print("  plateau values:", vals)
check(vals[:3] == [1, 3, 5], "first plateaus are 1, 3, 5 (zigzag graphene)")
check(np.all(np.diff(np.round(G)) >= 0), "G non-decreasing with E (no spurious dips)")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import os
    out = os.path.join(os.path.dirname(__file__), "..", "results", "g0_ribbon.png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    plt.figure(figsize=(5, 3.2))
    plt.plot(Es, G, "-k")
    plt.xlabel("E / t")
    plt.ylabel("G (e$^2$/h, spinless)")
    plt.title("G0: zigzag ribbon, W = 30 a")
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out, dpi=130)
    print("  figure:", os.path.normpath(out))
except Exception as e:
    print("  (no figure:", e, ")")

print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
