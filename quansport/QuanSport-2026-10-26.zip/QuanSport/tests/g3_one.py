"""One G3 case in its own process (clean peak-memory figure): g3_one.py <s> <w_nm> <B,B,...>"""
import json
import math
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from qtrans.synth import make_deck  # noqa: E402
from qtrans import device as D, output  # noqa: E402
from qtrans.worker import peak_mb  # noqa: E402

s, w = float(sys.argv[1]), float(sys.argv[2])
Bs = [float(x) for x in sys.argv[3].split(",")]
src_nm = float(sys.argv[4]) if len(sys.argv) > 4 else 20.0   # emitter width
size = float(sys.argv[5]) if len(sys.argv) > 5 else 1.0      # device side (um); the dot scales with it

# density map: n = +1e12 everywhere, p = -1e12 inside the dot (centre 0.55, 0.5 um, radius 0.25 um),
# a 20 nm tanh like the DFM decks (the builder rebuilds the junction from the contour anyway)
L, N0, R, XC, YC, RAMP = size, 1e12, 0.25 * size, 0.55 * size, 0.5 * size, 0.02
nm = 256
data = []
for j in range(nm):
    y = (1 - j / (nm - 1)) * L
    for i in range(nm):
        x = i / (nm - 1) * L
        data.append(-N0 * math.tanh((R - math.hypot(x - XC, y - YC)) / RAMP))
hs = 0.5 * src_nm / (L * 1e3)
deck = make_deck(L, L, [("source", "source", 0, 0.5 - hs, 0.005, 0.5 + hs),
                        ("back", "drain", 0.995, 0, 1, 1),
                        ("top", "drain", 0.45, 0.99, 0.99, 1),
                        ("bottom", "drain", 0.45, 0, 0.99, 0.01)],
                 edge="absorbing", pn_width_nm=w, density=(nm, nm, data), name="g3 dot")
t0 = time.time()
dev = D.build_device(deck, s=s)
build_s = time.time() - t0
j0 = dev.leads.index("source")
out = {"s": s, "w": w, "src_nm": src_nm, "modes": [], "sites": dev.n_sites, "build_s": build_s, "B": Bs, "T": [], "absorbed": [], "secs": [], "maps": [],
       "notes": dev.notes}
for B in Bs:
    t1 = time.time()
    r = D.solve(dev, B=B, wavefunction_from=j0)
    N0m = r["N"][j0]
    out["modes"].append(N0m)
    out["T"].append({dev.leads[k]: r["T"][k][j0] / N0m for k in range(len(dev.leads)) if k != j0})
    out["absorbed"].append(r["absorbed"][j0])
    m = output.density_map(dev, r["psi"], 100, 100)
    out["maps"].append((m / m.sum()).tolist())
    out["secs"].append(time.time() - t1)
out["peakMB"] = peak_mb()
print(json.dumps(out))
