"""G2e: the on-site potential the builder puts on the lattice (no transport solve, seconds).

For the Veselago dot (p dot of radius R in n graphene, |n| = 1e12) at two device sizes and two junction
widths: deep inside the dot U = +hbar v_F k_F (p plateau), far outside U = -hbar v_F k_F (n plateau), and
along a radial cut the potential follows Cayssol's profile kF(x) = k1 + (k2 - k1)/(exp(-x/d) + 1) about
the contour (x = distance outside the dot). This is the check that would have caught the silent zero
plateau of 2026-10-21 (DESIGN.md, Findings).

    python tests/g2_potential.py
"""
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from qtrans.synth import make_deck  # noqa: E402
from qtrans.model import Graphene  # noqa: E402
from qtrans.device import potential_function, Options  # noqa: E402
from qtrans.klein import profile_k  # noqa: E402

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


def dot_deck(size, w):
    L, N0, R, XC, YC, RAMP, nm = size, 1e12, 0.25 * size, 0.55 * size, 0.5 * size, 0.02, 256
    data = [-N0 * math.tanh((R - math.hypot(i / (nm - 1) * L - XC, (1 - j / (nm - 1)) * L - YC)) / RAMP)
            for j in range(nm) for i in range(nm)]
    return make_deck(L, L, [("source", "source", 0, 0.49, 0.005, 0.51)], pn_width_nm=w, density=(nm, nm, data)), R, XC, YC


g = Graphene(s=10)
kF = float(abs(g.kF_signed(1e12)))
Uf = g.hvF * kF
for size in (1.0, 0.5):
    for w in (2.5, 40.0):
        deck, R, XC, YC = dot_deck(size, w)
        notes = []
        U = potential_function(deck, g, Options(), notes)
        Rn, xc, yc = R * 1e3, XC * 1e3, YC * 1e3
        u_in = float(U(np.array([xc]), np.array([yc]))[0])
        u_out = float(U(np.array([20.0]), np.array([20.0]))[0])
        # reference contour = the zero of the bilinear MAP along the cut (what transim sees), not the
        # analytic circle: the 256-pixel map moves it by a fraction of a pixel
        lo, hi = xc + 0.5 * Rn, xc + 1.5 * Rn
        for _ in range(60):
            mid = 0.5 * (lo + hi)
            if deck.density_cm2(mid / 1e3, yc / 1e3) < 0:
                lo = mid
            else:
                hi = mid
        Rmap = 0.5 * (lo + hi) - xc
        x = np.linspace(-0.9 * Rn, min(0.9 * Rn, size * 1e3 - xc - Rmap - 5), 601)   # distance outside the map contour, inside the device
        Ucut = U(xc + Rmap + x, np.full_like(x, yc))
        # shape after aligning (a sharp step is so steep that a sub-nm contour shift alone gives a large
        # pointwise error), and the alignment itself = where the builder puts the contour
        shifts = np.linspace(-1.5, 1.5, 61)
        errs = [float(np.max(np.abs(Ucut - g.U_of_k(profile_k(x - dx, -kF, kF, w))))) / Uf for dx in shifts]
        k = int(np.argmin(errs))
        err, dx = errs[k], shifts[k]
        u_in_th = float(g.U_of_k(profile_k(np.array([-Rn]), -kF, kF, w))[0])   # the profile at the dot centre
        print("  size %.1f um, w = %g nm: U(dot centre) %+.4f eV (profile %+.4f), U(corner) %+.4f eV, radial cut vs "
              "Cayssol: shape %.3f E_F, contour at %+.2f nm | %s" % (size, w, u_in, u_in_th, u_out, err, dx, notes[0] if notes else ""))
        check(abs(u_in - u_in_th) < 0.02 * Uf, "size %.1f, w = %g: dot centre at the profile's value (%+.4f eV)" % (size, w, u_in_th))
        check(abs(u_out + Uf) < 0.02 * Uf, "size %.1f, w = %g: n plateau outside (U = -%.4f eV)" % (size, w, Uf))
        # tolerance = what a position error of a quarter lattice spacing costs on the steepest part of the
        # profile (slope E_F / (2 d)), floor 0.03 E_F: finer than that the lattice cannot resolve anyway
        tol = max(0.03, 0.25 * g.acc / (2 * w)) if w > 0 else 0.03
        check(err < tol, "size %.1f, w = %g: radial profile has Cayssol's shape (max error %.3f E_F after alignment, tolerance %.3f)" % (size, w, err, tol))
        check(abs(dx) < 0.5 * g.acc, "size %.1f, w = %g: contour within half a lattice spacing of the true circle (%+.2f nm)" % (size, w, dx))

print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
