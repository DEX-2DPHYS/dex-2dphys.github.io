"""G1: every transim example deck loads; contacts and density maps round-trip; density sampling
and obstacle tests agree with transim's own C++ (FieldMap::sample, inObstacle), built from the
live plugin.cpp by tests/g1_ref.cpp.

    python tests/g1_deck.py
"""
import glob
import json
import os
import subprocess
import sys
import tempfile

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from qtrans import deck as dk  # noqa: E402

# transim next door (working copy) or inside the package (qtrans/paths.py), never a user folder
from qtrans import paths  # noqa: E402
TRANSIM = paths.TRANSIM
EXAMPLES = paths.EXAMPLES

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


# --- 1. load every example ----------------------------------------------------------
files = sorted(glob.glob(os.path.join(EXAMPLES, "*.transim.json")))
listed = [e["file"] for e in json.load(open(os.path.join(EXAMPLES, "index.json"), encoding="utf-8"))["examples"]]
check(sorted(listed) == [os.path.basename(f) for f in files],
      "the %d decks on disk are exactly those listed in index.json (%d)" % (len(files), len(listed)))
decks = []
for f in files:
    try:
        d = dk.load(f)
        decks.append((f, d))
        print("  " + d.summary())
    except Exception as e:
        check(False, "load %s: %s" % (os.path.basename(f), e))
check(len(decks) == len(files), "all decks load")

# --- 2. round trip ------------------------------------------------------------------
for f, d in decks:
    raw = json.load(open(f, encoding="utf-8"))
    d2 = dk.parse(json.loads(json.dumps(d.to_json())))
    same_c = [c.to_json() for c in d2.contacts] == [
        {"id": c["id"], "role": c["role"], "x0": c["x0"], "y0": c["y0"], "x1": c["x1"], "y1": c["y1"]}
        for c in raw["contacts"]]
    same_m = (d.density is None and d2.density is None) or (
        d.density is not None and d2.density is not None and np.array_equal(d.density.data, d2.density.data))
    check(same_c and same_m and d2.sha256 == d.sha256,
          "round trip %s (contacts %s, density %s, hash %s)" % (
              os.path.basename(f), same_c, same_m, d2.sha256 == d.sha256))

# --- 3. orientation: row 0 is the top ------------------------------------------------
m = dk.FieldMap(3, 2, np.array([[1, 2, 3], [4, 5, 6]], dtype=np.float32))
check(m.sample(0, 1) == 1 and m.sample(1, 1) == 3 and m.sample(0, 0) == 4 and m.sample(1, 0) == 6,
      "corners: (0,1)=top-left=row0[0], (0,0)=bottom-left=last row")
check(abs(m.sample(0.5, 0.5) - 3.5) < 1e-12, "centre is the bilinear mean")
check(m.sample(-1, 2) == 1 and m.sample(5, -3) == 6, "outside the device clamps to the edge")

# --- 4. against transim's C++ -------------------------------------------------------
gpp = None
for cand in ["g++"] + glob.glob(os.path.expandvars(
        r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\BrechtSanders.WinLibs*\mingw64\bin\g++.exe")):
    try:
        subprocess.run([cand, "--version"], capture_output=True, check=True)
        gpp = cand
        break
    except Exception:
        pass
work = os.path.join(tempfile.gettempdir(), "qtrans-g1")
os.makedirs(work, exist_ok=True)
exe = os.path.join(work, "g1_ref.exe")
src = os.path.join(HERE, "g1_ref.cpp")
shipped = paths.prebuilt("g1_ref")  # a downloaded package carries it, built from its own sources
if shipped:
    exe = shipped
if gpp is None and not shipped:
    check(False, "g++ found (needed to build transim's reference sampler)")
else:
    need = not shipped and (not os.path.exists(exe) or os.path.getmtime(exe) < max(
        os.path.getmtime(src), os.path.getmtime(os.path.join(TRANSIM, "src", "plugin.cpp"))))
    if need:
        r = subprocess.run([gpp, "-std=c++17", "-O2", "-fno-fast-math", "-static", "-fopenmp",
                            "-I", os.path.join(TRANSIM, "src"), "-o", exe, src],
                           capture_output=True, text=True)
        check(r.returncode == 0, "build g1_ref against transim/src/plugin.cpp")
        if r.returncode:
            print(r.stderr[-2000:])
    rng = np.random.default_rng(1)
    for f, d in decks:
        if d.density is None and not any(c.is_obstacle() for c in d.contacts):
            continue
        fm = d.density or dk.FieldMap(2, 2, np.zeros((2, 2), np.float32))
        # random points, grid nodes, cell edges, the four corners and points outside
        pts = list(rng.random((400, 2)))
        pts += [(i / (fm.w - 1), 1 - j / (fm.h - 1)) for i in (0, fm.w // 3, fm.w - 1) for j in (0, fm.h // 2, fm.h - 1)]
        pts += [(0, 0), (1, 1), (0, 1), (1, 0), (-0.2, 0.5), (0.5, 1.3)]
        for c in d.contacts:  # around every obstacle
            if c.is_obstacle():
                cx, cy = 0.5 * (c.x0 + c.x1), 0.5 * (c.y0 + c.y1)
                for t in np.linspace(0, 2 * np.pi, 40, endpoint=False):
                    for r in (0.5, 0.98, 1.02, 1.5):
                        pts.append((cx + r * 0.5 * (c.x1 - c.x0) * np.cos(t), cy + r * 0.5 * (c.y1 - c.y0) * np.sin(t)))
        txt = os.path.join(work, "in.txt")
        with open(txt, "w") as fo:
            fo.write("%d %d\n" % (fm.w, fm.h))
            fo.write(" ".join("%.9g" % v for v in fm.data.ravel()) + "\n")
            fo.write("%d\n" % len(d.contacts))
            for c in d.contacts:
                fo.write("%s %.17g %.17g %.17g %.17g\n" % (c.role, c.x0, c.y0, c.x1, c.y1))
            fo.write("%d\n" % len(pts))
            for x, y in pts:
                fo.write("%.17g %.17g\n" % (x, y))
        out = subprocess.run([exe, txt], capture_output=True, text=True)
        if out.returncode:
            check(False, "g1_ref ran on %s (exit %d; Smart App Control?)" % (os.path.basename(f), out.returncode))
            continue
        ref = np.array([[float(a) for a in ln.split()] for ln in out.stdout.strip().splitlines()])
        xs, ys = np.array(pts).T
        mine = fm.sample(xs, ys)
        obs = np.array([any(c.in_obstacle(x, y) for c in d.contacts) for x, y in pts])
        scale = max(1.0, float(np.abs(fm.data).max()))
        err = np.max(np.abs(mine - ref[:, 0])) / scale
        check(err < 1e-12 and np.array_equal(obs, ref[:, 1].astype(bool)),
              "%s: %d points, sampling rel. err %.1e, obstacles agree %s" % (
                  os.path.basename(f), len(pts), err, np.array_equal(obs, ref[:, 1].astype(bool))))

print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
