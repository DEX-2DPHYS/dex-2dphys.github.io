"""Diagnostic (2026-10-21, Q4 finding): does the quantum beam bend in a field like transim's?

Two half-scale decks, 2 x 1 um, field doubled to 16 mT (deflection angle L / R_c as in the full DFM at
8 mT): (a) "plain": uniform n = 1e12, 20 nm emitter, absorbing edges, back drain; (b) "gun": the DFM gun
scaled by 1/2 (p cap behind a parabolic p-n lens of focal length 0.25 um, absorbing jaws). For each, the
beam centroid y(x) quantum vs semiclassical (transim's tracer through tsim) vs the free-electron estimate.

    python tests/beam_bend.py [--s 10]
"""
import argparse
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from qtrans.synth import make_deck  # noqa: E402
from qtrans import device as D, output, semiclassical  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("--s", type=float, default=10)
ap.add_argument("--B", type=float, default=0.016)
a = ap.parse_args()

W, H, YC, N0, RAMP = 2.0, 1.0, 0.5, 1e12, 0.02
XF, FPAR = 0.005, 0.25


def gun_density(x, y):
    dy = y - YC
    xp = XF + FPAR - dy * dy / (4 * FPAR)
    gpar = (xp - x) / math.sqrt(1 + (dy / (2 * FPAR)) ** 2)
    return -N0 * math.tanh(gpar / RAMP)


def deck(kind):
    contacts = [("source", "source", 0.0, (YC - 0.01) / H, 0.005, (YC + 0.01) / H), ("back", "drain", 0.995, 0, 1, 1)]
    dens = None
    if kind == "gun":
        aa, t, L = 0.04, 0.03, 0.125
        contacts += [("jawTop", "absorber", 0, (YC + aa) / H, L / W, (YC + aa + t) / H),
                     ("jawBottom", "absorber", 0, (YC - aa - t) / H, L / W, (YC - aa) / H)]
        nm = 256
        data = [gun_density(i / (nm - 1) * W, (1 - j / (nm - 1)) * H) for j in range(nm) for i in range(nm)]
        dens = (nm, nm, data)
    return make_deck(W, H, contacts, edge="absorbing", pn_width_nm=2.5, density=dens, name="bend-" + kind)


Rc = 1.0546e-34 * math.sqrt(math.pi * 1e16) / (1.602e-19 * a.B) * 1e6   # um
xs = (0.5, 1.0, 1.5, 1.8)
gx, gy = 400, 200
print("R_c = %.2f um at %g mT; s = %g" % (Rc, a.B * 1e3, a.s))
for kind in ("plain", "gun"):
    dk = deck(kind)
    raw = dk.to_json()
    dev = D.build_device(dk, s=a.s)
    j0 = dev.leads.index("source")
    cl = {r["B"]: r for r in semiclassical.run(raw, [0.0, a.B], n_traj=300000, traj_res=gx)}
    for B in (0.0, a.B):
        r = D.solve(dev, B=B, wavefunction_from=j0)
        q = output.density_map(dev, r["psi"], gx, gy)
        c = np.array(cl[B]["d"], float).reshape(cl[B]["gy"], cl[B]["gx"])
        row = []
        for name, m in (("quantum", q), ("transim", c)):
            ys = (np.arange(m.shape[0]) + 0.5) / m.shape[0] * H
            cs = []
            for x in xs:
                col = m[:, int(x / W * m.shape[1])]
                win = np.abs(ys - YC) < 0.35
                cs.append(np.sum(col[win] * ys[win]) / np.sum(col[win]) - YC)
            row.append("%s %s" % (name, " ".join("%+.3f" % v for v in cs)))
        est = " ".join("%+.3f" % (x * x / (2 * Rc) if B else 0.0) for x in xs)
        print("%-5s B = %5.1f mT | dy at x = %s um: %s | free from x=0: %s" % (kind, B * 1e3, xs, " | ".join(row), est))
