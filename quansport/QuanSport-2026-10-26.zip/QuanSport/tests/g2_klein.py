"""G2a: Klein tunnelling across a p-n junction in the scalable TB lattice, against the analytic laws in
qtrans.klein (ported from transim's tracer), on a strip periodic along the junction.

The junction runs along a ZIGZAG line, so one Bloch phase selects one valley. Within one valley
trigonal warping makes +theta and -theta differ by an amount proportional to k_F a_s; the other
valley is the mirror image, so the physical (two-valley) transmission is the valley average
T(theta) = [T_K(theta) + T_K(-theta)] / 2, and that is what is compared with the continuum laws.

  sharp step (lattice-sharp, d = 0): Cheianov-Fal'ko, cos^2 theta when symmetric
  d = 2.5 nm (the DFM decks' width) and d = 40 nm: Cayssol et al. Eq. 10

    python tests/g2_klein.py
"""
import math
import os
import sys
import time

import numpy as np
import kwant

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from qtrans.model import Graphene  # noqa: E402
from qtrans import build, klein  # noqa: E402

fails = []


def check(ok, what):
    print(("[ OK ] " if ok else "[FAIL] ") + what)
    if not ok:
        fails.append(what)


thetas = np.radians(np.linspace(-70, 70, 29))
mid = len(thetas) // 2


def run(s, n1, n2, d):
    g = Graphene(s=s)
    k1, k2 = float(g.kF_signed(n1)), float(g.kF_signed(n2))
    g.check_U([g.U_of_k(k1), g.U_of_k(k2)])
    half = max(120.0, 14 * d)
    fs = build.ribbon_y(g, lambda y: float(g.U_of_k(klein.profile_k(y, k1, k2, d))), -half, half,
                        float(g.U_of_k(k1)), float(g.U_of_k(k2)))
    TK, modes = [], set()
    for th in thetas:
        sm = kwant.smatrix(fs, 0.0, params=dict(phase=build.phase_for_angle(g, th, abs(k1))))
        TK.append(sm.transmission(1, 0))
        modes.add(int(sm.num_propagating(0)))
    TK = np.array(TK)
    Tv = 0.5 * (TK + TK[::-1])
    Ta = np.array([klein.smooth(th, k1, k2, d) for th in thetas])
    return dict(TK=TK, Tv=Tv, Ta=Ta, err=float(np.max(np.abs(Tv - Ta))), modes=modes)


t0 = time.time()
print(Graphene(s=10).summary())
R = {}
for key, s, n2, d in (("sharp", 10, -1e12, 0), ("sharp3", 10, -3e12, 0), ("d2.5", 10, -1e12, 2.5),
                      ("d40", 10, -1e12, 40), ("sharp_s5", 5, -1e12, 0)):
    R[key] = r = run(s, 1e12, n2, d)
    print("  s=%g n2=%.0e d=%g nm: valley-avg max|T - analytic| = %.4f, T(0) = %.4f, modes %s" % (
        s, n2, d, r["err"], r["Tv"][mid], sorted(r["modes"])))

check(all(R[k]["modes"] == {1} for k in R), "one incoming mode per Bloch phase (valleys kept apart)")
check(R["sharp"]["err"] < 0.05, "sharp symmetric step: cos^2 theta within 0.05 (%.3f)" % R["sharp"]["err"])
check(R["sharp3"]["err"] < 0.08, "sharp step 1e12 | -3e12: Cheianov-Fal'ko within 0.08 (%.3f)" % R["sharp3"]["err"])
check(R["sharp_s5"]["err"] < 0.5 * R["sharp"]["err"],
      "the sharp-step deviation is a lattice effect: halving s at least halves it (%.3f -> %.3f)" % (
          R["sharp"]["err"], R["sharp_s5"]["err"]))
check(R["d2.5"]["err"] < 0.03, "d = 2.5 nm: Cayssol within 0.03 (%.3f)" % R["d2.5"]["err"])
check(R["d40"]["err"] < 0.01, "d = 40 nm: Cayssol within 0.01 (%.4f)" % R["d40"]["err"])
check(R["d40"]["Tv"][mid] > 0.999, "perfect Klein tunnelling at normal incidence, d = 40 nm (%.5f)" % R["d40"]["Tv"][mid])
fw = lambda T: np.ptp(np.degrees(thetas[T >= 0.5]))
check(fw(R["d40"]["Tv"]) < 0.5 * fw(R["sharp"]["Tv"]), "smooth junction narrows the window: T >= 1/2 over %.0f deg vs %.0f deg sharp" % (
    fw(R["d40"]["Tv"]), fw(R["sharp"]["Tv"])))
print("  total %.1f s" % (time.time() - t0))

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    th = np.degrees(thetas)
    for key, lab, c in (("sharp", "sharp step, symmetric", "C0"), ("sharp3", "sharp step, 1e12 | -3e12", "C1"),
                        ("d2.5", "d = 2.5 nm", "C3"), ("d40", "d = 40 nm", "C2")):
        ax.plot(th, R[key]["Ta"], "-", color=c, lw=1.2)
        ax.plot(th, R[key]["Tv"], "o", color=c, ms=3.5, label=lab)
        ax.plot(th, R[key]["TK"], ".", color=c, ms=2, alpha=0.35)
    ax.set_xlabel("incidence angle (deg)")
    ax.set_ylabel("transmission")
    ax.set_title("G2: Klein tunnelling, TB s = 10, n = 1e12 cm$^{-2}$\n"
                 "dots: valley average, faint: one valley, lines: analytic", fontsize=9)
    ax.legend(fontsize=8, frameon=False, loc="lower center")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    out = os.path.join(HERE, "..", "results", "g2_klein.png")
    fig.savefig(out, dpi=130)
    print("  figure:", os.path.normpath(out))
except Exception as e:
    print("  (no figure:", e, ")")

print("ALL CLEAR" if not fails else "FAILURES: %d" % len(fails))
sys.exit(1 if fails else 0)
