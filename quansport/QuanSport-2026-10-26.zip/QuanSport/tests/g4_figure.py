"""G4 figure: the full DFM decks (Fig. 4 of the paper) from QuanSport run records, quantum next to
transim's semiclassical tracer, at every field that has maps; plus T(B) for back/top/bottom.

    python tests/g4_figure.py <run id vd25> <run id vd40> [out.png]
Run records are read from %LOCALAPPDATA%\\QuanSport\\runs\\<id>.json.
"""
import json
import os
import sys

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
RUNS = os.path.join(os.environ.get("LOCALAPPDATA", ""), "QuanSport", "runs")


def load(rid):
    return json.load(open(os.path.join(RUNS, rid + ".json"), encoding="utf-8"))


def logmap(data, gx, gy):
    a = np.array(data, float).reshape(gy, gx)
    a = a / a.sum()
    return np.log10(a + 1e-7)


ids = sys.argv[1:3]
out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, "..", "results", "g4_dfm_fig4.png")
runs = [load(i) for i in ids]
Bs = runs[0]["job"]["B"]
fig, axes = plt.subplots(len(Bs) * 2 + 1, 2, figsize=(11, 3.1 * len(Bs) * 2 + 3), gridspec_kw={"height_ratios": [1] * (2 * len(Bs)) + [1.3]})
for col, run in enumerate(runs):
    P = run["job"]["deck"]["params"]
    W, H = P["W_um"], P["H_um"]
    for i, B in enumerate(Bs):
        q = next(m for m in run["maps"] if m["kind"] == "density" and abs(m["B"] - B) < 1e-12)
        c = next(m for m in run["classical"] if abs(m["B"] - B) < 1e-12)
        for k, (title, data, gx, gy) in enumerate((("quantum", q["data"], q["gx"], q["gy"]),
                                                     ("semiclassical (transim)", c["d"], c["gx"], c["gy"]))):
            ax = axes[2 * i + k, col]
            img = logmap(data, gx, gy)
            ax.imshow(img, origin="lower", extent=[0, W, 0, H], cmap="viridis", vmin=img.max() - 4, vmax=img.max(), aspect="equal")
            for ct in run["job"]["deck"]["contacts"]:
                colr = {"source": "#ff5533", "drain": "#4da3ff", "absorber": "#dddddd", "reflector": "#ff66cc"}.get(ct["role"], "w")
                ax.add_patch(plt.Rectangle((ct["x0"] * W, ct["y0"] * H), (ct["x1"] - ct["x0"]) * W, (ct["y1"] - ct["y0"]) * H,
                                           fill=False, ec=colr, lw=1.2))
            ax.set_title("pn %g nm, B = %g mT: %s" % (P["pnWidth_nm"], B * 1e3, title), fontsize=9)
            ax.set_xlabel("x (um)", fontsize=8)
            ax.set_ylabel("y (um)", fontsize=8)
            ax.tick_params(labelsize=7)
    ax = axes[-1, col]
    q = sorted(run["points"], key=lambda p: p["B"])
    c = sorted(run["classical"], key=lambda p: p["B"])
    for key, colr in (("back", "C0"), ("top", "C3"), ("bottom", "C4")):
        ax.plot([p["B"] * 1e3 for p in q], [p["T"][key] for p in q], "-o", color=colr, ms=4, label="%s, quantum" % key)
        ax.plot([p["B"] * 1e3 for p in c], [p["T"][key] for p in c], "--s", color=colr, ms=3, mfc="none", label="%s, semiclassical" % key)
    ax.set_xlabel("B (mT)", fontsize=8)
    ax.set_ylabel("T per source mode / per trajectory", fontsize=8)
    ax.set_title("pn %g nm: transmission" % P["pnWidth_nm"], fontsize=9)
    ax.tick_params(labelsize=7)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=6.5, ncol=2, frameon=False)
fig.suptitle("G4: DFM Fig. 4 decks, s = %g, %s sites (log |psi|^2 and log trajectory density, 4 decades)" % (
    runs[0]["job"]["s"], format(runs[0]["built"]["sites"], ",")), fontsize=10)
fig.tight_layout()
fig.savefig(out, dpi=110)
print("figure:", os.path.normpath(out))
