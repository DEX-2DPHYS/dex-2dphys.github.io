@echo off
rem One-time setup on a PC (double-click). For the current Windows user only: no administrator rights needed.
rem   - .ipe files open in Interactive Presenter on double-click
rem   - an Interactive Presenter icon on the desktop
rem   - right-click a PowerPoint file (.pptx / .ppt) -> "Import into Interactive Presenter"
rem     (needs PowerPoint on the PC; Windows 11: under "Show more options")
rem Keep this folder where it is afterwards: the entries point here. Moved it? Run this again.
rem Uninstall Interactive Presenter.cmd removes all of it again.
title Install Interactive Presenter
echo.
echo   Installing Interactive Presenter for %USERNAME% ...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0register-ipe.ps1"
if errorlevel 1 (
  echo.
  echo   Something went wrong - see the message above.
  pause
  exit /b 1
)
echo.
echo   Done:
echo     - double-click an .ipe file to open it
echo     - the desktop icon "Interactive Presenter" opens an empty presenter
echo     - right-click a PowerPoint file: "Import into Interactive Presenter"
echo       (Windows 11: first "Show more options"; needs PowerPoint)
echo     - the helper for Browse... and Import PowerPoint... in the app
echo       (the browser asks once before it starts it: allow it)
echo.
echo   Needs Google Chrome or Microsoft Edge.
echo.
pause
