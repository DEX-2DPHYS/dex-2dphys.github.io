# PowerPoint (.pptx / .ppt) -> folder for Interactive Presenter's PowerPoint import.
#   powershell -File pptx-export.ps1 -File "talk.pptx" -Out "<folder>"   (writes <folder>\manifest.json + PNGs)
# Uses PowerPoint itself (COM), so it needs PowerPoint on this PC. The presentation is opened read-only and
# closed without saving; the original file is never changed.
#
# Per slide:
#   - text boxes and placeholders with text (not rotated, not in a group): their paragraphs and runs with the
#     formatting PowerPoint actually uses (size, bold, italic, colour, font, alignment, bullets) -> editable text
#   - pictures (not rotated): exported as PNG -> movable image overlays
#   - the slide rendered WITHOUT those (their text blanked, pictures hidden) -> the background picture, so
#     shapes, fills, tables, charts, SmartArt, equations and theme graphics keep their exact look
#   - the full slide rendered as it is (full\N.png) for comparison / fallback
#   - the speaker notes as text
param(
  [Parameter(Mandatory = $true)][string]$File,
  [Parameter(Mandatory = $true)][string]$Out,
  [int]$Width = 1920
)
$ErrorActionPreference = 'Stop'
$full = (Resolve-Path -LiteralPath $File).ProviderPath
foreach ($d in 'bg', 'full', 'pic') { New-Item -ItemType Directory -Force -Path (Join-Path $Out $d) | Out-Null }

function Hex([int]$bgr) { $r = $bgr -band 0xFF; $g = ($bgr -shr 8) -band 0xFF; $b = ($bgr -shr 16) -band 0xFF; '#{0:x2}{1:x2}{2:x2}' -f $r, $g, $b }
function TrueOf($v) { return ($v -eq -1) -or ($v -eq $true) }

$app = New-Object -ComObject PowerPoint.Application
$hadOpen = $app.Presentations.Count
# Open(FileName, ReadOnly, Untitled, WithWindow)
$pres = $app.Presentations.Open($full, -1, 0, 0)
try {
  $W = [double]$pres.PageSetup.SlideWidth; $H = [double]$pres.PageSetup.SlideHeight
  $Hpx = [int][Math]::Round($Width * $H / $W)
  # "Shrink text on overflow": PowerPoint draws such text smaller (normAutofit fontScale, lnSpcReduction), but
  # Font.Size reports the nominal size. The scale is only in the file, so read it from a .pptx copy's XML:
  # $fit["<SlideID>/<shape id>"] = @{ scale; lineReduction }
  $fit = @{}
  try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $copy = Join-Path $Out 'copy.pptx'
    $pres.SaveCopyAs($copy, 24) # ppSaveAsOpenXMLPresentation (also turns a .ppt into XML)
    $zip = [IO.Compression.ZipFile]::OpenRead($copy)
    $readXml = { param($name) $e = $zip.GetEntry($name); if (-not $e) { return $null }; $s = New-Object IO.StreamReader($e.Open()); $x = New-Object Xml.XmlDocument; $x.LoadXml($s.ReadToEnd()); $s.Close(); $x }
    $presXml = & $readXml 'ppt/presentation.xml'
    $rels = & $readXml 'ppt/_rels/presentation.xml.rels'
    $target = @{}; foreach ($r in $rels.SelectNodes("//*[local-name()='Relationship']")) { $target[$r.Id] = $r.Target }
    foreach ($sid in $presXml.SelectNodes("//*[local-name()='sldId']")) {
      $rid = $sid.GetAttribute('id', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')
      $sx = & $readXml ('ppt/' + ($target[$rid] -replace '^/?ppt/', ''))
      if (-not $sx) { continue }
      foreach ($af in $sx.SelectNodes("//*[local-name()='normAutofit'][@fontScale or @lnSpcReduction]")) {
        $sp = $af.ParentNode.ParentNode # bodyPr -> txBody -> sp
        while ($sp -and $sp.LocalName -ne 'sp') { $sp = $sp.ParentNode }
        $c = if ($sp) { $sp.SelectSingleNode(".//*[local-name()='cNvPr']") } else { $null }
        if (-not $c) { continue }
        $fs = if ($af.HasAttribute('fontScale')) { [double]$af.GetAttribute('fontScale') / 100000 } else { 1 }
        $ls = if ($af.HasAttribute('lnSpcReduction')) { [double]$af.GetAttribute('lnSpcReduction') / 100000 } else { 0 }
        $fit["$($sid.GetAttribute('id'))/$($c.GetAttribute('id'))"] = @{ scale = $fs; lineReduction = $ls }
      }
    }
    $zip.Dispose()
    Remove-Item $copy -Force -ErrorAction SilentlyContinue
  } catch { Write-Host "  (could not read the shrink-to-fit scales: $($_.Exception.Message))" }
  $slides = @()
  $n = 0
  foreach ($slide in $pres.Slides) {
    $n++
    $slide.Export((Join-Path $Out "full\$n.png"), 'PNG', $Width, $Hpx)
    $shapes = @()
    $title = ''
    $z = 0
    # the slide's animations, in order (main sequence): entrance or exit, the trigger (On Click / With Previous /
    # After Previous), delay and length in seconds, instant (Appear / Disappear) or not, and the paragraph for
    # effects on single paragraphs (bullets one by one; 0 = the whole shape)
    $anims = @(); $animated = @{}
    try {
      $seq = $slide.TimeLine.MainSequence
      for ($e = 1; $e -le $seq.Count; $e++) {
        $ef = $seq.Item($e)
        $sid = [int]$ef.Shape.Id
        $trig = switch ([int]$ef.Timing.TriggerType) { 1 { 'click' } 3 { 'after' } default { 'with' } }
        $anims += @{ shapeId = $sid; exit = (TrueOf $ef.Exit); trigger = $trig; delay = [double]$ef.Timing.TriggerDelayTime; duration = [double]$ef.Timing.Duration; fade = ([int]$ef.EffectType -ne 1); paragraph = [int]$ef.Paragraph }
        $animated[$sid] = $true
      }
    } catch { }
    # a shape as a picture overlay (PowerPoint renders it; rotated shapes in their bounding box)
    $asPicture = {
      param($sh, $box)
      $png = "pic\$n-$($sh.Id).png"
      try {
        $sh.Export((Join-Path $Out $png), 2) # ppShapeFormatPNG (hidden but long-standing method)
        if ((Get-Item (Join-Path $Out $png)).Length -gt 0) {
          $script:shapes += $box + @{ kind = 'picture'; file = $png }
          $sh.Visible = 0
        }
      } catch { }
    }
    foreach ($sh in @($slide.Shapes)) {
      $z++
      $rot = [double]$sh.Rotation
      $isPlaceholder = ($sh.Type -eq 14)
      $contained = if ($isPlaceholder) { try { $sh.PlaceholderFormat.ContainedType } catch { 0 } } else { 0 }
      $isAnimated = $animated.ContainsKey([int]$sh.Id)
      $box = @{ id = [int]$sh.Id; x = $sh.Left / $W; y = $sh.Top / $H; w = $sh.Width / $W; h = $sh.Height / $H; z = $z; name = [string]$sh.Name }
      if ($rot -ne 0) {
        # rotated: stays in the background picture, unless it is animated (then a picture of its bounding box)
        if ($isAnimated) {
          $t = $rot * [Math]::PI / 180; $cx = $sh.Left + $sh.Width / 2; $cy = $sh.Top + $sh.Height / 2
          $bw = [Math]::Abs($sh.Width * [Math]::Cos($t)) + [Math]::Abs($sh.Height * [Math]::Sin($t))
          $bh = [Math]::Abs($sh.Width * [Math]::Sin($t)) + [Math]::Abs($sh.Height * [Math]::Cos($t))
          & $asPicture $sh ($box + @{}) | Out-Null
          if ($shapes.Count -and $shapes[-1].id -eq [int]$sh.Id) { $shapes[-1].x = ($cx - $bw / 2) / $W; $shapes[-1].y = ($cy - $bh / 2) / $H; $shapes[-1].w = $bw / $W; $shapes[-1].h = $bh / $H }
        }
        continue
      }
      # entirely off the slide (e.g. a slide number parked outside): not shown, leave it alone
      if ($box.x -ge 1 -or $box.y -ge 1 -or ($box.x + $box.w) -le 0 -or ($box.y + $box.h) -le 0) { continue }
      # pictures (also a picture placeholder holding a picture)
      if ($sh.Type -eq 13 -or $contained -eq 13) { & $asPicture $sh $box; continue }
      # text
      $hasText = $false
      try { $hasText = (TrueOf $sh.HasTextFrame) -and (TrueOf $sh.TextFrame.HasText) } catch { }
      # anything else with an animation (arrow, box, line, group, chart): a picture, so it can appear / go
      if (-not $hasText) { if ($isAnimated) { & $asPicture $sh $box }; continue }
      # animated text in a filled or framed box: the box must come and go with its words, so the whole shape
      # becomes a picture (plain animated text stays editable text)
      if ($isAnimated) {
        $framed = $false; try { $framed = (TrueOf $sh.Fill.Visible) -or (TrueOf $sh.Line.Visible) } catch { }
        if ($framed) { & $asPicture $sh $box; continue }
      }
      $tf = $sh.TextFrame
      if (-not $title -and $isPlaceholder) { try { if ($sh.PlaceholderFormat.Type -in 1, 3) { $title = ($tf.TextRange.Text -replace '\s+', ' ').Trim() } } catch { } }
      $paras = @()
      $tr2 = $sh.TextFrame2.TextRange
      for ($p = 1; $p -le $tr2.Paragraphs().Count; $p++) {
        $para = $tr2.Paragraphs($p)
        $pf = $para.ParagraphFormat
        $runs = @()
        for ($r = 1; $r -le $para.Runs().Count; $r++) {
          $run = $para.Runs($r)
          $t = [string]$run.Text -replace "[\r\n\v]+$", ''
          if ($t -eq '') { continue }
          $f = $run.Font
          $color = '#000000'; try { $color = Hex $f.Fill.ForeColor.RGB } catch { }
          $runs += @{ text = $t; size = [double]$f.Size; bold = (TrueOf $f.Bold); italic = (TrueOf $f.Italic); underline = ($f.UnderlineStyle -ne 0); color = $color; font = [string]$f.Name; sup = ($f.BaselineOffset -gt 0); sub = ($f.BaselineOffset -lt 0) }
        }
        $align = switch ([int]$pf.Alignment) { 2 { 'center' } 3 { 'right' } 4 { 'justify' } 5 { 'justify' } default { 'left' } }
        $bullet = $false; try { $bullet = (TrueOf $pf.Bullet.Visible) -and ($pf.Bullet.Type -ne 0) } catch { }
        $paras += @{ runs = $runs; align = $align; bullet = $bullet; level = [int]$pf.IndentLevel }
      }
      $valign = switch ([int]$tf.VerticalAnchor) { 3 { 'middle' } 4 { 'bottom' } 5 { 'bottom' } default { 'top' } }
      $f = $fit["$($slide.SlideID)/$($sh.Id)"]
      $margins = @{ left = [double]$tf.MarginLeft; top = [double]$tf.MarginTop; right = [double]$tf.MarginRight; bottom = [double]$tf.MarginBottom }
      $isNumber = $false; try { $isNumber = $isPlaceholder -and ($sh.PlaceholderFormat.Type -eq 13) } catch { } # ppPlaceholderSlideNumber
      $shapes += $box + @{ kind = 'text'; paragraphs = $paras; valign = $valign; margins = $margins; fontScale = $(if ($f) { $f.scale } else { 1 }); lineReduction = $(if ($f) { $f.lineReduction } else { 0 }); slideNumber = $isNumber }
      $tf.TextRange.Text = ''   # blanked in this read-only copy, so the background keeps the box but not the words
    }
    $slide.Export((Join-Path $Out "bg\$n.png"), 'PNG', $Width, $Hpx)
    $notes = ''
    try { $notes = [string]$slide.NotesPage.Shapes.Placeholders(2).TextFrame.TextRange.Text } catch { }
    $hidden = $false; try { $hidden = TrueOf $slide.SlideShowTransition.Hidden } catch { }
    $slides += @{ n = $n; bg = "bg/$n.png"; full = "full/$n.png"; title = $title; notes = $notes; hidden = $hidden; shapes = $shapes; animations = $anims }
  }
  $manifest = @{ source = (Split-Path $full -Leaf); title = [IO.Path]::GetFileNameWithoutExtension($full); slideWidthPt = $W; slideHeightPt = $H; widthPx = $Width; heightPx = $Hpx; slides = $slides }
  [IO.File]::WriteAllText((Join-Path $Out 'manifest.json'), ($manifest | ConvertTo-Json -Depth 12), (New-Object Text.UTF8Encoding $false))
  "exported $n slides to $Out"
} finally {
  $pres.Saved = -1
  $pres.Close()
  if ($hadOpen -eq 0 -and $app.Presentations.Count -eq 0) { $app.Quit() }
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($pres)
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)
}
