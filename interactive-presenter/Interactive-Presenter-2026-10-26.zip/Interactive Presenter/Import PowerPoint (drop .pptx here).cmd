@echo off
rem Drop a PowerPoint file (.pptx or .ppt) on this icon: PowerPoint converts it and Interactive Presenter opens
rem it (text and pictures editable, the rest as the slide picture). Save it there to keep it as an .ipe file.
rem The same is in the right-click menu of PowerPoint files ("Import into Interactive Presenter") after
rem register-ipe.ps1 has been run once.
if "%~1"=="" (
  echo.
  echo   Drag a .pptx or .ppt file onto this icon.
  echo.
  pause
  exit /b 0
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0open-ipe.ps1" "%~1"
