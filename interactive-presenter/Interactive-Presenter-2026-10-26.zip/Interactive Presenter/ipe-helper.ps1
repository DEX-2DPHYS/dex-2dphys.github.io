# The Interactive Presenter helper: does for the page what a web page may not do itself.
# Registered by register-ipe.ps1 as the "ipe-helper:" link type; the page (deck-panel.js) opens a link such as
#   ipe-helper:pickfolder?job=<id>&start=C:\Talks
#   ipe-helper:locate?job=<id>&name=Talk.ipe&size=123456&t=<ms since 1970>
#   ipe-helper:pptx?job=<id>
# and reads the answer from .ipe-jobs\<id>.json beside this script (progress in <id>.start.json).
#   pickfolder  a Windows folder dialog                       -> {"path": "C:\\Talks\\Demo"}
#   locate      where Save put a file (the browser never says) -> {"path": "C:\\Talks\\Demo\\Talk.ipe"}
#   pptx        choose a PowerPoint file, PowerPoint converts it (tools\pptx-export.ps1) -> {"manifest": "file:///..."}
# Cancelled: {"cancelled": true}; failed: {"error": "..."}.
param([string]$Uri)
$ErrorActionPreference = 'Stop'
$jobs = Join-Path $PSScriptRoot '.ipe-jobs'
New-Item -ItemType Directory -Force -Path $jobs | Out-Null
Get-ChildItem $jobs -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-1) } | Remove-Item -Force -ErrorAction SilentlyContinue

$rest = $Uri -replace '^ipe-helper:/*', ''
$action, $query = $rest -split '\?', 2
$q = @{}
foreach ($pair in ($query -split '&')) {
  if (-not $pair) { continue }
  $k, $v = $pair -split '=', 2
  $q[[Uri]::UnescapeDataString($k)] = [Uri]::UnescapeDataString(($v -replace '\+', ' '))
}
$job = [string]$q['job']
if ($job -notmatch '^[0-9a-f]{8,64}$') { exit 1 }

$utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-Json([string]$suffix, $obj) {
  $file = Join-Path $jobs "$job$suffix"
  [IO.File]::WriteAllText("$file.tmp", ($obj | ConvertTo-Json -Compress), $utf8)
  Move-Item -Force "$file.tmp" $file
}
function Stage([string]$message) { Write-Json '.start.json' @{ message = $message } }
Stage 'The helper is running.'

# a dialog needs an owner in front of the browser, or it opens behind it
Add-Type -AssemblyName System.Windows.Forms
function New-Owner {
  $f = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Width = 1; Height = 1; StartPosition = 'CenterScreen'; Opacity = 0 }
  $f.Show(); $f.Activate()
  return $f
}

try {
  switch ($action) {
    'pickfolder' {
      Stage 'Choose the folder in the Windows dialog.'
      $owner = New-Owner
      $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
      $dlg.Description = 'Interactive Presenter: the folder that holds this presentation (with its html, sims, pdf ... folders)'
      $dlg.ShowNewFolderButton = $true
      if ($q['start'] -and (Test-Path -LiteralPath $q['start'])) { $dlg.SelectedPath = $q['start'] }
      $res = $dlg.ShowDialog($owner)
      $owner.Close()
      if ($res -eq 'OK') { Write-Json '.json' @{ path = $dlg.SelectedPath } } else { Write-Json '.json' @{ cancelled = $true } }
    }
    'locate' {
      $name = [string]$q['name']; $size = [int64]$q['size']; $t = [int64]$q['t']
      if (-not $name -or $name -match '[\\/:*?"<>|]') { throw 'no file name' }
      $when = [DateTimeOffset]::FromUnixTimeMilliseconds($t).LocalDateTime
      function Fits([IO.FileInfo]$f) { $f.Length -eq $size -and [Math]::Abs(($f.LastWriteTime - $when).TotalSeconds) -lt 300 }
      $found = $null
      # 1. Windows lists files saved through its Save dialog under Recent items
      $lnk = Join-Path ([Environment]::GetFolderPath('Recent')) "$name.lnk"
      if (Test-Path -LiteralPath $lnk) {
        $target = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk).TargetPath
        if ($target -and (Test-Path -LiteralPath $target)) { $fi = Get-Item -LiteralPath $target; if (Fits $fi) { $found = $fi.FullName } }
      }
      # 2. otherwise search the user's folders for it (newest match), at most ~60 s
      if (-not $found) {
        $roots = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'), (Join-Path $env:USERPROFILE 'Downloads'), $env:USERPROFILE) |
          Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
        $skip = '^(AppData|node_modules|\.git|\$Recycle\.Bin)$'
        $deadline = (Get-Date).AddSeconds(60)
        $seen = New-Object 'System.Collections.Generic.HashSet[string]'
        $queue = New-Object 'System.Collections.Generic.Queue[string]'
        foreach ($r in $roots) { $queue.Enqueue($r) }
        $best = $null
        while ($queue.Count -and (Get-Date) -lt $deadline) {
          $d = $queue.Dequeue()
          if (-not $seen.Add($d.ToLowerInvariant())) { continue }
          try {
            foreach ($p in [IO.Directory]::EnumerateFiles($d, $name)) { $fi = [IO.FileInfo]$p; if ((Fits $fi) -and (-not $best -or $fi.LastWriteTime -gt $best.LastWriteTime)) { $best = $fi } }
            foreach ($sub in [IO.Directory]::EnumerateDirectories($d)) {
              $leaf = [IO.Path]::GetFileName($sub)
              if ($leaf -notmatch $skip -and -not (([IO.DirectoryInfo]$sub).Attributes -band [IO.FileAttributes]::ReparsePoint)) { $queue.Enqueue($sub) }
            }
          } catch { }
          if ($best) { break }
        }
        if ($best) { $found = $best.FullName }
      }
      if ($found) { Write-Json '.json' @{ path = $found } } else { Write-Json '.json' @{ error = "Could not find where $name was saved." } }
    }
    'pptx' {
      Stage 'Choose the PowerPoint file in the Windows dialog.'
      $owner = New-Owner
      $dlg = New-Object System.Windows.Forms.OpenFileDialog
      $dlg.Title = 'Import PowerPoint into Interactive Presenter'
      $dlg.Filter = 'PowerPoint (*.pptx;*.ppt;*.pptm;*.ppsx)|*.pptx;*.ppt;*.pptm;*.ppsx|All files (*.*)|*.*'
      $res = $dlg.ShowDialog($owner)
      $owner.Close()
      if ($res -ne 'OK') { Write-Json '.json' @{ cancelled = $true }; break }
      $full = $dlg.FileName
      Stage "PowerPoint is converting $([IO.Path]::GetFileName($full)) (a few seconds per 10 slides) ..."
      $imports = Join-Path $env:LOCALAPPDATA 'IPPresenterDeck-imports'
      Get-ChildItem $imports -Directory -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
      $out = Join-Path $imports ('{0}-{1:yyyyMMdd-HHmmss}' -f ([IO.Path]::GetFileNameWithoutExtension($full) -replace '[^\w\-]+', '_'), (Get-Date))
      & (Join-Path $PSScriptRoot 'tools\pptx-export.ps1') -File $full -Out $out | Out-Null
      Write-Json '.json' @{ manifest = ([Uri](Join-Path $out 'manifest.json')).AbsoluteUri }
    }
    default { Write-Json '.json' @{ error = "Unknown helper action: $action" } }
  }
} catch {
  $msg = $_.Exception.Message
  if ($action -eq 'pptx' -and $msg -match '80040154|ComObject|class not registered') { $msg = 'PowerPoint is not installed on this PC: save the slides as PDF or pictures and import those.' }
  Write-Json '.json' @{ error = $msg }
}
