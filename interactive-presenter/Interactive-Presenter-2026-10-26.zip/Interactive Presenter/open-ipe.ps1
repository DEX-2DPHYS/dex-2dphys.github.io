# Opens Interactive Presenter, and a presentation (.ipe or .zip) when one is given.
#   open-ipe.ps1 "C:\path\talk.ipe"     (this is what double-clicking an .ipe file runs)
#   open-ipe.ps1                        (the desktop icon: an empty presenter)
# Why a launcher and not the .html directly: a page opened from disk may not read other local files
# (the deck, its sims). Chrome/Edge therefore start with --allow-file-access-from-files, in their OWN
# profile (%LOCALAPPDATA%\IPPresenterDeck), so the normal browser profile stays untouched.
#   open-ipe.ps1 "C:\path\talk.pptx"    (.pptx / .ppt: converted with PowerPoint by tools\pptx-export.ps1 into
#                                        %LOCALAPPDATA%\IPPresenterDeck-imports, then imported; save it as .ipe)
param([string]$Deck, [switch]$PrintUrl) # -PrintUrl: print the address instead of opening the browser (tests)
function Say([string]$msg) { Add-Type -AssemblyName PresentationFramework; [void][System.Windows.MessageBox]::Show($msg, 'Interactive Presenter') }
$page = Join-Path $PSScriptRoot 'InteractivePresenter.html'
$url = ([System.Uri]$page).AbsoluteUri
if ($Deck) {
  if (-not (Test-Path -LiteralPath $Deck)) { Say "Cannot find $Deck"; exit 1 }
  $full = (Resolve-Path -LiteralPath $Deck).ProviderPath
  if ($full -match '\.(pptx|ppt|pptm|ppsx|pps)$') {
    $imports = Join-Path $env:LOCALAPPDATA 'IPPresenterDeck-imports'
    # old conversions (more than a week) are removed
    Get-ChildItem $imports -Directory -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    $out = Join-Path $imports ('{0}-{1:yyyyMMdd-HHmmss}' -f ([IO.Path]::GetFileNameWithoutExtension($full) -replace '[^\w\-]+', '_'), (Get-Date))
    Write-Host "Converting $(Split-Path $full -Leaf) with PowerPoint ..."
    try { & (Join-Path $PSScriptRoot 'tools\pptx-export.ps1') -File $full -Out $out | Out-Host }
    catch { Say "Could not convert the PowerPoint file (PowerPoint is needed on this PC):`n$($_.Exception.Message)"; exit 1 }
    $url += '?pptx=' + [System.Uri]::EscapeDataString(([System.Uri](Join-Path $out 'manifest.json')).AbsoluteUri)
  } else {
    $url += '?deck=' + [System.Uri]::EscapeDataString(([System.Uri]$full).AbsoluteUri)
  }
}
if ($PrintUrl) { $url; exit 0 }
$cands = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")
$browser = $cands | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $browser) { Add-Type -AssemblyName PresentationFramework; [void][System.Windows.MessageBox]::Show('Neither Google Chrome nor Microsoft Edge was found.', 'Interactive Presenter'); exit 1 }
Start-Process $browser -ArgumentList @('--allow-file-access-from-files', "--user-data-dir=$env:LOCALAPPDATA\IPPresenterDeck", '--no-first-run', '--no-default-browser-check', '--start-maximized', $url)
