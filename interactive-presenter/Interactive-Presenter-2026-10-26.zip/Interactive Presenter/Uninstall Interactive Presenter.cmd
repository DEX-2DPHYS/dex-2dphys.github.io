@echo off
rem Removes what "Install Interactive Presenter.cmd" added (current Windows user only):
rem the .ipe file type, the right-click entry on PowerPoint files and the desktop icon.
rem The InteractivePresenter folder, your .ipe files and the browser profile stay untouched.
title Uninstall Interactive Presenter
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$c='HKCU:\Software\Classes';" ^
  "foreach($k in \"$c\.ipe\", \"$c\InteractivePresenter.Deck\", \"$c\SystemFileAssociations\.pptx\shell\IPImport\", \"$c\SystemFileAssociations\.ppt\shell\IPImport\", \"$c\ipe-helper\") { if (Test-Path $k) { Remove-Item $k -Recurse -Force; Write-Host \"removed $k\" } };" ^
  "$l = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Interactive Presenter.lnk'; if (Test-Path $l) { Remove-Item $l -Force; Write-Host \"removed $l\" };" ^
  "Add-Type -Namespace W -Name S -MemberDefinition '[System.Runtime.InteropServices.DllImport(\"shell32.dll\")] public static extern void SHChangeNotify(int e,int f,System.IntPtr a,System.IntPtr b);'; [W.S]::SHChangeNotify(0x08000000,0,[IntPtr]::Zero,[IntPtr]::Zero)"
echo.
echo   Interactive Presenter is uninstalled for %USERNAME%. Install Interactive Presenter.cmd adds it again.
echo.
pause
