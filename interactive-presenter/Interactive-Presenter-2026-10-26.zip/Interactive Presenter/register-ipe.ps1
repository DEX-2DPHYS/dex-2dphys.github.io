# One-time setup on a PC: makes double-clicking a .ipe file open it in Interactive Presenter, and puts
# an Interactive Presenter icon on the desktop. Current user only (no administrator rights needed).
# Run again after moving the InteractivePresenter folder.
$here = $PSScriptRoot
$launcher = Join-Path $here 'open-ipe.ps1'
$appIco = Join-Path $here 'InteractivePresenter.ico'
$fileIco = Join-Path $here 'ipe-file.ico'
$ps = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$cmd = "`"$ps`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`" `"%1`""

$cls = 'HKCU:\Software\Classes'
New-Item -Path "$cls\.ipe" -Force | Out-Null
Set-ItemProperty -Path "$cls\.ipe" -Name '(default)' -Value 'InteractivePresenter.Deck'
Set-ItemProperty -Path "$cls\.ipe" -Name 'Content Type' -Value 'application/zip'
New-Item -Path "$cls\InteractivePresenter.Deck" -Force | Out-Null
Set-ItemProperty -Path "$cls\InteractivePresenter.Deck" -Name '(default)' -Value 'Interactive Presenter presentation'
New-Item -Path "$cls\InteractivePresenter.Deck\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$cls\InteractivePresenter.Deck\DefaultIcon" -Name '(default)' -Value $fileIco
New-Item -Path "$cls\InteractivePresenter.Deck\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$cls\InteractivePresenter.Deck\shell\open" -Name '(default)' -Value 'Open in Interactive Presenter'
Set-ItemProperty -Path "$cls\InteractivePresenter.Deck\shell\open\command" -Name '(default)' -Value $cmd

# right-click a PowerPoint file -> "Import into Interactive Presenter" (PowerPoint keeps its own double-click).
# The window stays visible: it says what is being converted (takes a few seconds per 10 slides).
$importCmd = "`"$ps`" -NoProfile -ExecutionPolicy Bypass -File `"$launcher`" `"%1`""
foreach ($ext in '.pptx', '.ppt') {
  $key = "$cls\SystemFileAssociations\$ext\shell\IPImport"
  New-Item -Path "$key\command" -Force | Out-Null
  Set-ItemProperty -Path $key -Name '(default)' -Value 'Import into Interactive Presenter'
  Set-ItemProperty -Path $key -Name 'Icon' -Value $appIco
  Set-ItemProperty -Path "$key\command" -Name '(default)' -Value $importCmd
}

# the helper: Browse... for the linked-files folder, finding where Save put a deck, Import PowerPoint...
# (the page opens an ipe-helper: link; the browser asks once before it starts the helper)
$helper = Join-Path $here "ipe-helper.ps1"
$hk = "$cls\ipe-helper"
New-Item -Path "$hk\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path $hk -Name "(default)" -Value "URL:Interactive Presenter helper"
Set-ItemProperty -Path $hk -Name "URL Protocol" -Value ""
New-Item -Path "$hk\DefaultIcon" -Force | Out-Null
Set-ItemProperty -Path "$hk\DefaultIcon" -Name "(default)" -Value $appIco
Set-ItemProperty -Path "$hk\shell\open\command" -Name "(default)" -Value "`"$ps`" -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$helper`" `"%1`""

# desktop icon (follows a redirected/OneDrive desktop)
$desk = [Environment]::GetFolderPath('Desktop')
$ws = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut((Join-Path $desk 'Interactive Presenter.lnk'))
$lnk.TargetPath = $ps
$lnk.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$launcher`""
$lnk.WorkingDirectory = $here
$lnk.IconLocation = $appIco
$lnk.Description = 'Interactive Presenter'
$lnk.Save()

# tell Explorer the associations and icons changed
Add-Type -Namespace Win32 -Name Shell -MemberDefinition '[System.Runtime.InteropServices.DllImport("shell32.dll")] public static extern void SHChangeNotify(int e, int f, System.IntPtr a, System.IntPtr b);'
[Win32.Shell]::SHChangeNotify(0x08000000, 0, [IntPtr]::Zero, [IntPtr]::Zero)
"Done: .ipe is registered; desktop icon at $desk\Interactive Presenter.lnk"
