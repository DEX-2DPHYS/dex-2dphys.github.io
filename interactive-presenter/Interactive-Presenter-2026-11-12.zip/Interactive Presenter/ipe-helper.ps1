# The Interactive Presenter helper: does for the page what a web page may not do itself.
# Registered by register-ipe.ps1 as the "ipe-helper:" link type; the page (deck-panel.js) opens a link such as
#   ipe-helper:pickfolder?job=<id>&start=C:\Talks
#   ipe-helper:locate?job=<id>&name=Talk.ipe&size=123456&t=<ms since 1970>
#   ipe-helper:pptx?job=<id>
# and reads the answer from .ipe-jobs\<id>.json beside this script (progress in <id>.start.json).
#   pickfolder  a Windows folder dialog                       -> {"path": "C:\\Talks\\Demo"}
#   locate      where Save put a file (the browser never says) -> {"path": "C:\\Talks\\Demo\\Talk.ipe"}
#   pptx        choose a PowerPoint file, PowerPoint converts it (tools\pptx-export.ps1) -> {"manifest": "file:///..."}
#   placemedia  copy a PowerPoint import's movies into videos\ of the presentation folder -> {"placed": [...]}
#               (ipe-helper:placemedia?job=<id>&from=<import folder>&to=<presentation folder>)
# Cancelled: {"cancelled": true}; failed: {"error": "..."}.
param([string]$Uri)
$ErrorActionPreference = 'Stop'
$jobs = Join-Path $PSScriptRoot '.ipe-jobs'
New-Item -ItemType Directory -Force -Path $jobs | Out-Null
Get-ChildItem $jobs -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-1) } | Remove-Item -Force -ErrorAction SilentlyContinue

$rest = $Uri -replace '^ipe-helper:/*', ''
$action, $query = $rest -split '\?', 2
$q = @{}
foreach ($pair in ($query -split '&')) {
  if (-not $pair) { continue }
  $k, $v = $pair -split '=', 2
  $q[[Uri]::UnescapeDataString($k)] = [Uri]::UnescapeDataString(($v -replace '\+', ' '))
}
$job = [string]$q['job']
if ($job -notmatch '^[0-9a-f]{8,64}$') { exit 1 }

$utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-Json([string]$suffix, $obj) {
  $file = Join-Path $jobs "$job$suffix"
  [IO.File]::WriteAllText("$file.tmp", ($obj | ConvertTo-Json -Compress), $utf8)
  Move-Item -Force "$file.tmp" $file
}
# progress is best effort: the page may be reading the file at that moment (Windows then refuses to replace it)
function Stage([string]$message) { try { Write-Json '.start.json' @{ message = $message } } catch { Remove-Item -LiteralPath (Join-Path $jobs "$job.start.json.tmp") -Force -ErrorAction SilentlyContinue } }
Stage 'The helper is running.'

# a dialog needs an owner in front of the browser, or it opens behind it
Add-Type -AssemblyName System.Windows.Forms
function New-Owner {
  $f = New-Object System.Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Width = 1; Height = 1; StartPosition = 'CenterScreen'; Opacity = 0 }
  $f.Show(); $f.Activate()
  return $f
}

try {
  switch ($action) {
    'pickfolder' {
      Stage 'Choose the folder in the Windows dialog.'
      $owner = New-Owner
      $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
      $dlg.Description = 'Interactive Presenter: the folder that holds this presentation (with its html, sims, pdf ... folders)'
      $dlg.ShowNewFolderButton = $true
      if ($q['start'] -and (Test-Path -LiteralPath $q['start'])) { $dlg.SelectedPath = $q['start'] }
      $res = $dlg.ShowDialog($owner)
      $owner.Close()
      if ($res -eq 'OK') { Write-Json '.json' @{ path = $dlg.SelectedPath } } else { Write-Json '.json' @{ cancelled = $true } }
    }
    'locate' {
      $name = [string]$q['name']; $size = [int64]$q['size']; $t = [int64]$q['t']
      if (-not $name -or $name -match '[\\/:*?"<>|]') { throw 'no file name' }
      $when = [DateTimeOffset]::FromUnixTimeMilliseconds($t).LocalDateTime
      function Fits([IO.FileInfo]$f) { $f.Length -eq $size -and [Math]::Abs(($f.LastWriteTime - $when).TotalSeconds) -lt 300 }
      $found = $null
      # 1. Windows lists files saved through its Save dialog under Recent items
      $lnk = Join-Path ([Environment]::GetFolderPath('Recent')) "$name.lnk"
      if (Test-Path -LiteralPath $lnk) {
        $target = (New-Object -ComObject WScript.Shell).CreateShortcut($lnk).TargetPath
        if ($target -and (Test-Path -LiteralPath $target)) { $fi = Get-Item -LiteralPath $target; if (Fits $fi) { $found = $fi.FullName } }
      }
      # 2. otherwise search the user's folders for it (newest match), at most ~60 s; "near" (a folder, and
      #    then its parent) first: Save to folder passes the original presentation's folder
      if (-not $found) {
        $near = @()
        if ($q['near'] -and (Test-Path -LiteralPath $q['near'])) { $near = @($q['near'], (Split-Path -LiteralPath $q['near'] -Parent)) | Where-Object { $_ } }
        $roots = @($near) + @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'), (Join-Path $env:USERPROFILE 'Downloads'), $env:USERPROFILE) |
          Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique
        $skip = '^(AppData|node_modules|\.git|\$Recycle\.Bin)$'
        $deadline = (Get-Date).AddSeconds(60)
        $seen = New-Object 'System.Collections.Generic.HashSet[string]'
        $queue = New-Object 'System.Collections.Generic.Queue[string]'
        foreach ($r in $roots) { $queue.Enqueue($r) }
        $best = $null
        while ($queue.Count -and (Get-Date) -lt $deadline) {
          $d = $queue.Dequeue()
          if (-not $seen.Add($d.ToLowerInvariant())) { continue }
          try {
            foreach ($p in [IO.Directory]::EnumerateFiles($d, $name)) { $fi = [IO.FileInfo]$p; if ((Fits $fi) -and (-not $best -or $fi.LastWriteTime -gt $best.LastWriteTime)) { $best = $fi } }
            foreach ($sub in [IO.Directory]::EnumerateDirectories($d)) {
              $leaf = [IO.Path]::GetFileName($sub)
              if ($leaf -notmatch $skip -and -not (([IO.DirectoryInfo]$sub).Attributes -band [IO.FileAttributes]::ReparsePoint)) { $queue.Enqueue($sub) }
            }
          } catch { }
          if ($best) { break }
        }
        if ($best) { $found = $best.FullName }
      }
      if ($found) { Write-Json '.json' @{ path = $found } } else { Write-Json '.json' @{ error = "Could not find where $name was saved." } }
    }
    'pptx' {
      Stage 'Choose the PowerPoint file in the Windows dialog.'
      $owner = New-Owner
      $dlg = New-Object System.Windows.Forms.OpenFileDialog
      $dlg.Title = 'Import PowerPoint into Interactive Presenter'
      $dlg.Filter = 'PowerPoint (*.pptx;*.ppt;*.pptm;*.ppsx)|*.pptx;*.ppt;*.pptm;*.ppsx|All files (*.*)|*.*'
      $res = $dlg.ShowDialog($owner)
      $owner.Close()
      if ($res -ne 'OK') { Write-Json '.json' @{ cancelled = $true }; break }
      $full = $dlg.FileName
      Stage "PowerPoint is converting $([IO.Path]::GetFileName($full)) (a few seconds per 10 slides) ..."
      $imports = Join-Path $env:LOCALAPPDATA 'IPPresenterDeck-imports'
      Get-ChildItem $imports -Directory -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-7) } | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
      $out = Join-Path $imports ('{0}-{1:yyyyMMdd-HHmmss}' -f ([IO.Path]::GetFileNameWithoutExtension($full) -replace '[^\w\-]+', '_'), (Get-Date))
      & (Join-Path $PSScriptRoot 'tools\pptx-export.ps1') -File $full -Out $out | Out-Null
      Write-Json '.json' @{ manifest = ([Uri](Join-Path $out 'manifest.json')).AbsoluteUri }
    }
    'placemedia' {
      # PowerPoint movies (2026-11-12): copy media\* of one PowerPoint import folder into videos\ of the
      # presentation folder. Only from %LOCALAPPDATA%\IPPresenterDeck-imports, only into <to>\videos, never
      # over another file (same name, other content -> name-2.mp4); a file already there with the same
      # content is used as it is. -> {"placed": [{"file": "media/x.mp4", "name": "x.mp4"}]} or {"gone": true}
      $imports = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'IPPresenterDeck-imports')).TrimEnd('\')
      $from = [IO.Path]::GetFullPath([string]$q['from']).TrimEnd('\')
      if (-not $from.StartsWith($imports + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Not a PowerPoint import folder.' }
      $to = [string]$q['to']
      if (-not $to -or -not (Test-Path -LiteralPath $to -PathType Container)) { throw "The presentation folder $to does not exist." }
      $src = Join-Path $from 'media'
      if (-not (Test-Path -LiteralPath $src -PathType Container)) { Write-Json '.json' @{ gone = $true }; break }
      # videos\ as the rest of the app writes; a presentation that already keeps its movies in movies\ gets them there
      $folder = if (-not (Test-Path -LiteralPath (Join-Path $to 'videos')) -and (Test-Path -LiteralPath (Join-Path $to 'movies') -PathType Container)) { 'movies' } else { 'videos' }
      $dest = Join-Path $to $folder
      $placed = @()
      $files = @(Get-ChildItem -LiteralPath $src -File)
      $i = 0
      foreach ($f in $files) {
        $i++
        Stage "Copying the movies into videos\ ($i of $($files.Count)): $($f.Name)"
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        $base = [IO.Path]::GetFileNameWithoutExtension($f.Name); $ext = $f.Extension
        $target = Join-Path $dest $f.Name; $k = 2; $same = $false
        while (Test-Path -LiteralPath $target) {
          $t = Get-Item -LiteralPath $target
          if ($t.Length -eq $f.Length -and (Get-FileHash -LiteralPath $target).Hash -eq (Get-FileHash -LiteralPath $f.FullName).Hash) { $same = $true; break }
          $target = Join-Path $dest "$base-$k$ext"; $k++
        }
        if (-not $same) { Copy-Item -LiteralPath $f.FullName -Destination $target }
        $placed += @{ file = "media/$($f.Name)"; name = [IO.Path]::GetFileName($target) }
      }
      Write-Json '.json' @{ placed = @($placed); folder = $folder }
    }
    default { Write-Json '.json' @{ error = "Unknown helper action: $action" } }
  }
} catch {
  $msg = $_.Exception.Message
  if ($action -eq 'pptx' -and $msg -match '80040154|ComObject|class not registered') { $msg = 'PowerPoint is not installed on this PC: save the slides as PDF or pictures and import those.' }
  Write-Json '.json' @{ error = $msg }
}
