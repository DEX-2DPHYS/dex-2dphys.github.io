# PowerPoint (.pptx / .ppt) -> folder for Interactive Presenter's PowerPoint import.
#   powershell -File pptx-export.ps1 -File "talk.pptx" -Out "<folder>"   (writes <folder>\manifest.json + PNGs)
# Uses PowerPoint itself (COM), so it needs PowerPoint on this PC. The presentation is opened read-only and
# closed without saving; the original file is never changed.
#
# Per slide:
#   - text boxes and placeholders with text (not rotated, not in a group): their paragraphs and runs with the
#     formatting PowerPoint actually uses (size, bold, italic, colour, font, alignment, bullets) -> editable text
#   - pictures (not rotated): exported as PNG -> movable image overlays
#   - the slide rendered WITHOUT those (their text blanked, pictures hidden) -> the background picture, so
#     shapes, fills, tables, charts, SmartArt, equations and theme graphics keep their exact look
#   - the full slide rendered as it is (full\N.png) for comparison / fallback
#   - the speaker notes as text
#   - movies (embedded or linked, 2026-11-12): the file -> media\<name>.mp4 (taken from the .pptx copy, or
#     from its linked file), converted / trimmed with ffmpeg when Chrome could not play it as it is or
#     PowerPoint trims it; its poster frame -> pic\N-ID-poster.png; loop / mute / volume. The movie is left out
#     of the background picture. Online videos and sounds stay as they look in the background picture.
#   - animated GIFs (2026-11-12): the picture's own .gif from the .pptx instead of a still PNG (pic\N-ID.gif), with
#     PowerPoint's crop, flips and stretching applied by ffmpeg when there are any (without ffmpeg: a still PNG + a note)
param(
  [Parameter(Mandatory = $true)][string]$File,
  [Parameter(Mandatory = $true)][string]$Out,
  [int]$Width = 1920
)
$ErrorActionPreference = 'Stop'
$full = (Resolve-Path -LiteralPath $File).ProviderPath
foreach ($d in 'bg', 'full', 'pic') { New-Item -ItemType Directory -Force -Path (Join-Path $Out $d) | Out-Null }

function Hex([int]$bgr) { $r = $bgr -band 0xFF; $g = ($bgr -shr 8) -band 0xFF; $b = ($bgr -shr 16) -band 0xFF; '#{0:x2}{1:x2}{2:x2}' -f $r, $g, $b }
function TrueOf($v) { return ($v -eq -1) -or ($v -eq $true) }

# ---- movies ----------------------------------------------------------------------------------------------
# ffmpeg / ffprobe: on the PATH, or where winget / a hand install puts them
$script:toolCache = @{}
function Find-Tool([string]$name) {
  if ($script:toolCache.ContainsKey($name)) { return $script:toolCache[$name] }
  $found = $null
  $c = Get-Command "$name.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($c) { $found = $c.Source }
  if (-not $found) {
    foreach ($r in @("$env:LOCALAPPDATA\Microsoft\WinGet\Links", "$env:LOCALAPPDATA\Microsoft\WinGet\Packages", "$env:ProgramFiles\ffmpeg", "C:\ffmpeg")) {
      if (-not (Test-Path -LiteralPath $r)) { continue }
      $f = Get-ChildItem -LiteralPath $r -Recurse -Depth 5 -Filter "$name.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($f) { $found = $f.FullName; break }
    }
  }
  $script:toolCache[$name] = $found
  return $found
}
# a native program without PowerShell turning its error output into a stop
function Run-Native([string]$exe, [string[]]$argv) {
  $old = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
  try { $out = & $exe @argv 2>$null; return @{ code = $LASTEXITCODE; out = @($out) } } finally { $ErrorActionPreference = $old }
}
# the codecs in a movie file: @{ video = 'h264'; audio = 'aac' } ('' when it has none), $null without ffprobe
function Probe-Codecs([string]$file) {
  $probe = Find-Tool 'ffprobe'
  if (-not $probe) { return $null }
  $r = Run-Native $probe @('-v', 'error', '-show_entries', 'stream=codec_name,codec_type', '-of', 'csv=p=0', $file)
  if ($r.code -ne 0) { return $null }
  $res = @{ video = ''; audio = '' }
  foreach ($line in $r.out) {
    $name, $type = ([string]$line).Trim() -split ',', 2
    if ($type -eq 'video' -and -not $res.video -and $name -notin 'mjpeg', 'png') { $res.video = $name }
    if ($type -eq 'audio' -and -not $res.audio) { $res.audio = $name }
  }
  return $res
}
# A movie file as Chrome can play it: $src -> $dest (.mp4 / .webm). $startMs/$endMs: PowerPoint's trim (0 = none).
# Returns @{ file; how = 'as-is' | 'remuxed' | 'converted' | 'unconverted'; note }
function Make-Playable([string]$src, [string]$destBase, [double]$startMs, [double]$endMs) {
  $ext = [IO.Path]::GetExtension($src).ToLowerInvariant()
  $codecs = Probe-Codecs $src
  $okVideo = 'h264', 'vp8', 'vp9', 'av1'
  $okAudio = '', 'aac', 'mp3', 'opus', 'vorbis'
  $trim = ($startMs -gt 0) -or ($endMs -gt 0)
  $ffmpeg = Find-Tool 'ffmpeg'
  if ($codecs) { $playable = ($codecs.video -in $okVideo) -and ($codecs.audio -in $okAudio) }
  else { $playable = $ext -in '.mp4', '.m4v', '.webm' } # no ffprobe: trust the extension
  if ($playable -and -not $trim -and $ext -in '.mp4', '.m4v', '.webm') {
    $out = $destBase + $(if ($ext -eq '.webm') { '.webm' } else { '.mp4' })
    Copy-Item -LiteralPath $src -Destination $out -Force
    return @{ file = $out; how = 'as-is' }
  }
  if (-not $ffmpeg) {
    $out = $destBase + $ext
    Copy-Item -LiteralPath $src -Destination $out -Force
    $why = if ($trim) { 'PowerPoint trims this movie, but ffmpeg is not installed: it plays in full' } else { 'ffmpeg is not installed, so it could not be converted; Chrome may not play it' }
    return @{ file = $out; how = 'unconverted'; note = $why }
  }
  $out = $destBase + '.mp4'
  $argv = @('-y', '-v', 'error', '-nostdin')
  if ($trim -and $startMs -gt 0) { $argv += @('-ss', [string]::Format([Globalization.CultureInfo]::InvariantCulture, '{0:0.000}', $startMs / 1000)) }
  $argv += @('-i', $src)
  if ($trim -and $endMs -gt $startMs) { $argv += @('-t', [string]::Format([Globalization.CultureInfo]::InvariantCulture, '{0:0.000}', ($endMs - $startMs) / 1000)) }
  if ($playable -and -not $trim) {
    # only the container is new (e.g. .mov with H.264 inside)
    $argv += @('-c', 'copy', '-movflags', '+faststart', $out)
    $r = Run-Native $ffmpeg $argv
    if ($r.code -eq 0 -and (Test-Path -LiteralPath $out) -and (Get-Item -LiteralPath $out).Length -gt 0) { return @{ file = $out; how = 'remuxed' } }
    $argv = $argv[0..($argv.Count - 6)] # try again, converting
  }
  $argv += @('-map', '0:v:0', '-map', '0:a:0?', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-pix_fmt', 'yuv420p',
    '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', $out)
  $r = Run-Native $ffmpeg $argv
  if ($r.code -eq 0 -and (Test-Path -LiteralPath $out) -and (Get-Item -LiteralPath $out).Length -gt 0) { return @{ file = $out; how = 'converted' } }
  Remove-Item -LiteralPath $out -Force -ErrorAction SilentlyContinue
  $out = $destBase + $ext
  Copy-Item -LiteralPath $src -Destination $out -Force
  return @{ file = $out; how = 'unconverted'; note = 'ffmpeg could not convert it; Chrome may not play it' }
}
# ---- animated GIFs ---------------------------------------------------------------------------------------
# a GIF: @{ frames (1 = a still picture, 0 = unreadable); w; h }
function Gif-Info([string]$file) {
  try {
    Add-Type -AssemblyName System.Drawing
    $img = [System.Drawing.Image]::FromFile($file)
    try { return @{ frames = $img.GetFrameCount((New-Object System.Drawing.Imaging.FrameDimension($img.FrameDimensionsList[0]))); w = $img.Width; h = $img.Height } } finally { $img.Dispose() }
  } catch { return @{ frames = 0; w = 0; h = 0 } }
}
# The GIF as the slide shows it: PowerPoint's crop (fractions cut off each side) and flips applied with ffmpeg,
# still animated; $aspect > 0: stretched to that width/height (PowerPoint showed it out of its own proportions).
# Without any of these: the file as it is. Returns $true, or $false (no ffmpeg, or it failed).
function Make-Gif([string]$src, [string]$dest, $crop, [bool]$flipH, [bool]$flipV, [double]$aspect) {
  $cropped = ($crop.l -ne 0) -or ($crop.t -ne 0) -or ($crop.r -ne 0) -or ($crop.b -ne 0)
  if (-not $cropped -and -not $flipH -and -not $flipV -and $aspect -le 0) { Copy-Item -LiteralPath $src -Destination $dest -Force; return $true }
  $ffmpeg = Find-Tool 'ffmpeg'
  if (-not $ffmpeg) { return $false }
  # a negative crop (PowerPoint's "outset", a margin around the picture) is not a cut: leave that side whole
  $f = @{}; foreach ($k in 'l', 't', 'r', 'b') { $f[$k] = [Math]::Max(0, [double]$crop[$k]) }
  $inv = [Globalization.CultureInfo]::InvariantCulture
  $chain = @()
  if ($cropped) { $chain += [string]::Format($inv, 'crop=trunc(iw*{0:0.######}/2)*2:trunc(ih*{1:0.######}/2)*2:trunc(iw*{2:0.######}):trunc(ih*{3:0.######})', (1 - $f.l - $f.r), (1 - $f.t - $f.b), $f.l, $f.t) }
  if ($flipH) { $chain += 'hflip' }
  if ($flipV) { $chain += 'vflip' }
  if ($aspect -gt 0) { $chain += [string]::Format($inv, 'scale=iw:round(iw/{0:0.######}/2)*2', $aspect) }
  $vf = ($chain -join ',') + ',split[a][b];[a]palettegen=reserve_transparent=1[p];[b][p]paletteuse'
  $r = Run-Native $ffmpeg @('-y', '-v', 'error', '-nostdin', '-i', $src, '-filter_complex', $vf, '-loop', '0', $dest)
  return ($r.code -eq 0 -and (Test-Path -LiteralPath $dest) -and (Get-Item -LiteralPath $dest).Length -gt 0)
}

# a file name for the movie: the shape's name (PowerPoint names an inserted movie after its file) unless that
# is a generic "Video 3" / "Content Placeholder 2"
function Movie-Name([string]$shapeName, [string]$linkedPath, [string]$deckTitle, [int]$slideNo) {
  $base = ''
  if ($linkedPath) { $base = [IO.Path]::GetFileNameWithoutExtension($linkedPath) }
  elseif ($shapeName -and $shapeName -notmatch '^(Video|Movie|Media|Film|Online|Content Placeholder|Pladsholder|Placeholder|Picture|Billede|Indhold)\b') { $base = $shapeName }
  if (-not $base) { $base = "$deckTitle slide $slideNo movie" }
  $base = ($base -replace '[\\/:*?"<>|#%&{}$!''@+`=]+', '-' -replace '\s+', ' ').Trim(' ', '.', '-')
  if ($base.Length -gt 60) { $base = $base.Substring(0, 60).Trim() }
  if (-not $base) { $base = 'movie' }
  return $base
}

$app = New-Object -ComObject PowerPoint.Application
$hadOpen = $app.Presentations.Count
# Open(FileName, ReadOnly, Untitled, WithWindow)
$pres = $app.Presentations.Open($full, -1, 0, 0)
try {
  $W = [double]$pres.PageSetup.SlideWidth; $H = [double]$pres.PageSetup.SlideHeight
  $Hpx = [int][Math]::Round($Width * $H / $W)
  # "Shrink text on overflow": PowerPoint draws such text smaller (normAutofit fontScale, lnSpcReduction), but
  # Font.Size reports the nominal size. The scale is only in the file, so read it from a .pptx copy's XML:
  # $fit["<SlideID>/<shape id>"] = @{ scale; lineReduction }
  $fit = @{}
  # Movies, from the same copy: $movies["<SlideID>/<shape id>"] = @{ file = <extracted file> } (embedded) or
  # @{ link = <its address> } (linked; online videos have an http address). Files go to media-src\ first.
  $movies = @{}
  $gifs = @{}
  $mediaSrc = Join-Path $Out 'media-src'
  try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $copy = Join-Path $Out 'copy.pptx'
    $pres.SaveCopyAs($copy, 24) # ppSaveAsOpenXMLPresentation (also turns a .ppt into XML)
    $zip = [IO.Compression.ZipFile]::OpenRead($copy)
    $readXml = { param($name) $e = $zip.GetEntry($name); if (-not $e) { return $null }; $s = New-Object IO.StreamReader($e.Open()); $x = New-Object Xml.XmlDocument; $x.LoadXml($s.ReadToEnd()); $s.Close(); $x }
    $presXml = & $readXml 'ppt/presentation.xml'
    $rels = & $readXml 'ppt/_rels/presentation.xml.rels'
    $target = @{}; foreach ($r in $rels.SelectNodes("//*[local-name()='Relationship']")) { $target[$r.Id] = $r.Target }
    $relNs = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
    foreach ($sid in $presXml.SelectNodes("//*[local-name()='sldId']")) {
      $rid = $sid.GetAttribute('id', $relNs)
      $slidePath = 'ppt/' + ($target[$rid] -replace '^/?ppt/', '')
      $sx = & $readXml $slidePath
      if (-not $sx) { continue }
      try {
        $videoNodes = $sx.SelectNodes("//*[local-name()='videoFile']")
        if ($videoNodes.Count) {
          $slideRels = @{}
          $rx = & $readXml (($slidePath -replace '/([^/]+)$', '/_rels/$1') + '.rels')
          if ($rx) { foreach ($r in $rx.SelectNodes("//*[local-name()='Relationship']")) { $slideRels[$r.Id] = @{ target = $r.Target; external = ($r.GetAttribute('TargetMode') -eq 'External') } } }
          $slideDir = $slidePath -replace '/[^/]+$', ''
          foreach ($vf in $videoNodes) {
            $pic = $vf.ParentNode
            while ($pic -and $pic.LocalName -ne 'pic' -and $pic.LocalName -ne 'sp') { $pic = $pic.ParentNode }
            $c = if ($pic) { $pic.SelectSingleNode(".//*[local-name()='cNvPr']") } else { $null }
            if (-not $c) { continue }
            # the embedded file (p14:media r:embed), else the video link itself (r:link)
            $media = $pic.SelectSingleNode(".//*[local-name()='media'][@*[local-name()='embed']]")
            $relId = if ($media) { $media.GetAttribute('embed', $relNs) } else { '' }
            if (-not $relId) { $relId = $vf.GetAttribute('link', $relNs) }
            $rel = $slideRels[$relId]
            if (-not $rel) { continue }
            $key = "$($sid.GetAttribute('id'))/$($c.GetAttribute('id'))"
            if ($rel.external) { $movies[$key] = @{ link = [string]$rel.target }; continue }
            # ../media/media1.mp4 -> ppt/media/media1.mp4
            $parts = New-Object System.Collections.Generic.List[string]
            foreach ($p in (($slideDir + '/' + $rel.target) -split '/')) { if ($p -eq '..') { if ($parts.Count) { $parts.RemoveAt($parts.Count - 1) } } elseif ($p -and $p -ne '.') { $parts.Add($p) } }
            $entryName = $parts -join '/'
            $entry = $zip.GetEntry($entryName)
            if (-not $entry) { continue }
            New-Item -ItemType Directory -Force -Path $mediaSrc | Out-Null
            $file = Join-Path $mediaSrc ([IO.Path]::GetFileName($entryName))
            if (-not (Test-Path -LiteralPath $file)) { [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $file) }
            $movies[$key] = @{ file = $file }
          }
        }
      } catch { Write-Host "  (could not read the movies of a slide: $($_.Exception.Message))" }
      # animated GIFs (2026-11-12): the picture's own file (PowerPoint's export gives one still frame);
      # $gifs["<SlideID>/<shape id>"] = @{ file; frames; crop = @{ l; t; r; b } (fractions, a:srcRect) }
      try {
        $blips = @($sx.SelectNodes("//*[local-name()='pic']/*[local-name()='blipFill']/*[local-name()='blip']"))
        if ($blips.Count) {
          $slideRels = @{}
          $rx = & $readXml (($slidePath -replace '/([^/]+)$', '/_rels/$1') + '.rels')
          if ($rx) { foreach ($r in $rx.SelectNodes("//*[local-name()='Relationship']")) { $slideRels[$r.Id] = @{ target = $r.Target; external = ($r.GetAttribute('TargetMode') -eq 'External') } } }
          $slideDir = $slidePath -replace '/[^/]+$', ''
          foreach ($bl in $blips) {
            $rel = $slideRels[$bl.GetAttribute('embed', $relNs)]
            if (-not $rel -or $rel.external -or $rel.target -notmatch '\.gif$') { continue }
            $pic = $bl.ParentNode.ParentNode
            if ($pic.SelectSingleNode(".//*[local-name()='videoFile' or local-name()='audioFile']")) { continue }
            $c = $pic.SelectSingleNode(".//*[local-name()='cNvPr']")
            if (-not $c) { continue }
            $parts = New-Object System.Collections.Generic.List[string]
            foreach ($p in (($slideDir + '/' + $rel.target) -split '/')) { if ($p -eq '..') { if ($parts.Count) { $parts.RemoveAt($parts.Count - 1) } } elseif ($p -and $p -ne '.') { $parts.Add($p) } }
            $entry = $zip.GetEntry(($parts -join '/'))
            if (-not $entry) { continue }
            New-Item -ItemType Directory -Force -Path $mediaSrc | Out-Null
            $file = Join-Path $mediaSrc $entry.Name
            if (-not (Test-Path -LiteralPath $file)) { [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $file) }
            $info = Gif-Info $file
            if ($info.frames -lt 2) { continue } # a still GIF: PowerPoint's PNG is as good
            $crop = @{ l = 0; t = 0; r = 0; b = 0 }
            $sr = $bl.ParentNode.SelectSingleNode("*[local-name()='srcRect']")
            if ($sr) { foreach ($k in 'l', 't', 'r', 'b') { if ($sr.HasAttribute($k)) { $crop[$k] = [double]::Parse($sr.GetAttribute($k), [Globalization.CultureInfo]::InvariantCulture) / 100000 } } }
            $gifs["$($sid.GetAttribute('id'))/$($c.GetAttribute('id'))"] = @{ file = $file; frames = $info.frames; w = $info.w; h = $info.h; crop = $crop }
          }
        }
      } catch { Write-Host "  (could not read the GIFs of a slide: $($_.Exception.Message))" }
      foreach ($af in $sx.SelectNodes("//*[local-name()='normAutofit'][@fontScale or @lnSpcReduction]")) {
        $sp = $af.ParentNode.ParentNode # bodyPr -> txBody -> sp
        while ($sp -and $sp.LocalName -ne 'sp') { $sp = $sp.ParentNode }
        $c = if ($sp) { $sp.SelectSingleNode(".//*[local-name()='cNvPr']") } else { $null }
        if (-not $c) { continue }
        $fs = if ($af.HasAttribute('fontScale')) { [double]$af.GetAttribute('fontScale') / 100000 } else { 1 }
        $ls = if ($af.HasAttribute('lnSpcReduction')) { [double]$af.GetAttribute('lnSpcReduction') / 100000 } else { 0 }
        $fit["$($sid.GetAttribute('id'))/$($c.GetAttribute('id'))"] = @{ scale = $fs; lineReduction = $ls }
      }
    }
    $zip.Dispose()
    Remove-Item $copy -Force -ErrorAction SilentlyContinue
  } catch { Write-Host "  (could not read the shrink-to-fit scales: $($_.Exception.Message))" }
  $slides = @()
  $n = 0
  $deckTitle = [IO.Path]::GetFileNameWithoutExtension($full)
  $script:skippedMovies = @()
  $script:importNotes = @()
  $script:movieNames = @{}
  foreach ($slide in $pres.Slides) {
    $n++
    $slide.Export((Join-Path $Out "full\$n.png"), 'PNG', $Width, $Hpx)
    $shapes = @()
    $title = ''
    $z = 0
    # the slide's animations, in order (main sequence): entrance or exit, the trigger (On Click / With Previous /
    # After Previous), delay and length in seconds, instant (Appear / Disappear) or not, and the paragraph for
    # effects on single paragraphs (bullets one by one; 0 = the whole shape)
    $anims = @(); $animated = @{}
    try {
      $seq = $slide.TimeLine.MainSequence
      for ($e = 1; $e -le $seq.Count; $e++) {
        $ef = $seq.Item($e)
        $sid = [int]$ef.Shape.Id
        $trig = switch ([int]$ef.Timing.TriggerType) { 1 { 'click' } 3 { 'after' } default { 'with' } }
        $type = [int]$ef.EffectType
        # a movie's Play / Pause / Stop (msoAnimEffectMediaPlay 83, Pause 84, Stop 85): not an appearance
        if ($type -in 83, 84, 85) {
          $anims += @{ shapeId = $sid; media = $(switch ($type) { 83 { 'play' } 84 { 'pause' } default { 'stop' } }); trigger = $trig; delay = [double]$ef.Timing.TriggerDelayTime }
          continue
        }
        $anims += @{ shapeId = $sid; exit = (TrueOf $ef.Exit); trigger = $trig; delay = [double]$ef.Timing.TriggerDelayTime; duration = [double]$ef.Timing.Duration; fade = ($type -ne 1); paragraph = [int]$ef.Paragraph }
        $animated[$sid] = $true
      }
    } catch { }
    # a shape as a picture overlay (PowerPoint renders it; rotated shapes in their bounding box)
    $asPicture = {
      param($sh, $box)
      $png = "pic\$n-$($sh.Id).png"
      try {
        $sh.Export((Join-Path $Out $png), 2) # ppShapeFormatPNG (hidden but long-standing method)
        if ((Get-Item (Join-Path $Out $png)).Length -gt 0) {
          $script:shapes += $box + @{ kind = 'picture'; file = $png }
          $sh.Visible = 0
        }
      } catch { }
    }
    foreach ($sh in @($slide.Shapes)) {
      $z++
      $rot = [double]$sh.Rotation
      $isPlaceholder = ($sh.Type -eq 14)
      $contained = if ($isPlaceholder) { try { $sh.PlaceholderFormat.ContainedType } catch { 0 } } else { 0 }
      $isAnimated = $animated.ContainsKey([int]$sh.Id)
      $box = @{ id = [int]$sh.Id; x = $sh.Left / $W; y = $sh.Top / $H; w = $sh.Width / $W; h = $sh.Height / $H; z = $z; name = [string]$sh.Name }
      if ($rot -ne 0) {
        # rotated: stays in the background picture, unless it is animated (then a picture of its bounding box)
        if ($isAnimated) {
          $t = $rot * [Math]::PI / 180; $cx = $sh.Left + $sh.Width / 2; $cy = $sh.Top + $sh.Height / 2
          $bw = [Math]::Abs($sh.Width * [Math]::Cos($t)) + [Math]::Abs($sh.Height * [Math]::Sin($t))
          $bh = [Math]::Abs($sh.Width * [Math]::Sin($t)) + [Math]::Abs($sh.Height * [Math]::Cos($t))
          & $asPicture $sh ($box + @{}) | Out-Null
          if ($shapes.Count -and $shapes[-1].id -eq [int]$sh.Id) { $shapes[-1].x = ($cx - $bw / 2) / $W; $shapes[-1].y = ($cy - $bh / 2) / $H; $shapes[-1].w = $bw / $W; $shapes[-1].h = $bh / $H }
        }
        continue
      }
      # entirely off the slide (e.g. a slide number parked outside): not shown, leave it alone
      if ($box.x -ge 1 -or $box.y -ge 1 -or ($box.x + $box.w) -le 0 -or ($box.y + $box.h) -le 0) { continue }
      # movies: the file into media\, the shape out of the background
      $mv = $movies["$($slide.SlideID)/$($sh.Id)"]
      if ($mv) {
        $src = $null; $linkedPath = ''
        if ($mv.file) { $src = $mv.file }
        elseif ($mv.link -match '^https?:') { $script:skippedMovies += "slide ${n}: online video ($($mv.link)) - stays as a picture"; continue }
        else {
          try { $linkedPath = [string]$sh.LinkFormat.SourceFullName } catch { }
          if (-not $linkedPath) { try { $linkedPath = ([Uri]$mv.link).LocalPath } catch { $linkedPath = Join-Path (Split-Path $full) $mv.link } }
          if (Test-Path -LiteralPath $linkedPath) { $src = $linkedPath }
          else { $script:skippedMovies += "slide ${n}: the linked movie $linkedPath is missing - stays as a picture"; continue }
        }
        $startMs = 0; $endMs = 0; $lengthMs = 0; $muted = $false; $volume = 1; $loop = $false
        try { $mf = $sh.MediaFormat; $startMs = [double]$mf.StartPoint; $endMs = [double]$mf.EndPoint; $lengthMs = [double]$mf.Length; $muted = TrueOf $mf.Muted; $volume = [double]$mf.Volume } catch { }
        if ($lengthMs -gt 0 -and $endMs -ge $lengthMs - 50) { $endMs = 0 } # "trimmed" to its own end = not trimmed
        if ($endMs -gt 0 -and $endMs -le $startMs) { $endMs = 0 }
        try { $loop = TrueOf $sh.AnimationSettings.PlaySettings.LoopUntilStopped } catch { }
        $name = Movie-Name ([string]$sh.Name) $linkedPath $deckTitle $n
        $k = 2; $unique = $name
        while ($script:movieNames.ContainsKey($unique.ToLowerInvariant())) { $unique = "$name-$k"; $k++ }
        $script:movieNames[$unique.ToLowerInvariant()] = $true
        New-Item -ItemType Directory -Force -Path (Join-Path $Out 'media') | Out-Null
        Write-Host "  movie on slide ${n}: $unique ..."
        $made = Make-Playable $src (Join-Path $Out "media\$unique") $startMs $endMs
        $fileName = [IO.Path]::GetFileName($made.file)
        $poster = "pic\$n-$($sh.Id)-poster.png"
        try { $sh.Export((Join-Path $Out $poster), 2) } catch { }
        if (-not ((Test-Path -LiteralPath (Join-Path $Out $poster)) -and (Get-Item -LiteralPath (Join-Path $Out $poster)).Length -gt 0)) { $poster = '' }
        $mime = if ($fileName -match '\.webm$') { 'video/webm' } elseif ($fileName -match '\.mp4$|\.m4v$') { 'video/mp4' } elseif ($fileName -match '\.mov$') { 'video/quicktime' } else { 'video/' + ([IO.Path]::GetExtension($fileName).TrimStart('.').ToLowerInvariant()) }
        $shapes += $box + @{ kind = 'video'; file = "media/$fileName"; fileName = $fileName; mime = $mime; poster = ($poster -replace '\\', '/'); loop = $loop; muted = $muted; volume = $volume; trimmed = (($startMs -gt 0) -or ($endMs -gt 0)); how = $made.how; note = [string]$made.note; linked = $linkedPath }
        $sh.Visible = 0
        continue
      }
      # an animated GIF: its own file, so it keeps moving (a still GIF goes on as a PNG below)
      $gf = $gifs["$($slide.SlideID)/$($sh.Id)"]
      if ($gf -and ($sh.Type -eq 13 -or $contained -eq 13)) {
        $gifFile = "pic\$n-$($sh.Id).gif"
        $flipH = $false; $flipV = $false
        try { $flipH = TrueOf $sh.HorizontalFlip; $flipV = TrueOf $sh.VerticalFlip } catch { }
        # stretched in PowerPoint (its box has other proportions than the visible part of the GIF): stretch the file
        $cw = $gf.w * (1 - [Math]::Max(0, $gf.crop.l) - [Math]::Max(0, $gf.crop.r)); $ch = $gf.h * (1 - [Math]::Max(0, $gf.crop.t) - [Math]::Max(0, $gf.crop.b))
        $aspect = 0
        if ($cw -gt 0 -and $ch -gt 0 -and $sh.Height -gt 0) { $boxAspect = $sh.Width / $sh.Height; if ([Math]::Abs($boxAspect / ($cw / $ch) - 1) -gt 0.02) { $aspect = $boxAspect } }
        if (Make-Gif $gf.file (Join-Path $Out $gifFile) $gf.crop $flipH $flipV $aspect) {
          $shapes += $box + @{ kind = 'picture'; file = $gifFile; gif = $true; frames = $gf.frames }
          $sh.Visible = 0
          continue
        }
        $script:importNotes += "slide ${n}: an animated GIF that is cropped, flipped or stretched in PowerPoint came in as a still picture (ffmpeg is needed to cut it)"
      }
      # pictures (also a picture placeholder holding a picture)
      if ($sh.Type -eq 13 -or $contained -eq 13) { & $asPicture $sh $box; continue }
      # text
      $hasText = $false
      try { $hasText = (TrueOf $sh.HasTextFrame) -and (TrueOf $sh.TextFrame.HasText) } catch { }
      # anything else with an animation (arrow, box, line, group, chart): a picture, so it can appear / go
      if (-not $hasText) { if ($isAnimated) { & $asPicture $sh $box }; continue }
      # animated text in a filled or framed box: the box must come and go with its words, so the whole shape
      # becomes a picture (plain animated text stays editable text)
      if ($isAnimated) {
        $framed = $false; try { $framed = (TrueOf $sh.Fill.Visible) -or (TrueOf $sh.Line.Visible) } catch { }
        if ($framed) { & $asPicture $sh $box; continue }
      }
      $tf = $sh.TextFrame
      if (-not $title -and $isPlaceholder) { try { if ($sh.PlaceholderFormat.Type -in 1, 3) { $title = ($tf.TextRange.Text -replace '\s+', ' ').Trim() } } catch { } }
      $paras = @()
      $tr2 = $sh.TextFrame2.TextRange
      for ($p = 1; $p -le $tr2.Paragraphs().Count; $p++) {
        $para = $tr2.Paragraphs($p)
        $pf = $para.ParagraphFormat
        $runs = @()
        for ($r = 1; $r -le $para.Runs().Count; $r++) {
          $run = $para.Runs($r)
          $t = [string]$run.Text -replace "[\r\n\v]+$", ''
          if ($t -eq '') { continue }
          $f = $run.Font
          $color = '#000000'; try { $color = Hex $f.Fill.ForeColor.RGB } catch { }
          $runs += @{ text = $t; size = [double]$f.Size; bold = (TrueOf $f.Bold); italic = (TrueOf $f.Italic); underline = ($f.UnderlineStyle -ne 0); color = $color; font = [string]$f.Name; sup = ($f.BaselineOffset -gt 0); sub = ($f.BaselineOffset -lt 0) }
        }
        $align = switch ([int]$pf.Alignment) { 2 { 'center' } 3 { 'right' } 4 { 'justify' } 5 { 'justify' } default { 'left' } }
        $bullet = $false; try { $bullet = (TrueOf $pf.Bullet.Visible) -and ($pf.Bullet.Type -ne 0) } catch { }
        $paras += @{ runs = $runs; align = $align; bullet = $bullet; level = [int]$pf.IndentLevel }
      }
      $valign = switch ([int]$tf.VerticalAnchor) { 3 { 'middle' } 4 { 'bottom' } 5 { 'bottom' } default { 'top' } }
      $f = $fit["$($slide.SlideID)/$($sh.Id)"]
      $margins = @{ left = [double]$tf.MarginLeft; top = [double]$tf.MarginTop; right = [double]$tf.MarginRight; bottom = [double]$tf.MarginBottom }
      $isNumber = $false; try { $isNumber = $isPlaceholder -and ($sh.PlaceholderFormat.Type -eq 13) } catch { } # ppPlaceholderSlideNumber
      $shapes += $box + @{ kind = 'text'; paragraphs = $paras; valign = $valign; margins = $margins; fontScale = $(if ($f) { $f.scale } else { 1 }); lineReduction = $(if ($f) { $f.lineReduction } else { 0 }); slideNumber = $isNumber }
      $tf.TextRange.Text = ''   # blanked in this read-only copy, so the background keeps the box but not the words
    }
    $slide.Export((Join-Path $Out "bg\$n.png"), 'PNG', $Width, $Hpx)
    $notes = ''
    try { $notes = [string]$slide.NotesPage.Shapes.Placeholders(2).TextFrame.TextRange.Text } catch { }
    $hidden = $false; try { $hidden = TrueOf $slide.SlideShowTransition.Hidden } catch { }
    $slides += @{ n = $n; bg = "bg/$n.png"; full = "full/$n.png"; title = $title; notes = $notes; hidden = $hidden; shapes = $shapes; animations = $anims }
  }
  Remove-Item -LiteralPath $mediaSrc -Recurse -Force -ErrorAction SilentlyContinue
  $manifest = @{ source = (Split-Path $full -Leaf); title = $deckTitle; slideWidthPt = $W; slideHeightPt = $H; widthPx = $Width; heightPx = $Hpx; slides = $slides; skippedMovies = @($script:skippedMovies); notes = @($script:importNotes) }
  [IO.File]::WriteAllText((Join-Path $Out 'manifest.json'), ($manifest | ConvertTo-Json -Depth 12), (New-Object Text.UTF8Encoding $false))
  "exported $n slides to $Out"
} finally {
  $pres.Saved = -1
  $pres.Close()
  if ($hadOpen -eq 0 -and $app.Presentations.Count -eq 0) { $app.Quit() }
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($pres)
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($app)
}
